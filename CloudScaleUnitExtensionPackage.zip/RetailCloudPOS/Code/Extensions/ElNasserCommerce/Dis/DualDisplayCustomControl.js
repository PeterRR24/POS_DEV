System.register(["PosApi/Extend/DualDisplay", "PosApi/Consume/Controls", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var DualDisplay_1, Controls_1, TypeExtensions_1, knockout_1, DualDisplayCustomControl;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (DualDisplay_1_1) {
                DualDisplay_1 = DualDisplay_1_1;
            },
            function (Controls_1_1) {
                Controls_1 = Controls_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            DualDisplayCustomControl = (function (_super) {
                __extends(DualDisplayCustomControl, _super);
                function DualDisplayCustomControl(id, context) {
                    var _this = _super.call(this, id, context) || this;
                    _this.mediaServerUrl = "https://cn-guazha-1112.fareast.corp.microsoft.com:446/DualDisplay/";
                    _this.IMGTOTAL = 10;
                    _this.cartTotalAmountLabel = _this.context.resources.getString("string_5");
                    _this.customerNameLabel = _this.context.resources.getString("string_6");
                    _this.customerAccountNumberLabel = _this.context.resources.getString("string_7");
                    _this.employeeNameLabel = _this.context.resources.getString("string_8");
                    _this._cart = knockout_1.default.observable(null);
                    _this._cartLines = [];
                    _this._customer = knockout_1.default.observable(null);
                    _this._loggedOn = knockout_1.default.observable(false);
                    _this._employee = knockout_1.default.observable(null);
                    _this.imgIndex = 0;
                    _this.imgUrl = knockout_1.default.observable('');
                    _this.currentCartLine = knockout_1.default.observable(null);
                    _this.cartTotalAmount = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this._cart()) ? 0.00 : _this._cart().TotalAmount;
                    });
                    _this.customerName = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this._customer()) ? TypeExtensions_1.StringExtensions.EMPTY : _this._customer().Name;
                    });
                    _this.customerAccountNumber = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this._customer()) ? TypeExtensions_1.StringExtensions.EMPTY : _this._customer().AccountNumber;
                    });
                    _this.isLoggedOn = knockout_1.default.computed(function () {
                        return _this._loggedOn();
                    });
                    _this.employeeName = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this._employee()) ? TypeExtensions_1.StringExtensions.EMPTY : _this._employee().Name;
                    });
                    _this.itemId = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this.currentCartLine()) ? TypeExtensions_1.StringExtensions.EMPTY : _this.currentCartLine().ItemId;
                    });
                    _this.productName = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this.currentCartLine()) || TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(_this.currentCartLine().Description) ?
                            TypeExtensions_1.StringExtensions.EMPTY : _this.currentCartLine().Description;
                    });
                    _this.productQuantity = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this.currentCartLine()) ? TypeExtensions_1.StringExtensions.EMPTY : _this.currentCartLine().Quantity.toString();
                    });
                    _this.productDiscount = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this.currentCartLine()) ? TypeExtensions_1.StringExtensions.EMPTY : _this.currentCartLine().DiscountAmount.toString();
                    });
                    _this.productCost = knockout_1.default.computed(function () {
                        return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this.currentCartLine()) ? TypeExtensions_1.StringExtensions.EMPTY : _this.currentCartLine().TotalAmount.toString();
                    });
                    _this.cartChangedHandler = function (data) {
                        _this._cart(data.cart);
                        var currentCartLineId = localStorage.getItem("currentCartLineId");
                        var isNewLine = !TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(currentCartLineId) && _this._dataList.data.filter(function (line) { return line.LineId === currentCartLineId; }).length > 0 ? false : true;
                        _this._dataList.data = TypeExtensions_1.ObjectExtensions.isNullOrUndefined(data.cart) ? [] : data.cart.CartLines;
                        var listLine = document.querySelector(".dataListLine");
                        var rowHeight = 39;
                        if (listLine === null || listLine === void 0 ? void 0 : listLine.clientHeight) {
                            rowHeight = listLine === null || listLine === void 0 ? void 0 : listLine.clientHeight;
                        }
                        if (data.cart && data.cart.CartLines.length > 0 && !TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(currentCartLineId)) {
                            _this.currentCartLine(_this._dataList.data.filter(function (line) { return line.LineId === currentCartLineId; })[0]);
                            if (isNewLine) {
                                if (!TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(currentCartLineId)) {
                                    if (data.cart.CartLines.length >= 16) {
                                        setTimeout(function () {
                                            var dualDisplayScrollingContainer = document.querySelector('[aria-label="Scrolling Container"]');
                                            var totalHeight = dualDisplayScrollingContainer.scrollHeight;
                                            var shouldScrollTop = totalHeight - rowHeight * 15;
                                            dualDisplayScrollingContainer.scrollTo({
                                                top: shouldScrollTop,
                                                behavior: 'smooth'
                                            });
                                        }, 700);
                                    }
                                }
                            }
                            else {
                                setTimeout(function () {
                                    var selectedIndex = TypeExtensions_1.ArrayExtensions.findIndex(data.cart.CartLines, function (cartline) { return cartline.LineId === currentCartLineId; });
                                    var dualDisplayScrollingContainer = document.querySelector('[aria-label="Scrolling Container"]');
                                    var shouldScrollTop = rowHeight * selectedIndex;
                                    dualDisplayScrollingContainer.scrollTo({
                                        top: shouldScrollTop,
                                        behavior: 'smooth'
                                    });
                                }, 700);
                            }
                        }
                        else {
                            _this.currentCartLine(null);
                        }
                    };
                    _this.customerChangedHandler = function (data) {
                        _this._customer(data.customer);
                    };
                    _this.logOnStatusChangedHandler = function (data) {
                        _this.isProcessing = true;
                        window.setTimeout(function () {
                            _this.isProcessing = false;
                        }, 1000);
                        _this._loggedOn(data.loggedOn);
                        _this._employee(data.employee);
                    };
                    _this.context.logger.logInformational("DualDisplayCustomControl constructed", _this.context.logger.getNewCorrelationId());
                    return _this;
                }
                DualDisplayCustomControl.prototype.onReady = function (element) {
                    var _this = this;
                    var cartLinesDataListOptions = {
                        interactionMode: Controls_1.DataListInteractionMode.SingleSelect,
                        data: this._cartLines,
                        columns: [
                            {
                                title: this.context.resources.getString("string_0"),
                                ratio: 20,
                                collapseOrder: 2,
                                minWidth: 50,
                                computeValue: function (cartLine) {
                                    return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(cartLine.ItemId) ? TypeExtensions_1.StringExtensions.EMPTY : cartLine.ItemId;
                                }
                            },
                            {
                                title: this.context.resources.getString("string_1"),
                                ratio: 50,
                                collapseOrder: 4,
                                minWidth: 100,
                                computeValue: function (cartLine) {
                                    return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(cartLine.Description) ? TypeExtensions_1.StringExtensions.EMPTY : cartLine.Description;
                                }
                            },
                            {
                                title: this.context.resources.getString("string_2"),
                                ratio: 10,
                                collapseOrder: 3,
                                minWidth: 50,
                                computeValue: function (cartLine) {
                                    return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(cartLine.Quantity) ? TypeExtensions_1.StringExtensions.EMPTY : cartLine.Quantity.toString();
                                }
                            },
                            {
                                title: this.context.resources.getString("string_3"),
                                ratio: 10,
                                collapseOrder: 1,
                                minWidth: 50,
                                computeValue: function (cartLine) {
                                    return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(cartLine.DiscountAmount) ? TypeExtensions_1.StringExtensions.EMPTY : cartLine.DiscountAmount.toString();
                                }
                            },
                            {
                                title: this.context.resources.getString("string_4"),
                                ratio: 10,
                                collapseOrder: 5,
                                minWidth: 50,
                                computeValue: function (cartLine) {
                                    return TypeExtensions_1.ObjectExtensions.isNullOrUndefined(cartLine.TotalAmount) ? TypeExtensions_1.StringExtensions.EMPTY : cartLine.TotalAmount.toString();
                                }
                            }
                        ]
                    };
                    knockout_1.default.applyBindingsToNode(element, {
                        template: {
                            name: DualDisplayCustomControl.TEMPLATE_ID,
                            data: this
                        }
                    });
                    var dualDisplayRootElem = element.querySelector("#dualDisplayDataListSample");
                    this._dataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DataList", cartLinesDataListOptions, dualDisplayRootElem);
                    setInterval(function () {
                        _this.imgIndex++;
                        if (_this.imgIndex >= _this.IMGTOTAL) {
                            _this.imgIndex = 0;
                        }
                        _this.imgUrl(_this.mediaServerUrl + "desktop_".concat(_this.imgIndex, ".jpg"));
                        console.log(_this.imgUrl());
                    }, 4000);
                };
                DualDisplayCustomControl.prototype.init = function (state) {
                    this._cart(state.cart);
                    this._customer(state.customer);
                    this._loggedOn(state.loggedOn);
                    this._employee(state.employee);
                    this._cartLines = TypeExtensions_1.ObjectExtensions.isNullOrUndefined(this._cart()) ? [] : this._cart().CartLines;
                };
                DualDisplayCustomControl.TEMPLATE_ID = "Microsot_Pos_Extensibility_Samples_DualDisplay";
                return DualDisplayCustomControl;
            }(DualDisplay_1.DualDisplayCustomControlBase));
            exports_1("default", DualDisplayCustomControl);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Dis/DualDisplayCustomControl.js.map