System.register(["PosApi/Consume/Formatters"], function (exports_1, context_1) {
    "use strict";
    var Formatters_1;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Formatters_1_1) {
                Formatters_1 = Formatters_1_1;
            }
        ],
        execute: function () {
            exports_1("default", (function (context) {
                return [
                    {
                        title: "Item ID_CUSTOMIZED",
                        computeValue: function (row) { return row.ItemId; },
                        ratio: 20,
                        collapseOrder: 3,
                        minWidth: 120
                    }, {
                        title: "Desc",
                        computeValue: function (row) { return row.Name; },
                        ratio: 40,
                        collapseOrder: 2,
                        minWidth: 200
                    }, {
                        title: "DisplayOrder",
                        computeValue: function (row) { return "RecID: " + row.DisplayOrder; },
                        ratio: 20,
                        collapseOrder: 4,
                        minWidth: 200
                    }, {
                        title: "Price",
                        computeValue: function (row) { return Formatters_1.CurrencyFormatter.toCurrency(row.Price); },
                        ratio: 20,
                        collapseOrder: 1,
                        minWidth: 100,
                        isRightAligned: true
                    }
                ];
            }));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/RRV1Modifcation/SearchOrders/CustomProductSearchColumns.js.map