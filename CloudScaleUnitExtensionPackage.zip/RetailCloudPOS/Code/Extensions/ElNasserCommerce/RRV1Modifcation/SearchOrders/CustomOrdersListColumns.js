System.register(["PosApi/Consume/Formatters"], function (exports_1, context_1) {
    "use strict";
    var Formatters_1;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Formatters_1_1) {
                Formatters_1 = Formatters_1_1;
            }
        ],
        execute: function () {
            exports_1("default", (function (context) {
                return [
                    {
                        title: "SALES ORDER",
                        computeValue: function (row) {
                            return row.salesOrder.SalesId;
                        },
                        ratio: 10,
                        collapseOrder: 8,
                        minWidth: 100
                    },
                    {
                        title: "ORDER TYPE",
                        computeValue: function (row) {
                            return row.customerOrderType;
                        },
                        ratio: 15,
                        collapseOrder: 2,
                        minWidth: 200
                    },
                    {
                        title: "ORDER STATUS",
                        computeValue: function (row) {
                            return row.orderStatus;
                        },
                        ratio: 15,
                        collapseOrder: 4,
                        minWidth: 70
                    },
                    {
                        title: "CREATED DATE",
                        computeValue: function (row) {
                            return Formatters_1.DateFormatter.toShortDateAndTime(row.salesOrder.CreatedDateTime);
                        },
                        ratio: 10,
                        collapseOrder: 5,
                        minWidth: 200
                    },
                    {
                        title: "AgentName/PayMethod",
                        computeValue: function (row) {
                            return row.salesOrder.ReceiptEmail;
                        },
                        ratio: 10,
                        collapseOrder: 3,
                        minWidth: 150
                    },
                    {
                        title: "CUSTOMER NAME",
                        computeValue: function (row) {
                            return row.salesOrder.Name;
                        },
                        ratio: 15,
                        collapseOrder: 6,
                        minWidth: 200
                    },
                    {
                        title: "Ref",
                        computeValue: function (row) {
                            return row.salesOrder.Comment;
                        },
                        ratio: 10,
                        collapseOrder: 1,
                        minWidth: 200
                    },
                    {
                        title: "ORDER TOTAL",
                        computeValue: function (row) {
                            return Formatters_1.CurrencyFormatter.toCurrency(row.salesOrder.TotalAmount);
                        },
                        ratio: 10,
                        collapseOrder: 7,
                        minWidth: 100,
                        isRightAligned: true
                    },
                    {
                        title: "Req Date",
                        computeValue: function (row) {
                            return Formatters_1.DateFormatter.toShortDateAndTime(row.salesOrder.RequestedDeliveryDate);
                        },
                        ratio: 5,
                        collapseOrder: 9,
                        minWidth: 200
                    }
                ];
            }));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/RRV1Modifcation/SearchOrders/CustomOrdersListColumns.js.map