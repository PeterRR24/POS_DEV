System.register(["PosApi/Entities", "./DataServiceEntities.g", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, DataServiceEntities_g_1, DataService_1, Products;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            exports_1("Entities", DataServiceEntities_g_1.Entities);
            (function (Products) {
                var ProductSearchByTextResponse = (function (_super) {
                    __extends(ProductSearchByTextResponse, _super);
                    function ProductSearchByTextResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return ProductSearchByTextResponse;
                }(DataService_1.DataServiceResponse));
                Products.ProductSearchByTextResponse = ProductSearchByTextResponse;
                var ProductSearchByTextRequest = (function (_super) {
                    __extends(ProductSearchByTextRequest, _super);
                    function ProductSearchByTextRequest(productSearchCriteria, top, skip) {
                        var _this = _super.call(this) || this;
                        _this._method = "ProductSearchByText";
                        _this._parameters = { productSearchCriteria: productSearchCriteria, topRows: top, skipRows: skip };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.ProductExClass;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return ProductSearchByTextRequest;
                }(DataService_1.DataServiceRequest));
                Products.ProductSearchByTextRequest = ProductSearchByTextRequest;
                var GetProductAvailableQuantityResponse = (function (_super) {
                    __extends(GetProductAvailableQuantityResponse, _super);
                    function GetProductAvailableQuantityResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetProductAvailableQuantityResponse;
                }(DataService_1.DataServiceResponse));
                Products.GetProductAvailableQuantityResponse = GetProductAvailableQuantityResponse;
                var GetProductAvailableQuantityRequest = (function (_super) {
                    __extends(GetProductAvailableQuantityRequest, _super);
                    function GetProductAvailableQuantityRequest(productId, itemId, inventDimId) {
                        var _this = _super.call(this) || this;
                        _this._method = "ProductAvailableQuantity";
                        _this._parameters = { productId: productId, itemID: itemId, inventDimId: inventDimId };
                        _this._isAction = true;
                        _this._returnType = Number;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return GetProductAvailableQuantityRequest;
                }(DataService_1.DataServiceRequest));
                Products.GetProductAvailableQuantityRequest = GetProductAvailableQuantityRequest;
                var UpdateCartLinesResponse = (function (_super) {
                    __extends(UpdateCartLinesResponse, _super);
                    function UpdateCartLinesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return UpdateCartLinesResponse;
                }(DataService_1.DataServiceResponse));
                Products.UpdateCartLinesResponse = UpdateCartLinesResponse;
                var UpdateCartLinesRequest = (function (_super) {
                    __extends(UpdateCartLinesRequest, _super);
                    function UpdateCartLinesRequest(cartID, cartLines) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Carts";
                        _this._entityType = "Cart";
                        _this._keys = { Id: cartID };
                        _this._method = "UpdateCartLines";
                        _this._parameters = { cartLines: cartLines };
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.CartClass;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return UpdateCartLinesRequest;
                }(DataService_1.DataServiceRequest));
                Products.UpdateCartLinesRequest = UpdateCartLinesRequest;
                var VoidCartLinesResponse = (function (_super) {
                    __extends(VoidCartLinesResponse, _super);
                    function VoidCartLinesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return VoidCartLinesResponse;
                }(DataService_1.DataServiceResponse));
                Products.VoidCartLinesResponse = VoidCartLinesResponse;
                var VoidCartLinesRequest = (function (_super) {
                    __extends(VoidCartLinesRequest, _super);
                    function VoidCartLinesRequest(cartID, cartLines) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Carts";
                        _this._entityType = "Cart";
                        _this._keys = { Id: cartID };
                        _this._method = "VoidCartLines";
                        _this._parameters = { cartLines: cartLines };
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.CartClass;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return VoidCartLinesRequest;
                }(DataService_1.DataServiceRequest));
                Products.VoidCartLinesRequest = VoidCartLinesRequest;
                var GetProductSearchResponse = (function (_super) {
                    __extends(GetProductSearchResponse, _super);
                    function GetProductSearchResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetProductSearchResponse;
                }(DataService_1.DataServiceResponse));
                Products.GetProductSearchResponse = GetProductSearchResponse;
                var GetProductSearchRequest = (function (_super) {
                    __extends(GetProductSearchRequest, _super);
                    function GetProductSearchRequest(productSearchCriteria, searchMode) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Products";
                        _this._method = "SearchEx";
                        _this._parameters = { productSearchCriteria: productSearchCriteria, searchMode: 1 };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.ProductExClass;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetProductSearchRequest;
                }(DataService_1.DataServiceRequest));
                Products.GetProductSearchRequest = GetProductSearchRequest;
                var GetProductVariantResponse = (function (_super) {
                    __extends(GetProductVariantResponse, _super);
                    function GetProductVariantResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetProductVariantResponse;
                }(DataService_1.DataServiceResponse));
                Products.GetProductVariantResponse = GetProductVariantResponse;
                var GetProductVariantRequest = (function (_super) {
                    __extends(GetProductVariantRequest, _super);
                    function GetProductVariantRequest(channelId, RecordId, matchingDimensionValues) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Products(" + RecordId + ")";
                        _this._method = "GetVariantsByDimensionValues";
                        _this._parameters = { channelId: channelId, matchingDimensionValues: matchingDimensionValues };
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.SimpleProductClass;
                        _this.top = 1;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetProductVariantRequest;
                }(DataService_1.DataServiceRequest));
                Products.GetProductVariantRequest = GetProductVariantRequest;
                var GetDimensionValuesResponse = (function (_super) {
                    __extends(GetDimensionValuesResponse, _super);
                    function GetDimensionValuesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetDimensionValuesResponse;
                }(DataService_1.DataServiceResponse));
                Products.GetDimensionValuesResponse = GetDimensionValuesResponse;
                var GetDimensionValuesRequest = (function (_super) {
                    __extends(GetDimensionValuesRequest, _super);
                    function GetDimensionValuesRequest(channelId, RecordId, dimension, kitVariantResolutionContext, matchingDimensionValues) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Products(" + RecordId + ")";
                        _this._method = "GetDimensionValues";
                        _this._parameters = { channelId: channelId, dimension: dimension, kitVariantResolutionContext: kitVariantResolutionContext, matchingDimensionValues: matchingDimensionValues };
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.ProductDimensionValueClass;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetDimensionValuesRequest;
                }(DataService_1.DataServiceRequest));
                Products.GetDimensionValuesRequest = GetDimensionValuesRequest;
            })(Products || (exports_1("Products", Products = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/RRV1Modifcation/DataService/DataServiceRequests.g.js.map