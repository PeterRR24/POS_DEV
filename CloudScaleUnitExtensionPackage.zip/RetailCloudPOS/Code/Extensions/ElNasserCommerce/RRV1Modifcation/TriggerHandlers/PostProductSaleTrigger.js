System.register(["PosApi/Extend/Triggers/ProductTriggers", "../DataService/DataServiceRequests.g", "PosApi/Consume/Cart"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, DataServiceRequests_g_1, Cart_1, PostProductSaleTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (Cart_1_1) {
                Cart_1 = Cart_1_1;
            }
        ],
        execute: function () {
            PostProductSaleTrigger = (function (_super) {
                __extends(PostProductSaleTrigger, _super);
                function PostProductSaleTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PostProductSaleTrigger.prototype.execute = function (options) {
                    var _this = this;
                    this.context.logger.logVerbose("Executing PostProductSaleTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    var correlationId = '';
                    var voidCartLines = [];
                    var PSDs = options.productSaleDetails;
                    var products = '';
                    if (options.cart.CartLines[options.cart.CartLines.length - 1].Description.charAt(0) === "%") {
                        var Desc = options.cart.CartLines[options.cart.CartLines.length - 1].Description.split('%');
                        var UpatedPrice = (options.cart.CartLines[options.cart.CartLines.length - 1].Price * parseFloat(Desc[1])) / 100;
                        this.context.runtime.executeAsync(new Cart_1.PriceOverrideOperationRequest(options.cart.CartLines[options.cart.CartLines.length - 1].LineId, UpatedPrice, ""))
                            .then(function () {
                            correlationId = _this.context.logger.getNewCorrelationId();
                            _this.context.runtime.executeAsync(new Commerce.RefreshCartClientRequest(correlationId))
                                .then(function (resp) {
                                console.log(resp);
                            });
                        }).catch(function (err) {
                            console.log(err);
                        });
                    }
                    this.GetProductsQuantity(PSDs).then(function (results) {
                        for (var idx = 0; idx < results.length; idx++) {
                            if (!(results[idx].AvailableQuantity > 0)) {
                                for (var cl = 0; cl < options.cart.CartLines.length; cl++) {
                                    if (options.cart.CartLines[cl].ProductId == results[idx].product.RecordId) {
                                        voidCartLines.push(options.cart.CartLines[cl]);
                                        var item = options.cart.CartLines[cl].ItemId + '::' + options.cart.CartLines[cl].Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                        }
                                    }
                                }
                            }
                        }
                    }).catch(function (err) {
                        console.log(err);
                    });
                    return Promise.resolve();
                };
                PostProductSaleTrigger.prototype.GetProductsQuantity = function (PSDs) {
                    var promises = [];
                    var itemQtyRequest = null;
                    var _loop_1 = function (i) {
                        if (PSDs[i].product.ProductTypeValue == 4 || PSDs[i].product.ProductTypeValue == 5) {
                            itemQtyRequest = new DataServiceRequests_g_1.Products.GetProductAvailableQuantityRequest(PSDs[i].product.RecordId, PSDs[i].product.ItemId, '');
                            promises.push(this_1.context.runtime.executeAsync(itemQtyRequest)
                                .then(function (resp) {
                                if (!resp.canceled) {
                                    PSDs[i].AvailableQuantity = resp.data.result;
                                    return PSDs[i];
                                }
                            }));
                        }
                    };
                    var this_1 = this;
                    for (var i = 0; i < PSDs.length; i++) {
                        _loop_1(i);
                    }
                    return Promise.all(promises);
                };
                return PostProductSaleTrigger;
            }(Triggers.PostProductSaleTrigger));
            exports_1("default", PostProductSaleTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/RRV1Modifcation/TriggerHandlers/PostProductSaleTrigger.js.map