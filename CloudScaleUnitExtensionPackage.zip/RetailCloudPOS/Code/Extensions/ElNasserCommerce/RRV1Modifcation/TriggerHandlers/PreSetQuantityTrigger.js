System.register(["PosApi/Extend/Triggers/ProductTriggers"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, PreSetQuantityTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            }
        ],
        execute: function () {
            PreSetQuantityTrigger = (function (_super) {
                __extends(PreSetQuantityTrigger, _super);
                function PreSetQuantityTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PreSetQuantityTrigger.prototype.execute = function (options) {
                    this.context.logger.logVerbose("Executing PreProductSaleTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    sessionStorage.setItem("InitialTransQuantity", "2");
                    return Promise.resolve({ canceled: false });
                };
                return PreSetQuantityTrigger;
            }(Triggers.PreSetQuantityTrigger));
            exports_1("default", PreSetQuantityTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/RRV1Modifcation/TriggerHandlers/PreSetQuantityTrigger.js.map