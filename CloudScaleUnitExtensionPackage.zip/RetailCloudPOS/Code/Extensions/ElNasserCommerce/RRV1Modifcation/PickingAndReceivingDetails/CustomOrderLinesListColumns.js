System.register([], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            exports_1("default", (function (context) {
                return [
                    {
                        title: "PRODUCT Number",
                        computeValue: function (row) {
                            return row.productNumber;
                        },
                        ratio: 20,
                        collapseOrder: 3,
                        minWidth: 100
                    },
                    {
                        title: "QUANTITY ORDERED",
                        computeValue: function (row) {
                            return row.quantityOrdered.toString();
                        },
                        ratio: 20,
                        collapseOrder: 2,
                        minWidth: 100
                    },
                    {
                        title: "UNIT OF MEASURE",
                        computeValue: function (row) {
                            return row.unitOfMeasure;
                        },
                        ratio: 20,
                        collapseOrder: 1,
                        minWidth: 100
                    },
                    {
                        title: "Description",
                        computeValue: function (row) {
                            return row.description;
                        },
                        ratio: 20,
                        collapseOrder: 4,
                        minWidth: 100
                    },
                    {
                        title: "Quantity Rec",
                        computeValue: function (row) {
                            return row.quantityReceived.toString();
                        },
                        ratio: 20,
                        collapseOrder: 5,
                        minWidth: 100
                    }
                ];
            }));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/RRV1Modifcation/PickingAndReceivingDetails/CustomOrderLinesListColumns.js.map