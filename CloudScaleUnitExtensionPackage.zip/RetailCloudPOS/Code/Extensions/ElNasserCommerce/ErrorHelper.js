System.register(["PosApi/Consume/Dialogs", "PosApi/Entities"], function (exports_1, context_1) {
    "use strict";
    var Dialogs_1, Entities_1, ErrorHelper;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1_1) {
                Dialogs_1 = Dialogs_1_1;
            },
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            }
        ],
        execute: function () {
            ErrorHelper = (function () {
                function ErrorHelper() {
                }
                ErrorHelper.displayLocalizedErrorAsync = function (context, errorObj) {
                    var reason = errorObj;
                    var errorMsg = '';
                    var errorCode = '';
                    if (errorObj instanceof Array) {
                        if (errorObj.length) {
                            reason = errorObj[0];
                            errorCode = errorObj[0]._errorCode;
                        }
                    }
                    else {
                        errorCode = errorObj._errorCode || '';
                    }
                    if (reason instanceof Entities_1.ClientEntities.ExtensionError) {
                        errorMsg = reason.localizedMessage;
                    }
                    else if (reason instanceof Error) {
                        errorMsg = reason.message;
                        if (errorMsg == '' && errorCode != '') {
                            var rrcom = Commerce;
                            errorMsg = rrcom.ViewModelAdapter.getResourceString(errorCode);
                        }
                    }
                    else if (typeof reason === "string") {
                        errorMsg = reason;
                    }
                    else {
                        errorMsg = "An unexpected error occurred.";
                    }
                    return ErrorHelper.displayMessageAsync(context, errorMsg);
                };
                ErrorHelper.displayMessageAsync = function (context, reason) {
                    var messageDialogOptions = {
                        message: reason
                    };
                    var messageRequest = new Dialogs_1.ShowMessageDialogClientRequest(messageDialogOptions);
                    return context.runtime.executeAsync(messageRequest);
                };
                ErrorHelper.displayErrorAsync = function (context, reason) {
                    var messageDialogOptions;
                    if (reason instanceof Entities_1.ClientEntities.ExtensionError) {
                        messageDialogOptions = {
                            message: reason.localizedMessage
                        };
                    }
                    else if (reason instanceof Error) {
                        messageDialogOptions = {
                            message: reason.message
                        };
                    }
                    else if (typeof reason === "string") {
                        messageDialogOptions = {
                            message: reason
                        };
                    }
                    else {
                        messageDialogOptions = {
                            message: "An unexpected error occurred."
                        };
                    }
                    var errorMessageRequest = new Dialogs_1.ShowMessageDialogClientRequest(messageDialogOptions);
                    return context.runtime.executeAsync(errorMessageRequest);
                };
                return ErrorHelper;
            }());
            exports_1("ErrorHelper", ErrorHelper);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/ErrorHelper.js.map