System.register(["PosApi/Create/Operations", "./RangingOperationRequest", "../../DataService2/RangingDataServiceRequests.g"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, RangingOperationRequest_1, RangingDataServiceRequests_g_1, RangingOperationRequestHandler;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            },
            function (RangingOperationRequest_1_1) {
                RangingOperationRequest_1 = RangingOperationRequest_1_1;
            },
            function (RangingDataServiceRequests_g_1_1) {
                RangingDataServiceRequests_g_1 = RangingDataServiceRequests_g_1_1;
            }
        ],
        execute: function () {
            RangingOperationRequestHandler = (function (_super) {
                __extends(RangingOperationRequestHandler, _super);
                function RangingOperationRequestHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                RangingOperationRequestHandler.prototype.supportedRequestType = function () {
                    return RangingOperationRequest_1.default;
                };
                RangingOperationRequestHandler.prototype.executeAsync = function (request) {
                    var _this = this;
                    this.context.logger.logInformational("Log message from RangingOperationRequestHandler executeAsync().", this.context.logger.getNewCorrelationId());
                    return new Promise(function (resolve) {
                        var request = new RangingDataServiceRequests_g_1.Ranging.UtilitiesConfigurationRequest();
                        _this.context.runtime.executeAsync(request)
                            .then(function (result) {
                            setTimeout(resolve, 500);
                            _this.context.navigator.navigate("ItemStoreLocationView", { isFaceing: result.data.result.RangingWithFaces });
                        });
                    });
                };
                return RangingOperationRequestHandler;
            }(Operations_1.ExtensionOperationRequestHandlerBase));
            exports_1("default", RangingOperationRequestHandler);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Operations/Ranging/RangingOperationRequestHandler.js.map