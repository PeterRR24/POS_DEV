System.register(["./StockTakeOperationRequest"], function (exports_1, context_1) {
    "use strict";
    var StockTakeOperationRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (StockTakeOperationRequest_1_1) {
                StockTakeOperationRequest_1 = StockTakeOperationRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var operationRequest = new StockTakeOperationRequest_1.default(correlationId);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Operations/StockTake/StockTakeOperationRequestFactory.js.map