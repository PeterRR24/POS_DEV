System.register(["PosApi/Create/Dialogs", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, TypeExtensions_1, knockout_1, ClearCommitOptionsDialogModule;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            ClearCommitOptionsDialogModule = (function (_super) {
                __extends(ClearCommitOptionsDialogModule, _super);
                function ClearCommitOptionsDialogModule(shelf) {
                    var _this = _super.call(this) || this;
                    _this.message = knockout_1.default.observable("");
                    _this.optionValue = knockout_1.default.observable("0");
                    _this.shelf = knockout_1.default.observable(shelf);
                    return _this;
                }
                ClearCommitOptionsDialogModule.prototype.onReady = function (el) {
                    knockout_1.default.applyBindings(this, el);
                };
                ClearCommitOptionsDialogModule.prototype.open = function (message, title, subTitle) {
                    var _this = this;
                    if (title === void 0) { title = "Dialog title"; }
                    if (subTitle === void 0) { subTitle = ""; }
                    this.message(message);
                    var promise = new Promise(function (resolve, reject) {
                        _this.resolve = resolve;
                        var option = {
                            title: title,
                            subTitle: subTitle,
                            onCloseX: _this.onCloseX.bind(_this),
                            button1: {
                                id: "ok",
                                label: _this.context.resources.getString("OK_BUTTON"),
                                isPrimary: true,
                                onClick: _this.okClickHandler.bind(_this)
                            },
                            button2: {
                                id: "cancel",
                                label: _this.context.resources.getString("CANCEL_BUTTON"),
                                onClick: _this.cancelClickHandler.bind(_this)
                            }
                        };
                        _this.openDialog(option);
                    });
                    console.log(this.shelf);
                    var self = this;
                    this.optionValue.subscribe(function () {
                        self.enableOk();
                    });
                    this.setButtonDisabledState("ok", (this.optionValue() == "0"));
                    return promise;
                };
                ClearCommitOptionsDialogModule.prototype.enableOk = function () {
                    this.setButtonDisabledState("ok", (this.optionValue() == "0"));
                };
                ClearCommitOptionsDialogModule.prototype.onCloseX = function () {
                    this.resolvePromise("0");
                    return true;
                };
                ClearCommitOptionsDialogModule.prototype.okClickHandler = function () {
                    this.resolvePromise(this.optionValue());
                    this.closeDialog();
                    return true;
                };
                ClearCommitOptionsDialogModule.prototype.cancelClickHandler = function () {
                    this.resolvePromise("0");
                    this.closeDialog();
                    return false;
                };
                ClearCommitOptionsDialogModule.prototype.resolvePromise = function (result) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.resolve)) {
                        this.resolve({
                            selectedValue: result
                        });
                        this.resolve = null;
                    }
                };
                return ClearCommitOptionsDialogModule;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", ClearCommitOptionsDialogModule);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Controls/DialogControl/ClearCommitOptionsDialogModule.js.map