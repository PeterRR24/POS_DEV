System.register(["PosApi/Create/Dialogs", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, TypeExtensions_1, knockout_1, ProcessingDialogModule;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            ProcessingDialogModule = (function (_super) {
                __extends(ProcessingDialogModule, _super);
                function ProcessingDialogModule() {
                    var _this = _super.call(this) || this;
                    _this.displayMessage = knockout_1.default.observable("");
                    return _this;
                }
                ProcessingDialogModule.prototype.onReady = function (el) {
                    knockout_1.default.applyBindings(this, el);
                };
                ProcessingDialogModule.prototype.open = function (message, title, subTitle) {
                    var _this = this;
                    if (title === void 0) { title = "Processing dialog"; }
                    if (subTitle === void 0) { subTitle = ""; }
                    this.displayMessage(message);
                    var promise = new Promise(function (resolve, reject) {
                        _this.resolve = resolve;
                        var option = {
                            title: title,
                            subTitle: subTitle,
                            button1: {
                                id: "Button1",
                                label: _this.context.resources.getString("CLOSE_BUTTON"),
                                isPrimary: true,
                                onClick: _this.button1ClickHandler.bind(_this)
                            }
                        };
                        _this.openDialog(option);
                    });
                    return promise;
                };
                ProcessingDialogModule.prototype.button1ClickHandler = function () {
                    this.resolvePromise("Done");
                    this.closeDialog();
                    return true;
                };
                ProcessingDialogModule.prototype.resolvePromise = function (result) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.resolve)) {
                        this.resolve({
                            selectedValue: result
                        });
                        this.resolve = null;
                    }
                };
                return ProcessingDialogModule;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", ProcessingDialogModule);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Controls/DialogControl/ProcessingDialogModule.js.map