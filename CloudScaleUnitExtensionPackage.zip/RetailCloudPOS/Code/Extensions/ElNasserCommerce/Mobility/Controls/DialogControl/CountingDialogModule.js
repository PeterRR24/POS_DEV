System.register(["PosApi/Create/Dialogs", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, TypeExtensions_1, knockout_1, CountingDialogModule;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            CountingDialogModule = (function (_super) {
                __extends(CountingDialogModule, _super);
                function CountingDialogModule(showQuantity) {
                    var _this = _super.call(this) || this;
                    _this.quantity = knockout_1.default.observable("");
                    _this.itemName = knockout_1.default.observable("");
                    _this.comment = knockout_1.default.observable("");
                    _this.isShowQty = knockout_1.default.observable(showQuantity);
                    return _this;
                }
                CountingDialogModule.prototype.onReady = function (el) {
                    knockout_1.default.applyBindings(this, el);
                };
                CountingDialogModule.prototype.open = function (name, quantity, title) {
                    var _this = this;
                    this.itemName(name);
                    this.quantity(quantity);
                    var promise = new Promise(function (resolve, reject) {
                        _this.resolve = resolve;
                        var option = {
                            title: title,
                            subTitle: "",
                            onCloseX: _this.onCloseX.bind(_this),
                            button1: {
                                id: "Button1",
                                label: _this.context.resources.getString("OK_BUTTON"),
                                isPrimary: true,
                                onClick: _this.button1ClickHandler.bind(_this)
                            },
                            button2: {
                                id: "Button2",
                                label: _this.context.resources.getString("CANCEL_BUTTON"),
                                onClick: _this.button2ClickHandler.bind(_this)
                            }
                        };
                        _this.openDialog(option);
                    });
                    var self = this;
                    this.quantity.subscribe(function () {
                        self.enableOk();
                    });
                    this.comment.subscribe(function () {
                        self.enableOk();
                    });
                    if (quantity == "" && this.comment() == "") {
                        this.setButtonDisabledState("Button1", true);
                    }
                    else {
                        this.setButtonDisabledState("Button1", false);
                    }
                    return promise;
                };
                CountingDialogModule.prototype.closeDialogClicked = function () {
                    this.closeDialog();
                    this.resolvePromise("Closed");
                };
                CountingDialogModule.prototype.enableOkClicked = function () {
                    this.setButtonDisabledState("Button1", false);
                    this.resolvePromise("Closed");
                };
                CountingDialogModule.prototype.enableOk = function () {
                    var quantity = parseInt(this.quantity(), 10);
                    var isNotNumber = (this.quantity() != quantity.toString()) || isNaN(quantity) || quantity <= 0;
                    var noComment = this.comment().trim().length == 0;
                    if ((this.isShowQty() && isNotNumber) || (!this.isShowQty() && noComment)) {
                        this.setButtonDisabledState("Button1", true);
                    }
                    else {
                        this.setButtonDisabledState("Button1", false);
                    }
                    return true;
                };
                CountingDialogModule.prototype.onCloseX = function () {
                    this.resolvePromise("Closed");
                    return true;
                };
                CountingDialogModule.prototype.button1ClickHandler = function () {
                    this.resolvePromise("OK");
                    return true;
                };
                CountingDialogModule.prototype.button2ClickHandler = function () {
                    this.resolvePromise("Closed");
                    this.closeDialog();
                    return false;
                };
                CountingDialogModule.prototype.resolvePromise = function (result) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.resolve)) {
                        this.resolve({
                            quantity: parseInt(this.quantity()),
                            comment: this.comment(),
                            result: result
                        });
                        this.resolve = null;
                    }
                };
                return CountingDialogModule;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", CountingDialogModule);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Controls/DialogControl/CountingDialogModule.js.map