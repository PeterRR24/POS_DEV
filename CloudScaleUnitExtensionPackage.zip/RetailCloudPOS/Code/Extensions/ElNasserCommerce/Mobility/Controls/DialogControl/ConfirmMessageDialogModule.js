System.register(["PosApi/Create/Dialogs", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, TypeExtensions_1, knockout_1, ConfirmMessageDialogModule;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            ConfirmMessageDialogModule = (function (_super) {
                __extends(ConfirmMessageDialogModule, _super);
                function ConfirmMessageDialogModule() {
                    var _this = _super.call(this) || this;
                    _this.confirmMessage = knockout_1.default.observable("");
                    _this.userEnteredValue = knockout_1.default.observable("");
                    return _this;
                }
                ConfirmMessageDialogModule.prototype.onReady = function (el) {
                    knockout_1.default.applyBindings(this, el);
                };
                ConfirmMessageDialogModule.prototype.open = function (message, title, subTitle) {
                    var _this = this;
                    if (title === void 0) { title = "Confirmation dialog"; }
                    if (subTitle === void 0) { subTitle = ""; }
                    this.confirmMessage(message);
                    var promise = new Promise(function (resolve, reject) {
                        _this.resolve = resolve;
                        var option = {
                            title: title,
                            subTitle: subTitle,
                            onCloseX: _this.onCloseX.bind(_this),
                            button1: {
                                id: "Button1",
                                label: _this.context.resources.getString("YES_BUTTON"),
                                isPrimary: true,
                                onClick: _this.button1ClickHandler.bind(_this)
                            },
                            button2: {
                                id: "Button2",
                                label: _this.context.resources.getString("NO_BUTTON"),
                                onClick: _this.button2ClickHandler.bind(_this)
                            }
                        };
                        _this.openDialog(option);
                    });
                    this.setButtonDisabledState("Button1", false);
                    return promise;
                };
                ConfirmMessageDialogModule.prototype.onCloseX = function () {
                    this.resolvePromise("Closed");
                    return true;
                };
                ConfirmMessageDialogModule.prototype.button1ClickHandler = function () {
                    this.resolvePromise("Yes");
                    return true;
                };
                ConfirmMessageDialogModule.prototype.button2ClickHandler = function () {
                    this.resolvePromise("Closed");
                    this.closeDialog();
                    return false;
                };
                ConfirmMessageDialogModule.prototype.resolvePromise = function (result) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.resolve)) {
                        this.resolve({
                            selectedValue: result
                        });
                        this.resolve = null;
                    }
                };
                return ConfirmMessageDialogModule;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", ConfirmMessageDialogModule);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Controls/DialogControl/ConfirmMessageDialogModule.js.map