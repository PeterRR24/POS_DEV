System.register(["PosApi/Entities", "./DataServiceEntities.g", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, DataServiceEntities_g_1, DataService_1, StockTake;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            exports_1("Entities", DataServiceEntities_g_1.Entities);
            (function (StockTake) {
                var SearchJournalResponse = (function (_super) {
                    __extends(SearchJournalResponse, _super);
                    function SearchJournalResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SearchJournalResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.SearchJournalResponse = SearchJournalResponse;
                var SearchJournalRequest = (function (_super) {
                    __extends(SearchJournalRequest, _super);
                    function SearchJournalRequest(status, searchText) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "StockCount";
                        _this._method = "Search";
                        _this._parameters = { status: status, searchText: searchText };
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournal;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return SearchJournalRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.SearchJournalRequest = SearchJournalRequest;
                var AXJournalResponse = (function (_super) {
                    __extends(AXJournalResponse, _super);
                    function AXJournalResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return AXJournalResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.AXJournalResponse = AXJournalResponse;
                var AXJournalRequest = (function (_super) {
                    __extends(AXJournalRequest, _super);
                    function AXJournalRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'GetNewJournals';
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.StockCountJournalClass;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return AXJournalRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.AXJournalRequest = AXJournalRequest;
                var JournalImportResponse = (function (_super) {
                    __extends(JournalImportResponse, _super);
                    function JournalImportResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return JournalImportResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.JournalImportResponse = JournalImportResponse;
                var JournalImportRequest = (function (_super) {
                    __extends(JournalImportRequest, _super);
                    function JournalImportRequest(journalRequest) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'Import';
                        _this._parameters = { journal: journalRequest };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournal;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return JournalImportRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.JournalImportRequest = JournalImportRequest;
                var JournalCalculateResponse = (function (_super) {
                    __extends(JournalCalculateResponse, _super);
                    function JournalCalculateResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return JournalCalculateResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.JournalCalculateResponse = JournalCalculateResponse;
                var JournalCalculateRequest = (function (_super) {
                    __extends(JournalCalculateRequest, _super);
                    function JournalCalculateRequest(recordId, addLines) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'Calculate';
                        _this._parameters = { recordId: recordId, addLines: addLines };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return JournalCalculateRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.JournalCalculateRequest = JournalCalculateRequest;
                var JournalAdjustResponse = (function (_super) {
                    __extends(JournalAdjustResponse, _super);
                    function JournalAdjustResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return JournalAdjustResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.JournalAdjustResponse = JournalAdjustResponse;
                var JournalAdjustRequest = (function (_super) {
                    __extends(JournalAdjustRequest, _super);
                    function JournalAdjustRequest(recordId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'Adjust';
                        _this._parameters = { recordId: recordId };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return JournalAdjustRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.JournalAdjustRequest = JournalAdjustRequest;
                var DeleteJournalResponse = (function (_super) {
                    __extends(DeleteJournalResponse, _super);
                    function DeleteJournalResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return DeleteJournalResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.DeleteJournalResponse = DeleteJournalResponse;
                var DeleteJournalRequest = (function (_super) {
                    __extends(DeleteJournalRequest, _super);
                    function DeleteJournalRequest(journal) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "StockCount(" + journal.Id + ")";
                        _this._method = "DeleteJournal";
                        _this._parameters = {};
                        _this._isAction = true;
                        return _this;
                    }
                    return DeleteJournalRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.DeleteJournalRequest = DeleteJournalRequest;
                var JournalCommitResponse = (function (_super) {
                    __extends(JournalCommitResponse, _super);
                    function JournalCommitResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return JournalCommitResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.JournalCommitResponse = JournalCommitResponse;
                var JournalCommitRequest = (function (_super) {
                    __extends(JournalCommitRequest, _super);
                    function JournalCommitRequest(recordId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'Apply';
                        _this._parameters = { recordId: recordId };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournal;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return JournalCommitRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.JournalCommitRequest = JournalCommitRequest;
                var SearchJournalTransactionResponse = (function (_super) {
                    __extends(SearchJournalTransactionResponse, _super);
                    function SearchJournalTransactionResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SearchJournalTransactionResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.SearchJournalTransactionResponse = SearchJournalTransactionResponse;
                var SearchJournalTransactionRequest = (function (_super) {
                    __extends(SearchJournalTransactionRequest, _super);
                    function SearchJournalTransactionRequest(id, searchText) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "StockCount(" + id + ")";
                        _this._method = "SearchTransactions";
                        _this._parameters = { searchText: searchText };
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournalTransaction;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return SearchJournalTransactionRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.SearchJournalTransactionRequest = SearchJournalTransactionRequest;
                var CountTransactionResponse = (function (_super) {
                    __extends(CountTransactionResponse, _super);
                    function CountTransactionResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return CountTransactionResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.CountTransactionResponse = CountTransactionResponse;
                var CountTransactionRequest = (function (_super) {
                    __extends(CountTransactionRequest, _super);
                    function CountTransactionRequest(recordId, qtyCount, comment) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'CountTransaction';
                        _this._parameters = { recordId: recordId, qtyCount: qtyCount, comment: comment };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournalTransaction;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CountTransactionRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.CountTransactionRequest = CountTransactionRequest;
                var ClearTransactionResponse = (function (_super) {
                    __extends(ClearTransactionResponse, _super);
                    function ClearTransactionResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return ClearTransactionResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.ClearTransactionResponse = ClearTransactionResponse;
                var ClearTransactionRequest = (function (_super) {
                    __extends(ClearTransactionRequest, _super);
                    function ClearTransactionRequest(recordId, comment) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockCount';
                        _this._method = 'ClearTransaction';
                        _this._parameters = { recordId: recordId, comment: comment };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournalTransaction;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return ClearTransactionRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.ClearTransactionRequest = ClearTransactionRequest;
                var SearchSCJournalEntryResponse = (function (_super) {
                    __extends(SearchSCJournalEntryResponse, _super);
                    function SearchSCJournalEntryResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SearchSCJournalEntryResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.SearchSCJournalEntryResponse = SearchSCJournalEntryResponse;
                var SearchSCJournalEntryRequest = (function (_super) {
                    __extends(SearchSCJournalEntryRequest, _super);
                    function SearchSCJournalEntryRequest(id, searchText) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "StockCount(" + id + ")";
                        _this._method = "SearchEntries";
                        _this._parameters = { searchText: searchText };
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournalEntry;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return SearchSCJournalEntryRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.SearchSCJournalEntryRequest = SearchSCJournalEntryRequest;
                var SCJournalEntryResponse = (function (_super) {
                    __extends(SCJournalEntryResponse, _super);
                    function SCJournalEntryResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SCJournalEntryResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.SCJournalEntryResponse = SCJournalEntryResponse;
                var SCJournalEntryRequest = (function (_super) {
                    __extends(SCJournalEntryRequest, _super);
                    function SCJournalEntryRequest(id) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "StockCount";
                        _this._method = "GetEntries";
                        _this._parameters = { transId: id };
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.SCJournalEntry;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return SCJournalEntryRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.SCJournalEntryRequest = SCJournalEntryRequest;
                var DeleteSCJournalEntryResponse = (function (_super) {
                    __extends(DeleteSCJournalEntryResponse, _super);
                    function DeleteSCJournalEntryResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return DeleteSCJournalEntryResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.DeleteSCJournalEntryResponse = DeleteSCJournalEntryResponse;
                var DeleteSCJournalEntryRequest = (function (_super) {
                    __extends(DeleteSCJournalEntryRequest, _super);
                    function DeleteSCJournalEntryRequest(recIds) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "StockCount";
                        _this._method = "DeleteEntries";
                        _this._parameters = { recordIds: recIds };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return DeleteSCJournalEntryRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.DeleteSCJournalEntryRequest = DeleteSCJournalEntryRequest;
                var GetBarcodeForItemResponse = (function (_super) {
                    __extends(GetBarcodeForItemResponse, _super);
                    function GetBarcodeForItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetBarcodeForItemResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.GetBarcodeForItemResponse = GetBarcodeForItemResponse;
                var GetBarcodeForItemRequest = (function (_super) {
                    __extends(GetBarcodeForItemRequest, _super);
                    function GetBarcodeForItemRequest(barcodeItems) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetItemsBarcode";
                        _this._parameters = { barcodeItems: barcodeItems };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.BarcodeItem;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetBarcodeForItemRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.GetBarcodeForItemRequest = GetBarcodeForItemRequest;
                var GetStoreSectionsResponse = (function (_super) {
                    __extends(GetStoreSectionsResponse, _super);
                    function GetStoreSectionsResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetStoreSectionsResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.GetStoreSectionsResponse = GetStoreSectionsResponse;
                var GetStoreSectionsRequest = (function (_super) {
                    __extends(GetStoreSectionsRequest, _super);
                    function GetStoreSectionsRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetStoreSections";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.StoreSection;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetStoreSectionsRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.GetStoreSectionsRequest = GetStoreSectionsRequest;
                var GetStoreShelvesResponse = (function (_super) {
                    __extends(GetStoreShelvesResponse, _super);
                    function GetStoreShelvesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetStoreShelvesResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.GetStoreShelvesResponse = GetStoreShelvesResponse;
                var GetStoreShelvesRequest = (function (_super) {
                    __extends(GetStoreShelvesRequest, _super);
                    function GetStoreShelvesRequest(sectionId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetStoreShelves";
                        _this._parameters = { sectionId: sectionId };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.StoreShelf;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetStoreShelvesRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.GetStoreShelvesRequest = GetStoreShelvesRequest;
                var CountItemsResponse = (function (_super) {
                    __extends(CountItemsResponse, _super);
                    function CountItemsResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return CountItemsResponse;
                }(DataService_1.DataServiceResponse));
                StockTake.CountItemsResponse = CountItemsResponse;
                var CountItemsRequest = (function (_super) {
                    __extends(CountItemsRequest, _super);
                    function CountItemsRequest(items) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'StockTake';
                        _this._method = "CountOfflineItems";
                        _this._parameters = { stockTakeItems: items };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CountItemsRequest;
                }(DataService_1.DataServiceRequest));
                StockTake.CountItemsRequest = CountItemsRequest;
            })(StockTake || (exports_1("StockTake", StockTake = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/DataService2/DataServiceRequests.g.js.map