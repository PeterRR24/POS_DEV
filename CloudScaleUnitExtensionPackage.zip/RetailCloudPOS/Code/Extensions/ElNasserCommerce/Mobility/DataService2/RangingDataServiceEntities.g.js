System.register(["PosApi/Entities"], function (exports_1, context_1) {
    "use strict";
    var Entities_1, Entities;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            (function (Entities) {
                var StoreLocationItem = (function () {
                    function StoreLocationItem(odataObject) {
                        odataObject = odataObject || {};
                        this.Description = odataObject.Description;
                        this.DimColorId = odataObject.DimColorId;
                        this.DimConfigId = odataObject.DimConfigId;
                        this.DimSizeId = odataObject.DimSizeId;
                        this.DimStyleId = odataObject.DimStyleId;
                        this.InventDimId = odataObject.InventDimId;
                        this.ItemId = odataObject.ItemId;
                        this.Location = (odataObject.Location != null) ? parseInt(odataObject.Location, 10) : undefined;
                        this.FacingCount = (odataObject.FacingCount != null) ? parseInt(odataObject.FacingCount, 10) : undefined;
                        this.UnitId = odataObject.UnitId;
                        this.VariantId = odataObject.VariantId;
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreLocationItem;
                }());
                Entities.StoreLocationItem = StoreLocationItem;
                var StoreSection = (function () {
                    function StoreSection(odataObject) {
                        odataObject = odataObject || {};
                        this.SectionId = odataObject.SectionId;
                        this.SectionName = odataObject.SectionName;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreSection;
                }());
                Entities.StoreSection = StoreSection;
                var StoreShelf = (function () {
                    function StoreShelf(odataObject) {
                        odataObject = odataObject || {};
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.SectionName = odataObject.SectionName;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreShelf;
                }());
                Entities.StoreShelf = StoreShelf;
                var UtilitiesConfiguration = (function () {
                    function UtilitiesConfiguration(odataObject) {
                        odataObject = odataObject || {};
                        this.RangingWithFaces = (odataObject.RangingWithFaces != null) ? parseInt(odataObject.RangingWithFaces, 10) : undefined;
                        this.LabelHierarchyRecId = (odataObject.LabelHierarchyRecId != null) ? parseInt(odataObject.LabelHierarchyRecId, 10) : undefined;
                        this.DefaultLabelProfileRecId = (odataObject.DefaultLabelProfileRecId != null) ? parseInt(odataObject.DefaultLabelProfileRecId, 10) : undefined;
                        this.FireSaleBarcodePrefix = odataObject.FireSaleBarcodePrefix;
                        this.LabelCurrencyCode = odataObject.LabelCurrencyCode;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return UtilitiesConfiguration;
                }());
                Entities.UtilitiesConfiguration = UtilitiesConfiguration;
                var RetailServerError = (function () {
                    function RetailServerError() {
                    }
                    return RetailServerError;
                }());
                Entities.RetailServerError = RetailServerError;
            })(Entities || (exports_1("Entities", Entities = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/DataService2/RangingDataServiceEntities.g.js.map