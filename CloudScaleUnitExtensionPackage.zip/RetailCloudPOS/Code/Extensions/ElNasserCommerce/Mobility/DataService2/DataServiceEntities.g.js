System.register(["PosApi/Entities"], function (exports_1, context_1) {
    "use strict";
    var Entities_1, Entities;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            (function (Entities) {
                var SCJournalStatus;
                (function (SCJournalStatus) {
                    SCJournalStatus[SCJournalStatus["Open"] = 0] = "Open";
                    SCJournalStatus[SCJournalStatus["Committed"] = 1] = "Committed";
                })(SCJournalStatus = Entities.SCJournalStatus || (Entities.SCJournalStatus = {}));
                var SCJournalCalculation;
                (function (SCJournalCalculation) {
                    SCJournalCalculation[SCJournalCalculation["Default"] = 0] = "Default";
                    SCJournalCalculation[SCJournalCalculation["EmptyAsDiscrepant"] = 1] = "EmptyAsDiscrepant";
                    SCJournalCalculation[SCJournalCalculation["NegativeAsDiscrepant"] = 2] = "NegativeAsDiscrepant";
                })(SCJournalCalculation = Entities.SCJournalCalculation || (Entities.SCJournalCalculation = {}));
                var SCJournalLocation;
                (function (SCJournalLocation) {
                    SCJournalLocation[SCJournalLocation["Store"] = 0] = "Store";
                    SCJournalLocation[SCJournalLocation["Section"] = 1] = "Section";
                    SCJournalLocation[SCJournalLocation["Shelf"] = 2] = "Shelf";
                })(SCJournalLocation = Entities.SCJournalLocation || (Entities.SCJournalLocation = {}));
                var SCJournalEntryStatus;
                (function (SCJournalEntryStatus) {
                    SCJournalEntryStatus[SCJournalEntryStatus["Open"] = 0] = "Open";
                    SCJournalEntryStatus[SCJournalEntryStatus["Counted"] = 1] = "Counted";
                    SCJournalEntryStatus[SCJournalEntryStatus["Missing"] = 2] = "Missing";
                    SCJournalEntryStatus[SCJournalEntryStatus["Skipped"] = 3] = "Skipped";
                })(SCJournalEntryStatus = Entities.SCJournalEntryStatus || (Entities.SCJournalEntryStatus = {}));
                var SCJournalTransStatus;
                (function (SCJournalTransStatus) {
                    SCJournalTransStatus[SCJournalTransStatus["Default"] = 0] = "Default";
                })(SCJournalTransStatus = Entities.SCJournalTransStatus || (Entities.SCJournalTransStatus = {}));
                var StockTakeJournal = (function () {
                    function StockTakeJournal(odataObject) {
                        odataObject = odataObject || {};
                        this.Id = (odataObject.Id != null) ? parseInt(odataObject.Id, 10) : undefined;
                        this.JournalId = odataObject.JournalId;
                        this.Description = odataObject.Description;
                        this.CalcMode = odataObject.CalcMode;
                        this.LocationMode = odataObject.LocationMode;
                        this.CreatedDate = (odataObject.CreatedDate instanceof Date) ? odataObject.CreatedDate
                            : (odataObject.CreatedDate != null) ? odataObject.CreatedDate : undefined;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StockTakeJournal;
                }());
                Entities.StockTakeJournal = StockTakeJournal;
                var StockTakeItem = (function () {
                    function StockTakeItem(odataObject) {
                        odataObject = odataObject || {};
                        this.JournalId = (odataObject.JournalId != null) ? parseInt(odataObject.JournalId, 10) : undefined;
                        this.ItemId = odataObject.ItemId;
                        this.ItemName = odataObject.ItemName;
                        this.Unit = odataObject.Unit;
                        this.InventBatchId = odataObject.InventBatchId;
                        this.InventSerialId = odataObject.InventSerialId;
                        this.InventSizeId = odataObject.InventSizeId;
                        this.InventColorId = odataObject.InventColorId;
                        this.InventStyleId = odataObject.InventStyleId;
                        this.ConfigId = odataObject.ConfigId;
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.Counted = (odataObject.Counted != null) ? parseFloat(odataObject.Counted) : undefined;
                        this.JournalInfo = (odataObject.JournalInfo != null) ? parseInt(odataObject.JournalInfo, 10) : undefined;
                        this.TrackingInfo = (odataObject.Id != null) ? parseInt(odataObject.TrackingInfo, 10) : undefined;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StockTakeItem;
                }());
                Entities.StockTakeItem = StockTakeItem;
                var SCJournal = (function () {
                    function SCJournal(odataObject) {
                        odataObject = odataObject || {};
                        this.RecordId = (odataObject.RecordId != null) ? parseInt(odataObject.RecordId, 10) : undefined;
                        this.Id = (odataObject.Id != null) ? parseInt(odataObject.Id, 10) : undefined;
                        this.JournalId = odataObject.JournalId;
                        this.Description = odataObject.Description;
                        this.StoreId = odataObject.StoreId;
                        this.InventLocationId = odataObject.InventLocationId;
                        this.DimSetup = (odataObject.DimSetup != null) ? parseInt(odataObject.DimSetup, 10) : undefined;
                        this.CalcModeValue = (odataObject.CalcModeValue != null) ? parseInt(odataObject.CalcModeValue, 10) : undefined;
                        this.CalcMode = SCJournalCalculation[this.CalcModeValue];
                        this.LocationModeValue = (odataObject.LocationModeValue != null) ? parseInt(odataObject.LocationModeValue, 10) : undefined;
                        this.LocationMode = SCJournalLocation[this.LocationModeValue];
                        this.StatusValue = (odataObject.StatusValue != null) ? parseInt(odataObject.StatusValue, 10) : undefined;
                        this.Status = SCJournalStatus[this.StatusValue];
                        this.StaffId = odataObject.StaffId;
                        this.CreatedDate = (odataObject.CreatedDate instanceof Date) ? new Date(odataObject.CreatedDate)
                            : (odataObject.CreatedDate != null) ? new Date(odataObject.CreatedDate) : undefined;
                        this.AdjustDate = (odataObject.AdjustDate instanceof Date) ? odataObject.AdjustDate
                            : (odataObject.AdjustDate != null) ? odataObject.AdjustDate : undefined;
                        this.CommitDate = (odataObject.CommitDate instanceof Date) ? new Date(odataObject.CommitDate)
                            : (odataObject.CommitDate != null) ? new Date(odataObject.CommitDate) : undefined;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return SCJournal;
                }());
                Entities.SCJournal = SCJournal;
                var SCJournalEntry = (function () {
                    function SCJournalEntry(odataObject) {
                        odataObject = odataObject || {};
                        this.Id = (odataObject.Id != null) ? parseInt(odataObject.Id, 10) : undefined;
                        this.JournalId = (odataObject.JournalId != null) ? parseInt(odataObject.JournalId, 10) : undefined;
                        this.ItemId = odataObject.ItemId;
                        this.Unit = odataObject.Unit;
                        this.InventSizeId = odataObject.InventSizeId;
                        this.InventColorId = odataObject.InventColorId;
                        this.InventStyleId = odataObject.InventStyleId;
                        this.ConfigId = odataObject.ConfigId;
                        this.InventBatchId = odataObject.InventBatchId;
                        this.InventSerialId = odataObject.InventSerialId;
                        this.DeviceId = odataObject.DeviceId;
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.QtyCount = (odataObject.QtyCount != null) ? parseFloat(odataObject.QtyCount) : undefined;
                        this.StatusValue = (odataObject.StatusValue != null) ? parseInt(odataObject.StatusValue, 10) : undefined;
                        this.Status = SCJournalEntryStatus[this.StatusValue];
                        this.TransactionId = (odataObject.TransactionId != null) ? parseInt(odataObject.TransactionId, 10) : undefined;
                        this.CountedDate = (odataObject.CountedDate instanceof Date) ? new Date(odataObject.CountedDate)
                            : (odataObject.CountedDate != null) ? new Date(odataObject.CountedDate) : undefined;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return SCJournalEntry;
                }());
                Entities.SCJournalEntry = SCJournalEntry;
                var SCJournalTransaction = (function () {
                    function SCJournalTransaction(odataObject) {
                        odataObject = odataObject || {};
                        this.Id = (odataObject.Id != null) ? parseInt(odataObject.Id, 10) : undefined;
                        this.RecordId = (odataObject.RecordId != null) ? parseInt(odataObject.RecordId, 10) : undefined;
                        this.JournalId = (odataObject.JournalId != null) ? parseInt(odataObject.JournalId, 10) : undefined;
                        this.ItemId = odataObject.ItemId;
                        this.ItemName = odataObject.ItemName;
                        this.Unit = odataObject.Unit;
                        this.Barcode = odataObject.Barcode;
                        this.InventDimId = odataObject.InventDimId;
                        this.InventBatchId = odataObject.InventBatchId;
                        this.InventSerialId = odataObject.InventSerialId;
                        this.InventSizeId = odataObject.InventSizeId;
                        this.InventColorId = odataObject.InventColorId;
                        this.InventStyleId = odataObject.InventStyleId;
                        this.ConfigId = odataObject.ConfigId;
                        this.StatusValue = (odataObject.StatusValue != null) ? parseInt(odataObject.StatusValue, 10) : undefined;
                        this.Status = SCJournalStatus[this.StatusValue];
                        this.Quantity = (odataObject.Quantity != null) ? parseFloat(odataObject.Quantity) : undefined;
                        this.QtyAdjust = (odataObject.QtyAdjust != null) ? parseFloat(odataObject.QtyAdjust) : undefined;
                        this.QtyEntry = (odataObject.QtyEntry != null) ? parseFloat(odataObject.QtyEntry) : undefined;
                        this.QtyCount = (odataObject.QtyCount != null) ? parseFloat(odataObject.QtyCount) : undefined;
                        this.Comment = odataObject.Comment;
                        this.CountedDate = (odataObject.CountedDate instanceof Date) ? new Date(odataObject.CountedDate)
                            : (odataObject.CountedDate != null) ? new Date(odataObject.CountedDate) : undefined;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return SCJournalTransaction;
                }());
                Entities.SCJournalTransaction = SCJournalTransaction;
                var SCJournalRequest = (function () {
                    function SCJournalRequest(odataObject) {
                        odataObject = odataObject || {};
                        this.CalcMode = (odataObject.CalcMode != null) ? parseInt(odataObject.CalcMode, 10) : undefined;
                        this.LocationMode = (odataObject.LocationMode != null) ? parseInt(odataObject.LocationMode, 10) : undefined;
                        this.RecordId = odataObject.RecordId;
                        this.JournalId = odataObject.JournalId;
                        this.Description = odataObject.Description;
                    }
                    return SCJournalRequest;
                }());
                Entities.SCJournalRequest = SCJournalRequest;
                var StoreSection = (function () {
                    function StoreSection(odataObject) {
                        odataObject = odataObject || {};
                        this.SectionId = odataObject.SectionId;
                        this.SectionName = odataObject.SectionName;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreSection;
                }());
                Entities.StoreSection = StoreSection;
                var StoreShelf = (function () {
                    function StoreShelf(odataObject) {
                        odataObject = odataObject || {};
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.SectionName = odataObject.SectionName;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreShelf;
                }());
                Entities.StoreShelf = StoreShelf;
                var BarcodeItem = (function () {
                    function BarcodeItem(odataObject) {
                        this.RecordId = (odataObject.RecordId != null) ? parseInt(odataObject.RecordId, 10) : undefined;
                        this.ItemId = odataObject.ItemId;
                        this.InventDimId = odataObject.InventDimId;
                        this.UnitId = odataObject.UnitId;
                        this.Barcode = odataObject.Barcode;
                    }
                    return BarcodeItem;
                }());
                Entities.BarcodeItem = BarcodeItem;
                var RetailServerError = (function () {
                    function RetailServerError() {
                    }
                    return RetailServerError;
                }());
                Entities.RetailServerError = RetailServerError;
            })(Entities || (exports_1("Entities", Entities = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/DataService2/DataServiceEntities.g.js.map