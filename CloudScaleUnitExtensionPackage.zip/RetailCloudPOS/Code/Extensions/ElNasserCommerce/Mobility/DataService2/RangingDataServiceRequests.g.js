System.register(["PosApi/Entities", "./RangingDataServiceEntities.g", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, RangingDataServiceEntities_g_1, DataService_1, Ranging;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (RangingDataServiceEntities_g_1_1) {
                RangingDataServiceEntities_g_1 = RangingDataServiceEntities_g_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            exports_1("Entities", RangingDataServiceEntities_g_1.Entities);
            (function (Ranging) {
                var SelectLocationItemResponse = (function (_super) {
                    __extends(SelectLocationItemResponse, _super);
                    function SelectLocationItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SelectLocationItemResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.SelectLocationItemResponse = SelectLocationItemResponse;
                var SelectLocationItemRequest = (function (_super) {
                    __extends(SelectLocationItemRequest, _super);
                    function SelectLocationItemRequest(sectionId, shelfId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Placement";
                        _this._method = "Select";
                        _this._parameters = { sectionId: sectionId, shelfId: shelfId };
                        _this._isAction = false;
                        _this._returnType = RangingDataServiceEntities_g_1.Entities.StoreLocationItem;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return SelectLocationItemRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.SelectLocationItemRequest = SelectLocationItemRequest;
                var ClearLocationItemResponse = (function (_super) {
                    __extends(ClearLocationItemResponse, _super);
                    function ClearLocationItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return ClearLocationItemResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.ClearLocationItemResponse = ClearLocationItemResponse;
                var ClearLocationItemRequest = (function (_super) {
                    __extends(ClearLocationItemRequest, _super);
                    function ClearLocationItemRequest(sectionId, shelfId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'Placement';
                        _this._method = 'Clear';
                        _this._parameters = { sectionId: sectionId, shelfId: shelfId };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return ClearLocationItemRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.ClearLocationItemRequest = ClearLocationItemRequest;
                var CommitLocationItemResponse = (function (_super) {
                    __extends(CommitLocationItemResponse, _super);
                    function CommitLocationItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return CommitLocationItemResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.CommitLocationItemResponse = CommitLocationItemResponse;
                var CommitLocationItemRequest = (function (_super) {
                    __extends(CommitLocationItemRequest, _super);
                    function CommitLocationItemRequest(sectionId, shelfId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'Placement';
                        _this._method = 'Commit';
                        _this._parameters = { sectionId: sectionId, shelfId: shelfId };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CommitLocationItemRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.CommitLocationItemRequest = CommitLocationItemRequest;
                var PlaceLocationItemResponse = (function (_super) {
                    __extends(PlaceLocationItemResponse, _super);
                    function PlaceLocationItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return PlaceLocationItemResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.PlaceLocationItemResponse = PlaceLocationItemResponse;
                var PlaceLocationItemRequest = (function (_super) {
                    __extends(PlaceLocationItemRequest, _super);
                    function PlaceLocationItemRequest(sectionId, shelfId, location, itemId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'Placement';
                        _this._method = 'Place';
                        _this._parameters = { sectionId: sectionId, shelfId: shelfId, location: location, itemId: itemId };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return PlaceLocationItemRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.PlaceLocationItemRequest = PlaceLocationItemRequest;
                var RemoveLocationItemResponse = (function (_super) {
                    __extends(RemoveLocationItemResponse, _super);
                    function RemoveLocationItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return RemoveLocationItemResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.RemoveLocationItemResponse = RemoveLocationItemResponse;
                var RemoveLocationItemRequest = (function (_super) {
                    __extends(RemoveLocationItemRequest, _super);
                    function RemoveLocationItemRequest(sectionId, shelfId, location) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'Placement';
                        _this._method = 'Remove';
                        _this._parameters = { sectionId: sectionId, shelfId: shelfId, location: location };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return RemoveLocationItemRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.RemoveLocationItemRequest = RemoveLocationItemRequest;
                var MoveLocationItemResponse = (function (_super) {
                    __extends(MoveLocationItemResponse, _super);
                    function MoveLocationItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return MoveLocationItemResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.MoveLocationItemResponse = MoveLocationItemResponse;
                var MoveLocationItemRequest = (function (_super) {
                    __extends(MoveLocationItemRequest, _super);
                    function MoveLocationItemRequest(sectionId, shelfId, oldLocation, newLocation) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'Placement';
                        _this._method = 'Move';
                        _this._parameters = { sectionId: sectionId, shelfId: shelfId, oldLocation: oldLocation, newLocation: newLocation };
                        _this._isAction = true;
                        _this._returnType = '';
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return MoveLocationItemRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.MoveLocationItemRequest = MoveLocationItemRequest;
                var GetStoreSectionsResponse = (function (_super) {
                    __extends(GetStoreSectionsResponse, _super);
                    function GetStoreSectionsResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetStoreSectionsResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.GetStoreSectionsResponse = GetStoreSectionsResponse;
                var GetStoreSectionsRequest = (function (_super) {
                    __extends(GetStoreSectionsRequest, _super);
                    function GetStoreSectionsRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetStoreSections";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = RangingDataServiceEntities_g_1.Entities.StoreSection;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetStoreSectionsRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.GetStoreSectionsRequest = GetStoreSectionsRequest;
                var GetStoreShelvesResponse = (function (_super) {
                    __extends(GetStoreShelvesResponse, _super);
                    function GetStoreShelvesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetStoreShelvesResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.GetStoreShelvesResponse = GetStoreShelvesResponse;
                var GetStoreShelvesRequest = (function (_super) {
                    __extends(GetStoreShelvesRequest, _super);
                    function GetStoreShelvesRequest(sectionId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetStoreShelves";
                        _this._parameters = { sectionId: sectionId };
                        _this._isAction = true;
                        _this._returnType = RangingDataServiceEntities_g_1.Entities.StoreShelf;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetStoreShelvesRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.GetStoreShelvesRequest = GetStoreShelvesRequest;
                var UtilitiesConfigurationResponse = (function (_super) {
                    __extends(UtilitiesConfigurationResponse, _super);
                    function UtilitiesConfigurationResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return UtilitiesConfigurationResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.UtilitiesConfigurationResponse = UtilitiesConfigurationResponse;
                var UtilitiesConfigurationRequest = (function (_super) {
                    __extends(UtilitiesConfigurationRequest, _super);
                    function UtilitiesConfigurationRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetUtilitiesConfiguration";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = RangingDataServiceEntities_g_1.Entities.UtilitiesConfiguration;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return UtilitiesConfigurationRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.UtilitiesConfigurationRequest = UtilitiesConfigurationRequest;
                var UpdateCartLinesResponse = (function (_super) {
                    __extends(UpdateCartLinesResponse, _super);
                    function UpdateCartLinesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return UpdateCartLinesResponse;
                }(DataService_1.DataServiceResponse));
                Ranging.UpdateCartLinesResponse = UpdateCartLinesResponse;
                var UpdateCartLinesRequest = (function (_super) {
                    __extends(UpdateCartLinesRequest, _super);
                    function UpdateCartLinesRequest(cartID, cartLines, cartVersion) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Carts";
                        _this._entityType = "Cart";
                        _this._keys = { Id: cartID };
                        _this._method = "UpdateCartLines";
                        _this._parameters = { cartLines: cartLines, cartVersion: cartVersion };
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.CartClass;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return UpdateCartLinesRequest;
                }(DataService_1.DataServiceRequest));
                Ranging.UpdateCartLinesRequest = UpdateCartLinesRequest;
            })(Ranging || (exports_1("Ranging", Ranging = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/DataService2/RangingDataServiceRequests.g.js.map