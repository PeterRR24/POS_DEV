System.register(["knockout", "PosApi/Create/Views", "PosApi/Consume/Controls", "./SCJournalEntryViewModel", "../Controls/DialogControl/ConfirmMessageDialogModule", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, Controls_1, SCJournalEntryViewModel_1, ConfirmMessageDialogModule_1, TypeExtensions_1, ScJournalEntryView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (Controls_1_1) {
                Controls_1 = Controls_1_1;
            },
            function (SCJournalEntryViewModel_1_1) {
                SCJournalEntryViewModel_1 = SCJournalEntryViewModel_1_1;
            },
            function (ConfirmMessageDialogModule_1_1) {
                ConfirmMessageDialogModule_1 = ConfirmMessageDialogModule_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            ScJournalEntryView = (function (_super) {
                __extends(ScJournalEntryView, _super);
                function ScJournalEntryView(context, options) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("STOCK_TAKE_ENTRY_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "deleteEntry",
                                    label: 'Delete',
                                    icon: NewView.Icons.Delete,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.DeleteOperation();
                                    }
                                }
                            ]
                        }
                    }) || this;
                    _this._context = context;
                    _this.viewModel = new SCJournalEntryViewModel_1.default(context, options);
                    return _this;
                }
                ScJournalEntryView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var dataListOptions = {
                        interactionMode: Controls_1.DataListInteractionMode.MultiSelect,
                        data: this.viewModel.searchJournalEntry,
                        columns: [
                            {
                                title: this._context.resources.getString("ITEM_ID"),
                                ratio: 7,
                                collapseOrder: 10,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.ItemId; }
                            },
                            {
                                title: this._context.resources.getString("SECTION"),
                                ratio: 10,
                                collapseOrder: 11,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.SectionId; }
                            },
                            {
                                title: this._context.resources.getString("SHELF"),
                                ratio: 10,
                                collapseOrder: 12,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.ShelfId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_CONFIG"),
                                ratio: 7,
                                collapseOrder: 1,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.ConfigId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_SIZE"),
                                ratio: 7,
                                collapseOrder: 2,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.InventSizeId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_COLOR"),
                                ratio: 7,
                                collapseOrder: 3,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.InventColorId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_STYLE"),
                                ratio: 7,
                                collapseOrder: 4,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.InventStyleId; }
                            },
                            {
                                title: this._context.resources.getString("UNIT"),
                                ratio: 5,
                                collapseOrder: 5,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.Unit; }
                            },
                            {
                                title: this._context.resources.getString("STATUS"),
                                ratio: 10,
                                collapseOrder: 6,
                                minWidth: 80,
                                computeValue: function (rowData) { return rowData.Status; }
                            },
                            {
                                title: this._context.resources.getString("QUANTITY_COUNT"),
                                ratio: 10,
                                collapseOrder: 7,
                                minWidth: 80,
                                computeValue: function (rowData) { return rowData.QtyCount == undefined ? "" : Number(rowData.QtyCount).toFixed(2); }
                            },
                            {
                                title: this._context.resources.getString("COUNT_DATE"),
                                ratio: 10,
                                collapseOrder: 8,
                                minWidth: 80,
                                computeValue: function (rowData) { return rowData.CountedDate == undefined ? "" : rowData.CountedDate.toLocaleDateString(); }
                            },
                            {
                                title: this._context.resources.getString("DEVICE_ID"),
                                ratio: 10,
                                collapseOrder: 9,
                                minWidth: 80,
                                computeValue: function (rowData) { return rowData.DeviceId; }
                            }
                        ]
                    };
                    var dataListRootElem = element.querySelector("#listScJournalEntryview");
                    this.dataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DataList", dataListOptions, dataListRootElem);
                    this.dataList.addEventListener("SelectionChanged", function (eventData) {
                        _this.viewModel.setSelectedItems(eventData.items);
                        _this.state.commandBar.commands.forEach(function (command) { return command.canExecute = _this.viewModel.enableDelete(); });
                    });
                    this.state.isProcessing = true;
                    this.viewModel.searchSCJournalEntries().then(function () {
                        _this.dataList.data = _this.viewModel.searchJournalEntry();
                        _this.state.isProcessing = false;
                    });
                    this.viewModel.refreshListHandler = (function () {
                        _this.RefreshList();
                    });
                };
                ScJournalEntryView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                ScJournalEntryView.prototype.RefreshList = function () {
                    this.dataList.data = this.viewModel.searchJournalEntry();
                };
                ScJournalEntryView.prototype.searchClickHandler = function () {
                    this.viewModel.searchSCJournalEntries();
                };
                ScJournalEntryView.prototype.DeleteOperation = function () {
                    var _this = this;
                    var dialog = new ConfirmMessageDialogModule_1.default();
                    dialog.open(this._context.resources.getString("CONFIRM_DELETE_JOURNAL_ENTRY"))
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            _this.viewModel.deleteSCJournalEntries();
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("ScJournalEntryView deleteOperation confirmation error: " + JSON.stringify(reason));
                    });
                };
                return ScJournalEntryView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", ScJournalEntryView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/SCJournalEntryView.js.map