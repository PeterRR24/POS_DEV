System.register(["knockout", "PosApi/Create/Views", "PosApi/Consume/Controls", "./ItemStoreLocationViewModel", "../Controls/DialogControl/ClearCommitOptionsDialogModule", "../Controls/DialogControl/ConfirmMessageDialogModule", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, Controls_1, ItemStoreLocationViewModel_1, ClearCommitOptionsDialogModule_1, ConfirmMessageDialogModule_1, TypeExtensions_1, ItemStoreLocationView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (Controls_1_1) {
                Controls_1 = Controls_1_1;
            },
            function (ItemStoreLocationViewModel_1_1) {
                ItemStoreLocationViewModel_1 = ItemStoreLocationViewModel_1_1;
            },
            function (ClearCommitOptionsDialogModule_1_1) {
                ClearCommitOptionsDialogModule_1 = ClearCommitOptionsDialogModule_1_1;
            },
            function (ConfirmMessageDialogModule_1_1) {
                ConfirmMessageDialogModule_1 = ConfirmMessageDialogModule_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            ItemStoreLocationView = (function (_super) {
                __extends(ItemStoreLocationView, _super);
                function ItemStoreLocationView(context, options) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("RANGING_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "commitLocations",
                                    label: context.resources.getString('UPDATE_HQ_BUTTON'),
                                    icon: NewView.Icons.Accept,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.CommitOperation();
                                    }
                                },
                                {
                                    name: "clearLocations",
                                    label: 'Clear',
                                    icon: NewView.Icons.Cancel,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.ClearOperation();
                                    }
                                },
                                {
                                    name: "moveDownItem",
                                    label: context.resources.getString('MOVE_DOWN_BUTTON'),
                                    icon: NewView.Icons.PreviewPrevious,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.MoveOperation.bind(_this, 'down');
                                    }
                                },
                                {
                                    name: "moveUpItem",
                                    label: context.resources.getString('MOVE_UP_BUTTON'),
                                    icon: NewView.Icons.PreviewNext,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.MoveOperation.bind(_this, 'up');
                                    }
                                },
                                {
                                    name: "removeItem",
                                    label: context.resources.getString('REMOVE_BUTTON'),
                                    icon: NewView.Icons.Delete,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.RemoveOperation();
                                    }
                                },
                                {
                                    name: "printFacingReport",
                                    label: context.resources.getString('PRINT_REPORT_BUTTON'),
                                    icon: NewView.Icons.Invoice,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.PrintingOperation();
                                    }
                                }
                            ]
                        }
                    }) || this;
                    _this._context = context;
                    var isFacing = options.isFaceing == 1;
                    _this.viewModel = new ItemStoreLocationViewModel_1.default(context, options);
                    _this.listColumn = knockout_1.default.observableArray([]);
                    _this.showFaces = knockout_1.default.observable(false);
                    _this.showFaces(isFacing);
                    if (isFacing) {
                        _this.listColumn(_this.ColumnsWithFaces());
                    }
                    else {
                        _this.listColumn(_this.ColumnsWithoutFaces());
                    }
                    return _this;
                }
                ItemStoreLocationView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var dataListOptions = {
                        interactionMode: Controls_1.DataListInteractionMode.SingleSelect,
                        data: this.viewModel.storeLocationItems(),
                        columns: this.listColumn()
                    };
                    var dataListRootElem = element.querySelector("#listItemStoreLocation");
                    this.dataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DataList", dataListOptions, dataListRootElem);
                    this.dataList.addEventListener("SelectionChanged", function (eventData) {
                        _this.viewModel.setSelectedItem(eventData.items);
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'clearLocations'; }).canExecute = _this.viewModel.enableClear();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'commitLocations'; }).canExecute = _this.viewModel.enableCommit();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'moveDownItem'; }).canExecute = _this.viewModel.enableMoveDown();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'moveUpItem'; }).canExecute = _this.viewModel.enableMoveUp();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'removeItem'; }).canExecute = _this.viewModel.enableRemove();
                    });
                    this.viewModel.refreshListHandler = (function () {
                        _this.RefreshList();
                    });
                };
                ItemStoreLocationView.prototype.RefreshList = function () {
                    this.dataList.data = this.viewModel.storeLocationItems();
                };
                ItemStoreLocationView.prototype.ColumnsWithFaces = function () {
                    var columns = [];
                    columns = [
                        {
                            title: this._context.resources.getString("LOCATION"),
                            ratio: 15,
                            collapseOrder: 3,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.Location; }
                        },
                        {
                            title: this._context.resources.getString("ITEM_ID"),
                            ratio: 20,
                            collapseOrder: 4,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.ItemId; }
                        },
                        {
                            title: this._context.resources.getString("ITEM_DESCRIPTION"),
                            ratio: 35,
                            collapseOrder: 2,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.Description; }
                        },
                        {
                            title: this._context.resources.getString("UNIT"),
                            ratio: 10,
                            collapseOrder: 1,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.UnitId; }
                        },
                        {
                            title: this._context.resources.getString("FACES"),
                            ratio: 20,
                            collapseOrder: 5,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.FacingCount; }
                        }
                    ];
                    return columns;
                };
                ItemStoreLocationView.prototype.ColumnsWithoutFaces = function () {
                    var columns = [];
                    columns = [
                        {
                            title: this._context.resources.getString("LOCATION"),
                            ratio: 20,
                            collapseOrder: 3,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.Location; }
                        },
                        {
                            title: this._context.resources.getString("ITEM_ID"),
                            ratio: 20,
                            collapseOrder: 4,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.ItemId; }
                        },
                        {
                            title: this._context.resources.getString("ITEM_DESCRIPTION"),
                            ratio: 45,
                            collapseOrder: 2,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.Description; }
                        },
                        {
                            title: this._context.resources.getString("UNIT"),
                            ratio: 15,
                            collapseOrder: 1,
                            minWidth: 50,
                            computeValue: function (rowData) { return rowData.UnitId; }
                        }
                    ];
                    return columns;
                };
                ItemStoreLocationView.prototype.onShown = function () {
                    $('.rootCategory').on('click', 'ul.category label', function (self, evt) {
                        $('.rootCategory > .product > ul.category label').removeClass('accentBackground');
                        $(self.currentTarget).addClass("accentBackground");
                    });
                };
                ItemStoreLocationView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                ItemStoreLocationView.prototype.LocationClickHandler = function (self, data, element) {
                    self.viewModel.sectionId(data.SectionId == undefined ? "" : data.SectionId);
                    self.viewModel.shelfId(data.ShelfId == undefined ? "" : data.ShelfId);
                    self.viewModel.searchStoreLacationItems();
                };
                ItemStoreLocationView.prototype.PlaceOperation = function () {
                    this.viewModel.placeItemLocations(0, "");
                };
                ItemStoreLocationView.prototype.ClearOperation = function () {
                    var _this = this;
                    var dialog = new ClearCommitOptionsDialogModule_1.default(this.viewModel.shelfId());
                    dialog.open(this._context.resources.getString("CLEAR_LOCATION_OPTION_SELECT_MESSAGE"), this._context.resources.getString("CLEAR_LOCATION_OPTIONS_DIALOG_TITLE"))
                        .then(function (result) {
                        if (result.selectedValue !== '0') {
                            if (result.selectedValue == "1")
                                _this.viewModel.clearLocations(result.selectedValue);
                            else {
                                var confirmDialog = new ConfirmMessageDialogModule_1.default();
                                confirmDialog.open(_this._context.resources.getString("CONFIRM_CLEAR_LOCATION"))
                                    .then(function (confirmResult) {
                                    if (confirmResult.selectedValue == "Yes") {
                                        _this.viewModel.clearLocations(result.selectedValue);
                                    }
                                }).catch(function (reason) {
                                    _this._context.logger.logError("ItemStoreLocationView clearOperation options: " + JSON.stringify(reason));
                                });
                            }
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("ItemStoreLocationView clearOperation options: " + JSON.stringify(reason));
                    });
                };
                ItemStoreLocationView.prototype.CommitOperation = function () {
                    var _this = this;
                    var dialog1 = new ClearCommitOptionsDialogModule_1.default(this.viewModel.shelfId());
                    dialog1.open(this._context.resources.getString("COMMIT_LOCATION_OPTION_SELECT_MESSAGE"), this._context.resources.getString("COMMIT_LOCATION_OPTIONS_DIALOG_TITLE"))
                        .then(function (result) {
                        if (result.selectedValue !== '0') {
                            _this.viewModel.commitOption("");
                            _this.viewModel.commitOption(result.selectedValue);
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("ItemStoreLocationView commitOperation options: " + JSON.stringify(reason));
                    });
                };
                ItemStoreLocationView.prototype.MoveOperation = function (self, option) {
                    self.viewModel.moveLocations(option);
                };
                ItemStoreLocationView.prototype.RemoveOperation = function () {
                    var _this = this;
                    var msg = TypeExtensions_1.StringExtensions.format(this._context.resources.getString("CONFIRM_REMOVE_LOCATION"), this.viewModel.selectedLocationItem().Description);
                    var confirmDialog = new ConfirmMessageDialogModule_1.default();
                    confirmDialog.open(msg)
                        .then(function (confirmResult) {
                        if (confirmResult.selectedValue == "Yes") {
                            _this.viewModel.removeLocations();
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("ItemStoreLocationView remove operation: " + JSON.stringify(reason));
                    });
                };
                ItemStoreLocationView.prototype.PrintingOperation = function () {
                    this.viewModel.printLocations();
                };
                return ItemStoreLocationView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", ItemStoreLocationView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/ItemStoreLocationView.js.map