System.register(["knockout", "PosApi/TypeExtensions", "../DataService2/DataServiceRequests.g", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, TypeExtensions_1, DataServiceRequests_g_1, ErrorHelper_1, ScJournalEntryViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ScJournalEntryViewModel = (function () {
                function ScJournalEntryViewModel(context, options) {
                    var _this = this;
                    this._context = context;
                    this.isPageModeBusy = knockout_1.default.observable(false);
                    this.searchText = knockout_1.default.observable("");
                    this.searchJournalEntry = knockout_1.default.observableArray([]);
                    this.scJournalEntry = knockout_1.default.observableArray([]);
                    this.enableDelete = knockout_1.default.computed(function () { return _this.scJournalEntry().length > 0; });
                    this.EntityType = options.key;
                    if (this.EntityType == "SCJournal") {
                        this.scJournal = options.value;
                        this.searchSCJournalEntries();
                    }
                    else {
                        this.scJournalTrans = options.value;
                        this.searchJournalTransEntries();
                    }
                }
                ScJournalEntryViewModel.prototype.searchSCJournalEntries = function () {
                    var _this = this;
                    if (TypeExtensions_1.StringExtensions.isNullOrWhitespace(this.searchText())) {
                        this.searchText("");
                    }
                    this.searchJournalEntry([]);
                    var search = this.searchText();
                    this.isPageModeBusy(true);
                    var request = new DataServiceRequests_g_1.StockTake.SearchSCJournalEntryRequest(this.scJournal.Id, search);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchJournalEntry(result.data.result);
                            if (TypeExtensions_1.ObjectExtensions.isFunction(_this.refreshListHandler)) {
                                _this.refreshListHandler();
                            }
                            return _this.searchJournalEntry();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Stock Take Journal Transaction search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ScJournalEntryViewModel.prototype.searchJournalTransEntries = function () {
                    var _this = this;
                    this.searchJournalEntry([]);
                    this.isPageModeBusy(true);
                    var request = new DataServiceRequests_g_1.StockTake.SCJournalEntryRequest(this.scJournalTrans.Id);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchJournalEntry(result.data.result);
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Stock Take Journal Transaction search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ScJournalEntryViewModel.prototype.deleteSCJournalEntries = function () {
                    var _this = this;
                    this.isPageModeBusy(true);
                    var recIds = [];
                    for (var i = 0; i < this.scJournalEntry().length; i++) {
                        recIds.push(this.scJournalEntry()[i].Id);
                    }
                    var request = new DataServiceRequests_g_1.StockTake.DeleteSCJournalEntryRequest(recIds);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (_this.EntityType == "SCJournal") {
                            _this.searchSCJournalEntries();
                        }
                        else {
                            _this.searchJournalTransEntries();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Stock Take Journal Transaction search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ScJournalEntryViewModel.prototype.JournalEntryEditor = function (item) {
                };
                ScJournalEntryViewModel.prototype.setSelectedItems = function (items) {
                    this.scJournalEntry(items);
                };
                return ScJournalEntryViewModel;
            }());
            exports_1("default", ScJournalEntryViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/SCJournalEntryViewModel.js.map