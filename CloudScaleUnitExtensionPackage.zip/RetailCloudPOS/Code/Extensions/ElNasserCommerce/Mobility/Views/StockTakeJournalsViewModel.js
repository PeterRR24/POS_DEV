System.register(["knockout", "PosApi/TypeExtensions", "../DataService2/DataServiceRequests.g", "../DataService2/DataServiceEntities.g", "../Controls/DialogControl/ConfirmMessageDialogModule", "PosApi/Consume/Peripherals", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, TypeExtensions_1, DataServiceRequests_g_1, DataServiceEntities_g_1, ConfirmMessageDialogModule_1, Peripherals_1, ErrorHelper_1, StockTakeJournalsViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (ConfirmMessageDialogModule_1_1) {
                ConfirmMessageDialogModule_1 = ConfirmMessageDialogModule_1_1;
            },
            function (Peripherals_1_1) {
                Peripherals_1 = Peripherals_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            StockTakeJournalsViewModel = (function () {
                function StockTakeJournalsViewModel(context, vState) {
                    var _this = this;
                    this._context = context;
                    this.state = vState;
                    this.searchJournals = knockout_1.default.observableArray([]);
                    this.axSCJournals = knockout_1.default.observableArray([]);
                    this.allowOffline = knockout_1.default.observable(false);
                    this.isShowDialog = knockout_1.default.observable(false);
                    this.scJournal = knockout_1.default.observable(null);
                    this.axJournal = knockout_1.default.observable(null);
                    this.selectedJournalID = knockout_1.default.observable("");
                    this.journalType = knockout_1.default.observable(0);
                    this.isEnable = knockout_1.default.computed(function () { return _this.scJournal() != null; });
                    this.searchText = knockout_1.default.observable("");
                    this.selectedJournalId = knockout_1.default.observable("");
                    this.selectedCMValue = knockout_1.default.observable("0");
                    this.selectedLMValue = knockout_1.default.observable("0");
                    var self = this;
                    this.journalType.subscribe(function (a) {
                        self.searchSCJournals();
                    }, this);
                    this._context.logger.logInformational("StockTakeJournalsViewModel: success");
                }
                StockTakeJournalsViewModel.prototype.searchSCJournals = function () {
                    var _this = this;
                    if (TypeExtensions_1.StringExtensions.isNullOrWhitespace(this.searchText())) {
                        this.searchText("");
                    }
                    this.searchJournals([]);
                    var search = this.searchText();
                    this.state.isProcessing = true;
                    var request = new DataServiceRequests_g_1.StockTake.SearchJournalRequest(this.journalType(), search);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.searchJournals(result.data.result);
                            if (TypeExtensions_1.ObjectExtensions.isFunction(_this.refreshListHandler)) {
                                _this.refreshListHandler();
                            }
                            return _this.searchJournals();
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Stock Take Journal search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.openJournalDialog = function () {
                    var _this = this;
                    var journals = [];
                    var request = new DataServiceRequests_g_1.StockTake.AXJournalRequest();
                    this.state.isProcessing = true;
                    var allowSelect = false;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            var stats = result.data.result;
                            for (var i = 0; i < stats.length; i++) {
                                journals.push({ Journal: stats[i], IsSelect: knockout_1.default.observable(allowSelect) });
                            }
                            _this.axSCJournals(journals);
                            _this.isShowDialog(true);
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Get Journal error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.ImportJournal = function () {
                    var _this = this;
                    var requestParam = new DataServiceEntities_g_1.Entities.SCJournalRequest();
                    requestParam.CalcMode = parseInt(this.selectedCMValue(), 10);
                    requestParam.LocationMode = parseInt(this.selectedLMValue(), 10);
                    requestParam.RecordId = this.axJournal().RecordId;
                    requestParam.JournalId = this.axJournal().JournalId;
                    requestParam.Description = this.axJournal().Description;
                    var request = new DataServiceRequests_g_1.StockTake.JournalImportRequest(requestParam);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.searchSCJournals();
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Import Journal error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.adjustJournal = function () {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.StockTake.JournalAdjustRequest(this.scJournal().Id);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Get Journal error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.calcualteJournal = function () {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.StockTake.JournalCalculateRequest(this.scJournal().Id, true);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Get Journal error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.commitJournal = function () {
                    var _this = this;
                    this.state.isProcessing = true;
                    var entryRequest = new DataServiceRequests_g_1.StockTake.SearchSCJournalEntryRequest(this.scJournal().Id, "");
                    this._context.runtime.executeAsync(entryRequest)
                        .then(function (resp) {
                        if (!resp.canceled) {
                            var entries = resp.data.result;
                            var doCommit = false;
                            for (var i = 0; i < entries.length; i++) {
                                if (entries[i].StatusValue != 0) {
                                    doCommit = true;
                                }
                            }
                            if (doCommit) {
                                var dialog = new ConfirmMessageDialogModule_1.default();
                                dialog.open(_this._context.resources.getString("CONFIRM_COMMIT_JOURNAL"))
                                    .then(function (result) {
                                    if (result.selectedValue !== 'Closed') {
                                        var commitRequest = new DataServiceRequests_g_1.StockTake.JournalCommitRequest(_this.scJournal().Id);
                                        _this._context.runtime.executeAsync(commitRequest)
                                            .then(function (result) {
                                            _this.state.isProcessing = false;
                                            if (!result.canceled) {
                                                _this.searchSCJournals();
                                            }
                                        })
                                            .catch(function (reason) {
                                            _this.state.isProcessing = false;
                                            _this._context.logger.logError("Commit Journal error: " + JSON.stringify(reason));
                                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                                        });
                                    }
                                    else {
                                        _this.state.isProcessing = false;
                                    }
                                });
                            }
                            else {
                                ErrorHelper_1.ErrorHelper.displayMessageAsync(_this._context, _this._context.resources.getString("JOURNAL_CALCULATE_VALIDATION"));
                                _this.state.isProcessing = false;
                            }
                        }
                        else
                            _this.state.isProcessing = false;
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Stock Take Journal entry error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.deleteJournal = function () {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.StockTake.DeleteJournalRequest(this.scJournal());
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.searchSCJournals();
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Delete Journal error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                StockTakeJournalsViewModel.prototype.importOfflineStockTake = function (file) {
                    var _this = this;
                    var me = this;
                    this.state.isProcessing = true;
                    this.getXml(file)
                        .then(function (data) {
                        var requestObj = { "xmlData": data };
                        var importRequest = new Peripherals_1.HardwareStationDeviceActionRequest("FILEOPERATION", "ImportStockTakeFromXML", requestObj);
                        me._context.runtime.executeAsync(importRequest)
                            .then(function (resp) {
                            var stItems = resp.data.response.StockTakeItems;
                            me._context.runtime.executeAsync(new DataServiceRequests_g_1.StockTake.CountItemsRequest(stItems))
                                .then(function (result) {
                                _this.state.isProcessing = false;
                                if (!result.canceled) {
                                    console.log(result.data.result);
                                    ErrorHelper_1.ErrorHelper.displayMessageAsync(me._context, me._context.resources.getString("JOURNAL_IMPORT_SUCCESS_MESSAGE"));
                                }
                            })
                                .catch(function (reason) {
                                _this.state.isProcessing = false;
                                me._context.logger.logError("Count inport journal items error: " + JSON.stringify(reason));
                                ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                            });
                        })
                            .catch(function (reason) {
                            _this.state.isProcessing = false;
                            me._context.logger.logError("Convert xml to object error: " + JSON.stringify(reason));
                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                        });
                    });
                };
                StockTakeJournalsViewModel.prototype.exportJournal = function () {
                    var transactions = [];
                    var sections = [];
                    var shelve = [];
                    var journals = this.searchJournals();
                    var isTrans = false;
                    var isSection = false;
                    var isShelve = false;
                    var isDone = false;
                    this.state.isProcessing = true;
                    var me = this;
                    var rr = { commerce: Commerce };
                    new rr.commerce.AsyncQueue().enqueue(function () {
                        var asyncResult = new rr.commerce.VoidAsyncResult();
                        var _loop_1 = function (i) {
                            setTimeout(function () {
                                me._context.runtime.executeAsync(new DataServiceRequests_g_1.StockTake.SearchJournalTransactionRequest(journals[i].Id, ''))
                                    .then(function (result) {
                                    if (!result.canceled) {
                                        transactions = transactions.concat(result.data.result);
                                    }
                                    isTrans = false;
                                    isDone = false;
                                    if (i + 1 == journals.length)
                                        isTrans = true;
                                    if (isTrans && isSection && isShelve)
                                        isDone = true;
                                    if (isDone)
                                        asyncResult.resolve();
                                })
                                    .catch(function (reason) {
                                    me.state.isProcessing = false;
                                    me._context.logger.logError("Stock Take Journal Transaction search error: " + JSON.stringify(reason));
                                    ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                                    asyncResult.reject(reason);
                                });
                            }, 50);
                        };
                        for (var i = 0; i < journals.length; i++) {
                            _loop_1(i);
                        }
                        me._context.runtime.executeAsync(new DataServiceRequests_g_1.StockTake.GetStoreSectionsRequest())
                            .then(function (result) {
                            if (!result.canceled) {
                                sections = result.data.result;
                            }
                            isSection = true;
                            if (isTrans && isSection && isShelve)
                                isDone = true;
                            if (isDone)
                                asyncResult.resolve();
                        })
                            .catch(function (reason) {
                            me.state.isProcessing = false;
                            me._context.logger.logError("Getting store section's error: " + JSON.stringify(reason));
                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                            asyncResult.reject(reason);
                        });
                        me._context.runtime.executeAsync(new DataServiceRequests_g_1.StockTake.GetStoreShelvesRequest(''))
                            .then(function (result) {
                            if (!result.canceled) {
                                shelve = result.data.result;
                            }
                            isShelve = true;
                            if (isTrans && isSection && isShelve)
                                isDone = true;
                            if (isDone)
                                asyncResult.resolve();
                        })
                            .catch(function (reason) {
                            me.state.isProcessing = false;
                            me._context.logger.logError("Getting store section's error: " + JSON.stringify(reason));
                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                            asyncResult.reject(reason);
                        });
                        return asyncResult;
                    }).enqueue(function () {
                        var asyncResult = new rr.commerce.VoidAsyncResult();
                        var items = [];
                        for (var i = 0; i < transactions.length; i++) {
                            items.push(new DataServiceEntities_g_1.Entities.BarcodeItem({
                                InventDimId: transactions[i].InventDimId,
                                ItemId: transactions[i].ItemId,
                                RecordId: transactions[i].RecordId,
                                UnitId: transactions[i].Unit
                            }));
                        }
                        me._context.runtime.executeAsync(new DataServiceRequests_g_1.StockTake.GetBarcodeForItemRequest(items))
                            .then(function (result) {
                            if (!result.canceled) {
                                items = result.data.result;
                                var _loop_2 = function (j) {
                                    if (items[j].Barcode != null || items[j].Barcode != "") {
                                        transactions.forEach(function (element, index) {
                                            if (element.RecordId === items[j].RecordId) {
                                                transactions[index].Barcode = items[j].Barcode;
                                            }
                                        });
                                    }
                                    if (j + 1 == items.length)
                                        asyncResult.resolve();
                                };
                                for (var j = 0; j < items.length; j++) {
                                    _loop_2(j);
                                }
                            }
                        })
                            .catch(function (reason) {
                            me.state.isProcessing = false;
                            me._context.logger.logError("Getting store section's error: " + JSON.stringify(reason));
                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                            asyncResult.reject(reason);
                        });
                        return asyncResult;
                    }).enqueue(function () {
                        var asyncResult = new rr.commerce.VoidAsyncResult();
                        var requestObj = {
                            "FileName": "",
                            "SCJournals": JSON.stringify(journals),
                            "SCJournalTransactions": JSON.stringify(transactions),
                            "StoreSections": JSON.stringify(sections),
                            "StoreSectionShelve": JSON.stringify(shelve)
                        };
                        var exportRequest = new Peripherals_1.HardwareStationDeviceActionRequest("FILEOPERATION", "Export", requestObj);
                        me._context.runtime.executeAsync(exportRequest)
                            .then(function (resp) {
                            console.log(JSON.stringify(resp));
                            var respMsg = '';
                            if (resp.data.response == true)
                                respMsg = me._context.resources.getString("JOURNAL_EXPORT_SUCCESS_MESSAGE");
                            else
                                respMsg = me._context.resources.getString("JOURNAL_EXPORT_FAIL_MESSAGE");
                            me.state.isProcessing = false;
                            ErrorHelper_1.ErrorHelper.displayMessageAsync(me._context, respMsg);
                            asyncResult.resolve();
                        })
                            .catch(function (reason) {
                            me.state.isProcessing = false;
                            me._context.logger.logError("Getting journal export error: " + JSON.stringify(reason));
                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(me._context, reason);
                            asyncResult.reject(reason);
                        });
                        return asyncResult;
                    }).run();
                };
                StockTakeJournalsViewModel.prototype.getXml = function (file) {
                    return new Promise(function (resolve, reject) {
                        var reader = new FileReader();
                        reader.readAsText(file, "UTF-8");
                        reader.onload = function () { return resolve(reader.result); };
                        reader.onerror = function (error) { return reject(error); };
                    });
                };
                StockTakeJournalsViewModel.prototype.setSelectedItems = function (items) {
                    if (items.length)
                        this.scJournal(items[0]);
                    else
                        this.scJournal(null);
                };
                return StockTakeJournalsViewModel;
            }());
            exports_1("default", StockTakeJournalsViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/StockTakeJournalsViewModel.js.map