System.register(["knockout", "PosApi/TypeExtensions", "../DataService2/RangingDataServiceRequests.g", "../Controls/DialogControl/ProcessingDialogModule", "PosApi/Consume/Peripherals", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, TypeExtensions_1, RangingDataServiceRequests_g_1, ProcessingDialogModule_1, Peripherals_1, ErrorHelper_1, ItemStoreLocationViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (RangingDataServiceRequests_g_1_1) {
                RangingDataServiceRequests_g_1 = RangingDataServiceRequests_g_1_1;
            },
            function (ProcessingDialogModule_1_1) {
                ProcessingDialogModule_1 = ProcessingDialogModule_1_1;
            },
            function (Peripherals_1_1) {
                Peripherals_1 = Peripherals_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ItemStoreLocationViewModel = (function () {
                function ItemStoreLocationViewModel(context, options) {
                    this._context = context;
                    this.isPageModeBusy = knockout_1.default.observable(false);
                    this.searchText = knockout_1.default.observable("");
                    this.storeLocationItems = knockout_1.default.observableArray([]);
                    this.storeSections = knockout_1.default.observableArray([]);
                    this.storeShelves = knockout_1.default.observableArray([]);
                    this.locationTree = knockout_1.default.observableArray([]);
                    this.selectedLocationItem = knockout_1.default.observable(null);
                    this.sectionId = knockout_1.default.observable("");
                    this.shelfId = knockout_1.default.observable("");
                    this.enableRemove = knockout_1.default.observable(false);
                    this.enableClear = knockout_1.default.observable(true);
                    this.GetStoreSectionAndShelves();
                    this.enableMoveUp = knockout_1.default.observable(false);
                    this.enableMoveDown = knockout_1.default.observable(false);
                    this.enableCommit = knockout_1.default.observable(true);
                    this.commitOption = knockout_1.default.observable("");
                    this.stopCommit = knockout_1.default.observable(false);
                    var self = this;
                    this.commitOption.subscribe(function () {
                        self.commitLocations();
                    });
                }
                ItemStoreLocationViewModel.prototype.searchStoreLacationItems = function () {
                    var _this = this;
                    if (this.sectionId() == "" || this.sectionId() == null)
                        return this.storeLocationItems([]);
                    if (this.shelfId() == "" || this.shelfId() == null)
                        return this.storeLocationItems([]);
                    this.isPageModeBusy(true);
                    var request = new RangingDataServiceRequests_g_1.Ranging.SelectLocationItemRequest(this.sectionId(), this.shelfId());
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.storeLocationItems(result.data.result);
                            if (TypeExtensions_1.ObjectExtensions.isFunction(_this.refreshListHandler)) {
                                _this.refreshListHandler();
                            }
                            return _this.storeLocationItems();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Get store location item error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.setSelectedItem = function (item) {
                    this.selectedLocationItem(item[0]);
                    this.enableRemove(item.length > 0);
                    this.enableMoveUp(false);
                    this.enableMoveDown(false);
                    if (item.length > 0) {
                        var len = this.storeLocationItems().length;
                        var isLast = this.storeLocationItems()[len - 1].ItemId == item[0].ItemId;
                        var isFIrst = this.storeLocationItems()[0].ItemId == item[0].ItemId;
                        this.enableMoveUp(!isFIrst);
                        this.enableMoveDown(!isLast);
                    }
                };
                ItemStoreLocationViewModel.prototype.placeItemLocations = function (location, itemId) {
                    var _this = this;
                    var request = new RangingDataServiceRequests_g_1.Ranging.PlaceLocationItemRequest(this.sectionId(), this.shelfId(), location, itemId);
                    this.isPageModeBusy(true);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchStoreLacationItems();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Placing item locations error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.clearLocations = function (option) {
                    var _this = this;
                    var shelve, section;
                    if (option == "1") {
                        section = this.sectionId();
                        shelve = this.shelfId();
                    }
                    else if (option == "2") {
                        section = this.sectionId();
                        shelve = "";
                    }
                    else {
                        section = "";
                        shelve = "";
                    }
                    var request = new RangingDataServiceRequests_g_1.Ranging.ClearLocationItemRequest(section, shelve);
                    this.isPageModeBusy(true);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchStoreLacationItems();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Clear locations error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.commitLocations = function () {
                    var _this = this;
                    var option = this.commitOption();
                    if (["1", "2", "3"].indexOf(option) == -1)
                        return;
                    var dialog = new ProcessingDialogModule_1.default();
                    var shelves = [];
                    var shelve, section;
                    this.stopCommit(false);
                    if (option == "1") {
                        dialog = null;
                        shelve = this.shelfId();
                        section = this.sectionId();
                    }
                    else if (option == "2") {
                        shelves = this.storeShelves().filter(function (ss) { return ss.SectionId == _this.sectionId(); });
                        this.commitAllForSection(dialog, shelves, 0);
                        return;
                    }
                    else {
                        shelves = this.storeShelves();
                        this.commitAllForSection(dialog, shelves, 0);
                        return;
                    }
                    this.isPageModeBusy(true);
                    var request = new RangingDataServiceRequests_g_1.Ranging.CommitLocationItemRequest(section, shelve);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchStoreLacationItems();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Update HQ locations error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.commitAllForSection = function (dialog, shelves, i) {
                    var _this = this;
                    if (i == shelves.length) {
                        $("#processText").html(this._context.resources.getString("COMMIT_LOCATION_SUCCESS_MESSAGE"));
                        return;
                    }
                    var msg = TypeExtensions_1.StringExtensions.format(this._context.resources.getString("COMMIT_LOCATION_PROCESS_MESSAGE"), shelves[i].SectionName);
                    console.log(shelves[i].SectionName);
                    if (i == 0) {
                        this.isPageModeBusy(true);
                        dialog.open(msg, this._context.resources.getString("COMMIT_LOCATION_PROCESS_DIALOG_TITLE"))
                            .then(function (result) {
                            if (result.selectedValue == "Done") {
                                _this.isPageModeBusy(false);
                                _this.searchStoreLacationItems();
                                _this.stopCommit(true);
                            }
                        }).catch(function (reason) {
                            _this._context.logger.logError("ItemStoreLocationViewModel update HQ processing dialog error: " + JSON.stringify(reason));
                        });
                    }
                    else if (i > 0) {
                        $("#processText").html(msg);
                    }
                    if (this.stopCommit()) {
                        return;
                    }
                    var request = new RangingDataServiceRequests_g_1.Ranging.CommitLocationItemRequest(shelves[i].SectionId, shelves[i].ShelfId);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (!result.canceled) {
                            if (_this.stopCommit()) {
                                _this.isPageModeBusy(false);
                                _this.searchStoreLacationItems();
                            }
                            else
                                _this.commitAllForSection(dialog, shelves, ++i);
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this.searchStoreLacationItems();
                        _this._context.logger.logError("Items location update to HQ error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.removeLocations = function () {
                    var _this = this;
                    var item = this.selectedLocationItem();
                    var request = new RangingDataServiceRequests_g_1.Ranging.RemoveLocationItemRequest(this.sectionId(), this.shelfId(), item.Location);
                    this.isPageModeBusy(true);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchStoreLacationItems();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Removing locations error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.printLocations = function () {
                    var _this = this;
                    this.isPageModeBusy(true);
                    var count = 0;
                    var itemList = [];
                    var shelf = null;
                    var request = null;
                    for (var idx = 0; idx < this.storeShelves().length; idx++) {
                        shelf = this.storeShelves()[idx];
                        request = new RangingDataServiceRequests_g_1.Ranging.SelectLocationItemRequest(shelf.SectionId, shelf.ShelfId);
                        this._context.runtime.executeAsync(request)
                            .then(function (result) {
                            count += 1;
                            if (!result.canceled) {
                                itemList = itemList.concat(result.data.result);
                            }
                            console.log(itemList);
                            if (count === (_this.storeShelves().length)) {
                                _this.isPageModeBusy(false);
                                _this.processPrint(itemList);
                            }
                        })
                            .catch(function (reason) {
                            _this.isPageModeBusy(false);
                            _this._context.logger.logError("Get store location item error: " + JSON.stringify(reason));
                            ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        });
                    }
                };
                ItemStoreLocationViewModel.prototype.processPrint = function (items) {
                    var _this = this;
                    if (items.length == 0)
                        return;
                    this.isPageModeBusy(true);
                    var commerce = Commerce;
                    var storeNumber = commerce.ApplicationContext.Instance.storeNumber;
                    var requestObj = { "storeName": storeNumber, "strObject": JSON.stringify(items) };
                    var hsRequest = new Peripherals_1.HardwareStationDeviceActionRequest("FACEING", "PrintFacing", requestObj);
                    this._context.runtime.executeAsync(hsRequest)
                        .then(function (resp) {
                        console.log(resp);
                        _this.isPageModeBusy(false);
                    })
                        .catch(function (reason) {
                        console.log(reason);
                        _this.isPageModeBusy(false);
                    });
                };
                ItemStoreLocationViewModel.prototype.moveLocations = function (option) {
                    var _this = this;
                    var item = this.selectedLocationItem();
                    var upItem = null, downItem = null, allItems = this.storeLocationItems(), itemsLen = allItems.length, newLocation = 0;
                    if (itemsLen == 1)
                        return;
                    for (var i = 0; i < itemsLen; i++) {
                        if (allItems[i].ItemId == item.ItemId) {
                            if (i != 0) {
                                upItem = allItems[i - 1];
                            }
                            if (i != itemsLen - 1) {
                                downItem = allItems[i + 1];
                            }
                            break;
                        }
                    }
                    if (option == 'up') {
                        newLocation = upItem.Location;
                    }
                    else {
                        newLocation = downItem.Location;
                    }
                    var request = new RangingDataServiceRequests_g_1.Ranging.MoveLocationItemRequest(this.sectionId(), this.shelfId(), item.Location, newLocation);
                    this.isPageModeBusy(true);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchStoreLacationItems();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Moving locations error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.GetStoreSectionAndShelves = function () {
                    var _this = this;
                    this.GetStoreSections().then(function () {
                        _this.GetStoreShelves().then(function (result) {
                            _this.arrangeLocation(result);
                        });
                    });
                };
                ItemStoreLocationViewModel.prototype.GetStoreSections = function () {
                    var _this = this;
                    if (this.storeSections().length > 0)
                        return this.storeSections([]);
                    var request = new RangingDataServiceRequests_g_1.Ranging.GetStoreSectionsRequest();
                    this.isPageModeBusy(true);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.storeSections(result.data.result);
                            return _this.storeSections();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Getting store section's error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.GetStoreShelves = function (sectionId) {
                    var _this = this;
                    if (sectionId === void 0) { sectionId = ''; }
                    if (this.storeShelves().length > 0)
                        return this.storeShelves([]);
                    var request = new RangingDataServiceRequests_g_1.Ranging.GetStoreShelvesRequest(sectionId);
                    this.isPageModeBusy(true);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.storeShelves(result.data.result);
                            _this.arrangeLocation(result.data.result);
                            return _this.storeShelves();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Geting section's shalve error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemStoreLocationViewModel.prototype.arrangeLocation = function (arry) {
                    var secs = this.storeSections(), shelves = this.storeShelves(), storeShelves = [], sections = [];
                    if (this.storeSections().length == 0 || this.storeShelves().length == 0) {
                        return;
                    }
                    for (var i = 0; i < secs.length; ++i) {
                        var section = secs[i];
                        sections.push({
                            SectionId: section.SectionId,
                            SectionName: section.SectionName,
                            shelves: []
                        });
                        for (var j = 0; j < shelves.length; ++j) {
                            var shelve = shelves[j];
                            if (section.SectionId == shelve.SectionId) {
                                sections[i].shelves.push(shelve);
                                storeShelves.push(shelve);
                            }
                        }
                    }
                    this.locationTree(sections);
                    this.storeShelves([]);
                    this.storeShelves(storeShelves);
                };
                return ItemStoreLocationViewModel;
            }());
            exports_1("default", ItemStoreLocationViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/ItemStoreLocationViewModel.js.map