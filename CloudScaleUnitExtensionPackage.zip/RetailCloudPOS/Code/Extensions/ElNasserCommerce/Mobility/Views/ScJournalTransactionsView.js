System.register(["knockout", "PosApi/Create/Views", "PosApi/Consume/Controls", "./ScJournalTransactionsViewModel", "../Controls/DialogControl/CountingDialogModule", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, Controls_1, ScJournalTransactionsViewModel_1, CountingDialogModule_1, TypeExtensions_1, ScJournalTransactionsView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (Controls_1_1) {
                Controls_1 = Controls_1_1;
            },
            function (ScJournalTransactionsViewModel_1_1) {
                ScJournalTransactionsViewModel_1 = ScJournalTransactionsViewModel_1_1;
            },
            function (CountingDialogModule_1_1) {
                CountingDialogModule_1 = CountingDialogModule_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            ScJournalTransactionsView = (function (_super) {
                __extends(ScJournalTransactionsView, _super);
                function ScJournalTransactionsView(context, options) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("JOURNAL_TRANSACTIONS_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "transactionEntry",
                                    label: context.resources.getString('ENTRIES_BUTTON'),
                                    icon: NewView.Icons.PageList,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.EntriesOperation();
                                    }
                                },
                                {
                                    name: "clearTransaction",
                                    label: 'Clear',
                                    icon: NewView.Icons.Cancel,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.ClearTransOperation();
                                    }
                                },
                                {
                                    name: "countTransaction",
                                    label: 'Count',
                                    icon: NewView.Icons.Count,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.CountTransOperation();
                                    }
                                }
                            ]
                        }
                    }) || this;
                    _this._context = context;
                    _this.viewModel = new ScJournalTransactionsViewModel_1.default(context, options);
                    return _this;
                }
                ScJournalTransactionsView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var dataListOptions = {
                        interactionMode: Controls_1.DataListInteractionMode.SingleSelect,
                        data: this.viewModel.searchTransactions,
                        columns: [
                            {
                                title: this._context.resources.getString("ITEM_ID"),
                                ratio: 7,
                                collapseOrder: 10,
                                minWidth: 40,
                                computeValue: function (rowData) { return rowData.ItemId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_NAME"),
                                ratio: 20,
                                collapseOrder: 11,
                                minWidth: 80,
                                computeValue: function (rowData) { return rowData.ItemName; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_CONFIG"),
                                ratio: 7,
                                collapseOrder: 1,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.ConfigId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_SIZE"),
                                ratio: 7,
                                collapseOrder: 2,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.InventSizeId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_COLOR"),
                                ratio: 7,
                                collapseOrder: 3,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.InventColorId; }
                            },
                            {
                                title: this._context.resources.getString("ITEM_DIM_STYLE"),
                                ratio: 7,
                                collapseOrder: 4,
                                minWidth: 50,
                                computeValue: function (rowData) { return rowData.InventStyleId; }
                            },
                            {
                                title: this._context.resources.getString("UNIT"),
                                ratio: 5,
                                collapseOrder: 5,
                                minWidth: 40,
                                computeValue: function (rowData) { return rowData.Unit; }
                            },
                            {
                                title: this._context.resources.getString("QUANTITY"),
                                ratio: 8,
                                collapseOrder: 6,
                                minWidth: 70,
                                computeValue: function (rowData) { return Number(rowData.Quantity).toFixed(2); }
                            },
                            {
                                title: this._context.resources.getString("QUANTITY_COUNT"),
                                ratio: 8,
                                collapseOrder: 7,
                                minWidth: 70,
                                computeValue: function (rowData) { return rowData.QtyCount == undefined ? "" : Number(rowData.QtyCount).toFixed(2); }
                            },
                            {
                                title: this._context.resources.getString("QUANTITY_ADJUST"),
                                ratio: 8,
                                collapseOrder: 8,
                                minWidth: 70,
                                computeValue: function (rowData) { return rowData.QtyAdjust == undefined ? "" : Number(rowData.QtyAdjust).toFixed(2); }
                            },
                            {
                                title: this._context.resources.getString("COUNT_DATE"),
                                ratio: 8,
                                collapseOrder: 9,
                                minWidth: 60,
                                computeValue: function (rowData) { return rowData.CountedDate == undefined ? "" : rowData.CountedDate.toLocaleDateString(); }
                            },
                            {
                                title: this._context.resources.getString("COMMENT"),
                                ratio: 8,
                                collapseOrder: 12,
                                minWidth: 70,
                                computeValue: function (rowData) { return rowData.Comment; }
                            }
                        ]
                    };
                    var dataListRootElem = element.querySelector("#listScJournalTransview");
                    this.dataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DataList", dataListOptions, dataListRootElem);
                    this.dataList.addEventListener("SelectionChanged", function (eventData) {
                        _this.viewModel.setSelectedItems(eventData.items);
                        _this.state.commandBar.commands.forEach(function (command) { return command.canExecute = (["transactionEntry", "clearTransaction", "countTransaction"]
                            .some(function (name) { return name == command.name && _this.viewModel.isEnable(); })); });
                    });
                    this.state.isProcessing = true;
                    this.viewModel.searchSCJournalTransactions().then(function () {
                        _this.dataList.data = _this.viewModel.searchTransactions();
                        _this.state.isProcessing = false;
                    });
                    this.viewModel.refreshListHandler = (function () {
                        _this.RefreshList();
                    });
                };
                ScJournalTransactionsView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                ScJournalTransactionsView.prototype.RefreshList = function () {
                    this.dataList.data = this.viewModel.searchTransactions();
                };
                ScJournalTransactionsView.prototype.searchClickHandler = function () {
                    this.viewModel.searchSCJournalTransactions();
                };
                ScJournalTransactionsView.prototype.CountTransOperation = function () {
                    var _this = this;
                    var item = this.viewModel.scJournalTransaction();
                    var qty = isNaN(item.QtyCount) ? "" : item.QtyCount.toString();
                    var dialog = new CountingDialogModule_1.default(true);
                    dialog.open(item.ItemName, qty, this._context.resources.getString("QUANTITY_COUNT_DIALOG_TITLE"))
                        .then(function (result) {
                        if (result.result !== 'Closed') {
                            _this.viewModel.countJournalTransactions(result.quantity, result.comment);
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("ScJournalTransactionsView.openTemplatedDialog: " + JSON.stringify(reason));
                    });
                };
                ScJournalTransactionsView.prototype.ClearTransOperation = function () {
                    var _this = this;
                    var item = this.viewModel.scJournalTransaction();
                    var dialog = new CountingDialogModule_1.default(false);
                    dialog.open(item.ItemName, "", this._context.resources.getString("COMMENT_DIALOG_TITLE"))
                        .then(function (result) {
                        if (result.result !== 'Closed') {
                            _this.viewModel.clearJournalTransactions(result.comment);
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("ScJournalTransactionsView.openTemplatedDialog: " + JSON.stringify(reason));
                    });
                };
                ScJournalTransactionsView.prototype.EntriesOperation = function () {
                    var options = {
                        key: "SCJournalTransaction",
                        value: this.viewModel.scJournalTransaction()
                    };
                    this._context.navigator.navigate("ScJournalEntryView", options);
                };
                return ScJournalTransactionsView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", ScJournalTransactionsView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/ScJournalTransactionsView.js.map