System.register(["knockout", "PosApi/Create/Views", "./StockTakeJournalsViewModel", "PosApi/Consume/Controls", "../Controls/DialogControl/ConfirmMessageDialogModule", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, StockTakeJournalsViewModel_1, Controls, ConfirmMessageDialogModule_1, TypeExtensions_1, StockTakeJournalsView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (StockTakeJournalsViewModel_1_1) {
                StockTakeJournalsViewModel_1 = StockTakeJournalsViewModel_1_1;
            },
            function (Controls_1) {
                Controls = Controls_1;
            },
            function (ConfirmMessageDialogModule_1_1) {
                ConfirmMessageDialogModule_1 = ConfirmMessageDialogModule_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            StockTakeJournalsView = (function (_super) {
                __extends(StockTakeJournalsView, _super);
                function StockTakeJournalsView(context) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("STOCK_TAKE_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "addJournal",
                                    label: context.resources.getString('GET_JOURNAL_BUTTON'),
                                    icon: NewView.Icons.Add,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.AddAxJournalOperation();
                                    }
                                },
                                {
                                    name: "journalTransactions",
                                    label: 'Transactions',
                                    icon: NewView.Icons.LightningBolt,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.JournalTransactionsOperation();
                                    }
                                },
                                {
                                    name: "journalEntries",
                                    label: context.resources.getString('ENTRIES_BUTTON'),
                                    icon: NewView.Icons.PageList,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.JournalEntriesOperation();
                                    }
                                },
                                {
                                    name: "calculateJournal",
                                    label: context.resources.getString('CALCULATE_BUTTON'),
                                    icon: NewView.Icons.Quantity,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.JournalCalcOperation();
                                    }
                                },
                                {
                                    name: "journalAdjust",
                                    label: context.resources.getString('ADJUST_BUTTON'),
                                    icon: NewView.Icons.CheckList,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.JournalAdjustOperation();
                                    }
                                },
                                {
                                    name: "commitJournal",
                                    label: 'Commit',
                                    icon: NewView.Icons.Accept,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.JournalCommitOperation();
                                    }
                                },
                                {
                                    name: "deleteJournal",
                                    label: 'Delete',
                                    icon: NewView.Icons.Delete,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.deleteJournalOperation();
                                    }
                                },
                                {
                                    name: "exportJournal",
                                    label: context.resources.getString('EXPORT_BUTTON'),
                                    icon: NewView.Icons.CloudUpload,
                                    isVisible: false,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.ExportJournalOperation();
                                    }
                                },
                                {
                                    name: "importJournal",
                                    label: context.resources.getString('IMPORT_BUTTON'),
                                    icon: NewView.Icons.Pickup,
                                    isVisible: false,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.ImportJournalOperation();
                                    }
                                },
                            ]
                        }
                    }) || this;
                    _this._context = context;
                    _this.viewModel = new StockTakeJournalsViewModel_1.default(context, _this.state);
                    _this.page1Visible = knockout_1.default.observable(false);
                    _this.page2Visible = knockout_1.default.observable(false);
                    _this.btnBackEnable = knockout_1.default.observable(false);
                    _this.btnNextEnable = knockout_1.default.observable(false);
                    _this.btnOKEnable = knockout_1.default.observable(false);
                    _this.arrJournalTypes = knockout_1.default.observableArray([
                        { JournalStatus: "Open", Value: 0 },
                        { JournalStatus: "Close", Value: 1 }
                    ]);
                    return _this;
                }
                StockTakeJournalsView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var dataListOptions = {
                        columns: [
                            {
                                title: this._context.resources.getString("JOURNAL_ID"),
                                ratio: 20,
                                collapseOrder: 8,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.JournalId; }
                            },
                            {
                                title: this._context.resources.getString("JOURNAL_DESCRIPTION"),
                                ratio: 25,
                                collapseOrder: 7,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.Description; }
                            },
                            {
                                title: this._context.resources.getString("JOURNAL_STATUS"),
                                ratio: 10,
                                collapseOrder: 6,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.Status.toString(); }
                            },
                            {
                                title: this._context.resources.getString("CALCULATE_MODE"),
                                ratio: 7,
                                collapseOrder: 5,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.CalcMode.toString(); }
                            },
                            {
                                title: this._context.resources.getString("LOCATION_MODE"),
                                ratio: 10,
                                collapseOrder: 4,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.LocationMode.toString(); }
                            },
                            {
                                title: this._context.resources.getString("CALCULATE_DATE"),
                                ratio: 10,
                                collapseOrder: 3,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.CreatedDate == undefined ? "" : rowData.CreatedDate.toLocaleDateString(); }
                            },
                            {
                                title: this._context.resources.getString("COMMIT_DATE"),
                                ratio: 10,
                                collapseOrder: 2,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.CommitDate == undefined ? "" : rowData.CommitDate.toLocaleDateString(); }
                            },
                            {
                                title: this._context.resources.getString("STAFF"),
                                ratio: 8,
                                collapseOrder: 1,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.StaffId; }
                            }
                        ],
                        data: this.viewModel.searchJournals(),
                        interactionMode: Controls.DataListInteractionMode.SingleSelect
                    };
                    var dataListRootElem = element.querySelector("#listJournalview");
                    this.dataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DataList", dataListOptions, dataListRootElem);
                    this.dataList.addEventListener("SelectionChanged", function (eventData) {
                        _this.viewModel.setSelectedItems(eventData.items);
                        _this.state.commandBar.commands.forEach(function (command) { return command.canExecute = (["journalTransactions", "journalEntries", "calculateJournal", "journalAdjust", "commitJournal", "deleteJournal"]
                            .some(function (name) { return name == command.name && _this.viewModel.isEnable(); }) || (command.name == "addJournal")); });
                    });
                    this.state.isProcessing = true;
                    this.viewModel.searchSCJournals().then(function () {
                        _this.dataList.data = _this.viewModel.searchJournals();
                        _this.state.isProcessing = false;
                    });
                    this.viewModel.refreshListHandler = (function () {
                        _this.RefreshList();
                    });
                };
                StockTakeJournalsView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                StockTakeJournalsView.prototype.RefreshList = function () {
                    this.dataList.data = this.viewModel.searchJournals();
                };
                StockTakeJournalsView.prototype.searchClickHandler = function () {
                    this.viewModel.searchSCJournals();
                };
                StockTakeJournalsView.prototype.AddAxJournalOperation = function () {
                    this.page1Visible(true);
                    this.page2Visible(false);
                    this.btnBackEnable(false);
                    this.btnNextEnable(false);
                    this.btnOKEnable(false);
                    this.viewModel.openJournalDialog();
                };
                StockTakeJournalsView.prototype.deleteJournalOperation = function () {
                    var _this = this;
                    var dialog = new ConfirmMessageDialogModule_1.default();
                    dialog.open(this._context.resources.getString("CONFIRM_DELETE_JOURNAL"))
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            _this.viewModel.deleteJournal();
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("StockTakeJournalsView deleteJournalOperation confirmation: " + JSON.stringify(reason));
                    });
                };
                StockTakeJournalsView.prototype.JournalCommitOperation = function () {
                    this.viewModel.commitJournal();
                };
                StockTakeJournalsView.prototype.JournalAdjustOperation = function () {
                    var _this = this;
                    var dialog = new ConfirmMessageDialogModule_1.default();
                    dialog.open(this._context.resources.getString("CONFIRM_ADJUST_JOURNAL"))
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            _this.viewModel.adjustJournal();
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("StockTakeJournalsView journal adjust operation confirmation: " + JSON.stringify(reason));
                    });
                };
                StockTakeJournalsView.prototype.JournalCalcOperation = function () {
                    var _this = this;
                    var dialog = new ConfirmMessageDialogModule_1.default();
                    dialog.open(this._context.resources.getString("CONFIRM_CALCULATE_JOURNAL"))
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            _this.viewModel.calcualteJournal();
                        }
                    }).catch(function (reason) {
                        _this._context.logger.logError("StockTakeJournalsView journal calcualte operation confirmation: " + JSON.stringify(reason));
                    });
                };
                StockTakeJournalsView.prototype.getJournal = function (self, data, e) {
                    self.viewModel.axJournal(data.Journal);
                    self.viewModel.selectedJournalID(data.Journal.JournalId);
                    self.viewModel.selectedCMValue("0");
                    self.viewModel.selectedLMValue("0");
                    self.btnNextEnable(true);
                    var rooNodes = document.querySelectorAll('div#divSCJournals div.listViewLine');
                    for (var i = 0; i < rooNodes.length; i++) {
                        rooNodes[i].classList.remove("accentBackground");
                        rooNodes[i].classList.add("tablerow");
                        var elements = rooNodes[i].getElementsByTagName('input');
                        for (var j = 0; j < elements.length; j++) {
                            var elmt = elements[j];
                            if (elmt.type == "hidden" && elmt.id == data.Journal.RecordId) {
                                rooNodes[i].classList.add("accentBackground");
                                rooNodes[i].classList.remove("tablerow");
                            }
                        }
                    }
                };
                StockTakeJournalsView.prototype.ImportJournalOperation = function () {
                    document.getElementById('filePath').click();
                };
                StockTakeJournalsView.prototype.FileDialogHandler = function (self, evt) {
                    var data = evt.currentTarget.files[0];
                    this.viewModel.importOfflineStockTake(data);
                };
                StockTakeJournalsView.prototype.ExportJournalOperation = function () {
                    this.viewModel.exportJournal();
                };
                StockTakeJournalsView.prototype.NextHandler = function () {
                    this.page1Visible(false);
                    this.page2Visible(true);
                    this.btnBackEnable(true);
                    this.btnNextEnable(false);
                    this.btnOKEnable(true);
                };
                StockTakeJournalsView.prototype.BackHandler = function () {
                    this.page1Visible(true);
                    this.page2Visible(false);
                    this.btnBackEnable(false);
                    this.btnNextEnable(true);
                    this.btnOKEnable(false);
                };
                StockTakeJournalsView.prototype.OkDialogHandler = function () {
                    this.viewModel.isShowDialog(false);
                    this.viewModel.ImportJournal();
                };
                StockTakeJournalsView.prototype.CancelDialogHandler = function () {
                    this.viewModel.isShowDialog(false);
                };
                StockTakeJournalsView.prototype.JournalTransactionsOperation = function () {
                    this._context.navigator.navigate("ScJournalTransactionsView", this.viewModel.scJournal());
                };
                StockTakeJournalsView.prototype.JournalEntriesOperation = function () {
                    var options = {
                        key: "SCJournal",
                        value: this.viewModel.scJournal()
                    };
                    this._context.navigator.navigate("ScJournalEntryView", options);
                };
                return StockTakeJournalsView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", StockTakeJournalsView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/StockTakeJournalsView.js.map