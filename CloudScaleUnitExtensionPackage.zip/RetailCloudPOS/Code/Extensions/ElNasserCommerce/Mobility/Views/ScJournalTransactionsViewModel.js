System.register(["knockout", "PosApi/TypeExtensions", "../DataService2/DataServiceRequests.g", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, TypeExtensions_1, DataServiceRequests_g_1, ErrorHelper_1, ScJournalTransactionsViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ScJournalTransactionsViewModel = (function () {
                function ScJournalTransactionsViewModel(context, options) {
                    var _this = this;
                    this._context = context;
                    this.isPageModeBusy = knockout_1.default.observable(false);
                    this.searchText = knockout_1.default.observable("");
                    this.searchTransactions = knockout_1.default.observableArray([]);
                    this.scJournalTransaction = knockout_1.default.observable(null);
                    this.isEnable = knockout_1.default.computed(function () { return _this.scJournalTransaction() != null; });
                    this.scJournal = options;
                    this.searchSCJournalTransactions();
                }
                ScJournalTransactionsViewModel.prototype.searchSCJournalTransactions = function () {
                    var _this = this;
                    if (TypeExtensions_1.StringExtensions.isNullOrWhitespace(this.searchText())) {
                        this.searchText("");
                    }
                    this.searchTransactions([]);
                    var search = this.searchText();
                    this.isPageModeBusy(true);
                    var request = new DataServiceRequests_g_1.StockTake.SearchJournalTransactionRequest(this.scJournal.Id, search);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            _this.searchTransactions(result.data.result);
                            if (TypeExtensions_1.ObjectExtensions.isFunction(_this.refreshListHandler)) {
                                _this.refreshListHandler();
                            }
                            return _this.searchTransactions();
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Stock Take Journal Transaction search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ScJournalTransactionsViewModel.prototype.countJournalTransactions = function (quantity, comment) {
                    var _this = this;
                    var recId = this.scJournalTransaction().Id;
                    var list = this.searchTransactions();
                    var item = null;
                    this.isPageModeBusy(true);
                    var request = new DataServiceRequests_g_1.StockTake.CountTransactionRequest(recId, quantity, comment);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            item = result.data.result;
                            for (var i = 0; i < list.length; i++) {
                                if (item.Id == list[i].Id && item.RecordId == list[i].RecordId) {
                                    list[i] = item;
                                    break;
                                }
                            }
                            _this.searchTransactions([]);
                            _this.searchTransactions(list);
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Stock Take Journal Transaction Count operation error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ScJournalTransactionsViewModel.prototype.clearJournalTransactions = function (comment) {
                    var _this = this;
                    var recId = this.scJournalTransaction().Id;
                    var list = this.searchTransactions();
                    var item = null;
                    this.isPageModeBusy(true);
                    var request = new DataServiceRequests_g_1.StockTake.ClearTransactionRequest(recId, comment);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isPageModeBusy(false);
                        if (!result.canceled) {
                            item = result.data.result;
                            for (var i = 0; i < list.length; i++) {
                                if (item.Id == list[i].Id && item.RecordId == list[i].RecordId) {
                                    list[i] = item;
                                    break;
                                }
                            }
                            _this.searchTransactions([]);
                            _this.searchTransactions(list);
                        }
                    })
                        .catch(function (reason) {
                        _this.isPageModeBusy(false);
                        _this._context.logger.logError("Stock Take Journal Transaction Clear operation error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ScJournalTransactionsViewModel.prototype.setSelectedItems = function (items) {
                    if (items.length)
                        this.scJournalTransaction(items[0]);
                    else
                        this.scJournalTransaction(null);
                };
                return ScJournalTransactionsViewModel;
            }());
            exports_1("default", ScJournalTransactionsViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Mobility/Views/ScJournalTransactionsViewModel.js.map