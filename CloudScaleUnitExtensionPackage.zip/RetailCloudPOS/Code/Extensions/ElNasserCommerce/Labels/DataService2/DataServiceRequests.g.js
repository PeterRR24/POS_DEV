System.register(["PosApi/Entities", "./DataServiceEntities.g", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, DataServiceEntities_g_1, DataService_1, Labels;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            exports_1("Entities", DataServiceEntities_g_1.Entities);
            (function (Labels) {
                var EmptyOrNullResponse = (function (_super) {
                    __extends(EmptyOrNullResponse, _super);
                    function EmptyOrNullResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return EmptyOrNullResponse;
                }(DataService_1.DataServiceResponse));
                Labels.EmptyOrNullResponse = EmptyOrNullResponse;
                var GetLabelItemResponse = (function (_super) {
                    __extends(GetLabelItemResponse, _super);
                    function GetLabelItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetLabelItemResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetLabelItemResponse = GetLabelItemResponse;
                var GetLabelItemRequest = (function (_super) {
                    __extends(GetLabelItemRequest, _super);
                    function GetLabelItemRequest(labelType, keyword, top, skip) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "Search";
                        _this._parameters = { labelType: labelType, keyword: keyword };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.LabelItem;
                        _this._isReturnTypeCollection = true;
                        _this.top = top;
                        _this.skip = skip;
                        return _this;
                    }
                    return GetLabelItemRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetLabelItemRequest = GetLabelItemRequest;
                var CalculateLabelItemResponse = (function (_super) {
                    __extends(CalculateLabelItemResponse, _super);
                    function CalculateLabelItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return CalculateLabelItemResponse;
                }(DataService_1.DataServiceResponse));
                Labels.CalculateLabelItemResponse = CalculateLabelItemResponse;
                var CalculateLabelItemRequest = (function (_super) {
                    __extends(CalculateLabelItemRequest, _super);
                    function CalculateLabelItemRequest(labelType, calcParam, items, criteria, pageNumber) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "Calculate";
                        _this._parameters = { labelType: labelType, param: calcParam, items: items, criteria: criteria, pageNumber: pageNumber };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CalculateLabelItemRequest;
                }(DataService_1.DataServiceRequest));
                Labels.CalculateLabelItemRequest = CalculateLabelItemRequest;
                var GetCalcStatResponse = (function (_super) {
                    __extends(GetCalcStatResponse, _super);
                    function GetCalcStatResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetCalcStatResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetCalcStatResponse = GetCalcStatResponse;
                var GetCalcStatRequest = (function (_super) {
                    __extends(GetCalcStatRequest, _super);
                    function GetCalcStatRequest(labelType) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "CalcStat";
                        _this._parameters = { labelType: labelType };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.LabelItemStatistic;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetCalcStatRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetCalcStatRequest = GetCalcStatRequest;
                var GetLabelsFormatResponse = (function (_super) {
                    __extends(GetLabelsFormatResponse, _super);
                    function GetLabelsFormatResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetLabelsFormatResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetLabelsFormatResponse = GetLabelsFormatResponse;
                var GetLabelsFormatRequest = (function (_super) {
                    __extends(GetLabelsFormatRequest, _super);
                    function GetLabelsFormatRequest(stat) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "Format";
                        _this._parameters = { stat: stat };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.PrinterJob;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return GetLabelsFormatRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetLabelsFormatRequest = GetLabelsFormatRequest;
                var GetLabelItemFormatRequest = (function (_super) {
                    __extends(GetLabelItemFormatRequest, _super);
                    function GetLabelItemFormatRequest(recordId, quantity) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "FormatLabelItem";
                        _this._parameters = { recordId: recordId, quantity: quantity };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.PrinterJob;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return GetLabelItemFormatRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetLabelItemFormatRequest = GetLabelItemFormatRequest;
                var CommitLabelItemRequest = (function (_super) {
                    __extends(CommitLabelItemRequest, _super);
                    function CommitLabelItemRequest(recordId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "CommitLabelItem";
                        _this._parameters = { recordId: recordId };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CommitLabelItemRequest;
                }(DataService_1.DataServiceRequest));
                Labels.CommitLabelItemRequest = CommitLabelItemRequest;
                var CommitLabelItemsRequest = (function (_super) {
                    __extends(CommitLabelItemsRequest, _super);
                    function CommitLabelItemsRequest(recordIds) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "CommitItems";
                        _this._parameters = { recordIds: recordIds };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CommitLabelItemsRequest;
                }(DataService_1.DataServiceRequest));
                Labels.CommitLabelItemsRequest = CommitLabelItemsRequest;
                var PrintLabelItemResponse = (function (_super) {
                    __extends(PrintLabelItemResponse, _super);
                    function PrintLabelItemResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return PrintLabelItemResponse;
                }(DataService_1.DataServiceResponse));
                Labels.PrintLabelItemResponse = PrintLabelItemResponse;
                var PrintLabelItemRequest = (function (_super) {
                    __extends(PrintLabelItemRequest, _super);
                    function PrintLabelItemRequest(recordId, quantity, templateNo) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "PrintLabelItem";
                        _this._parameters = { recordId: recordId, quantity: quantity, templateNo: templateNo };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.LabelPrinterTask;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return PrintLabelItemRequest;
                }(DataService_1.DataServiceRequest));
                Labels.PrintLabelItemRequest = PrintLabelItemRequest;
                var GetLabelsCommitRequest = (function (_super) {
                    __extends(GetLabelsCommitRequest, _super);
                    function GetLabelsCommitRequest(stat) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'LabelItems';
                        _this._method = "Submit";
                        _this._parameters = { stat: stat };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return GetLabelsCommitRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetLabelsCommitRequest = GetLabelsCommitRequest;
                var GetClearRequest = (function (_super) {
                    __extends(GetClearRequest, _super);
                    function GetClearRequest(labelType) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = 'LabelItems';
                        _this._method = "Clear";
                        _this._parameters = { labelType: labelType };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return GetClearRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetClearRequest = GetClearRequest;
                var LabelItemUpdateResponse = (function (_super) {
                    __extends(LabelItemUpdateResponse, _super);
                    function LabelItemUpdateResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return LabelItemUpdateResponse;
                }(DataService_1.DataServiceResponse));
                Labels.LabelItemUpdateResponse = LabelItemUpdateResponse;
                var LabelItemUpdateRequest = (function (_super) {
                    __extends(LabelItemUpdateRequest, _super);
                    function LabelItemUpdateRequest(item) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems(" + item.Id + ")";
                        _this._method = "UpdateLabelItem";
                        _this._parameters = { patch: item };
                        _this._isAction = true;
                        return _this;
                    }
                    return LabelItemUpdateRequest;
                }(DataService_1.DataServiceRequest));
                Labels.LabelItemUpdateRequest = LabelItemUpdateRequest;
                var LabelItemDeleteRequest = (function (_super) {
                    __extends(LabelItemDeleteRequest, _super);
                    function LabelItemDeleteRequest(item) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems(" + item.Id + ")";
                        _this._method = "DeleteLabelItem";
                        _this._parameters = {};
                        _this._isAction = true;
                        return _this;
                    }
                    return LabelItemDeleteRequest;
                }(DataService_1.DataServiceRequest));
                Labels.LabelItemDeleteRequest = LabelItemDeleteRequest;
                var GetProductDetailsByDataLevelResponse = (function (_super) {
                    __extends(GetProductDetailsByDataLevelResponse, _super);
                    function GetProductDetailsByDataLevelResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetProductDetailsByDataLevelResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetProductDetailsByDataLevelResponse = GetProductDetailsByDataLevelResponse;
                var GetProductDetailsByDataLevelRequest = (function (_super) {
                    __extends(GetProductDetailsByDataLevelRequest, _super);
                    function GetProductDetailsByDataLevelRequest(productSearchCriteria) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "Products";
                        _this._method = "Search";
                        _this._parameters = { productSearchCriteria: productSearchCriteria };
                        _this._isAction = true;
                        _this._returnType = Entities_1.ProxyEntities.ProductClass;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetProductDetailsByDataLevelRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetProductDetailsByDataLevelRequest = GetProductDetailsByDataLevelRequest;
                var GetCategoryHierarchyResponse = (function (_super) {
                    __extends(GetCategoryHierarchyResponse, _super);
                    function GetCategoryHierarchyResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetCategoryHierarchyResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetCategoryHierarchyResponse = GetCategoryHierarchyResponse;
                var GetCategoryHierarchyRequest = (function (_super) {
                    __extends(GetCategoryHierarchyRequest, _super);
                    function GetCategoryHierarchyRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "GetCategoryHierarchy";
                        _this._parameters = {};
                        _this._isAction = false;
                        _this._returnType = Entities_1.ProxyEntities.CategoryClass;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetCategoryHierarchyRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetCategoryHierarchyRequest = GetCategoryHierarchyRequest;
                var GetLabelCodeResponse = (function (_super) {
                    __extends(GetLabelCodeResponse, _super);
                    function GetLabelCodeResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetLabelCodeResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetLabelCodeResponse = GetLabelCodeResponse;
                var GetLabelCodeRequest = (function (_super) {
                    __extends(GetLabelCodeRequest, _super);
                    function GetLabelCodeRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "LabelItems";
                        _this._method = "GetCodes";
                        _this._parameters = {};
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.LabelCode;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetLabelCodeRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetLabelCodeRequest = GetLabelCodeRequest;
                var GetStoreSectionsResponse = (function (_super) {
                    __extends(GetStoreSectionsResponse, _super);
                    function GetStoreSectionsResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetStoreSectionsResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetStoreSectionsResponse = GetStoreSectionsResponse;
                var GetStoreSectionsRequest = (function (_super) {
                    __extends(GetStoreSectionsRequest, _super);
                    function GetStoreSectionsRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetStoreSections";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.StoreSection;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetStoreSectionsRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetStoreSectionsRequest = GetStoreSectionsRequest;
                var GetStoreShelvesResponse = (function (_super) {
                    __extends(GetStoreShelvesResponse, _super);
                    function GetStoreShelvesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetStoreShelvesResponse;
                }(DataService_1.DataServiceResponse));
                Labels.GetStoreShelvesResponse = GetStoreShelvesResponse;
                var GetStoreShelvesRequest = (function (_super) {
                    __extends(GetStoreShelvesRequest, _super);
                    function GetStoreShelvesRequest(sectionId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetStoreShelves";
                        _this._parameters = { sectionId: sectionId };
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.StoreShelf;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetStoreShelvesRequest;
                }(DataService_1.DataServiceRequest));
                Labels.GetStoreShelvesRequest = GetStoreShelvesRequest;
                var UtilitiesConfigurationResponse = (function (_super) {
                    __extends(UtilitiesConfigurationResponse, _super);
                    function UtilitiesConfigurationResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return UtilitiesConfigurationResponse;
                }(DataService_1.DataServiceResponse));
                Labels.UtilitiesConfigurationResponse = UtilitiesConfigurationResponse;
                var UtilitiesConfigurationRequest = (function (_super) {
                    __extends(UtilitiesConfigurationRequest, _super);
                    function UtilitiesConfigurationRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = '';
                        _this._method = "GetUtilitiesConfiguration";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = DataServiceEntities_g_1.Entities.UtilitiesConfiguration;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return UtilitiesConfigurationRequest;
                }(DataService_1.DataServiceRequest));
                Labels.UtilitiesConfigurationRequest = UtilitiesConfigurationRequest;
            })(Labels || (exports_1("Labels", Labels = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/DataService2/DataServiceRequests.g.js.map