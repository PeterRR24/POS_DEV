System.register(["PosApi/Entities"], function (exports_1, context_1) {
    "use strict";
    var Entities_1, Entities;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            (function (Entities) {
                var LabelLayoutType;
                (function (LabelLayoutType) {
                    LabelLayoutType[LabelLayoutType["Shelf"] = 0] = "Shelf";
                    LabelLayoutType[LabelLayoutType["Product"] = 1] = "Product";
                })(LabelLayoutType = Entities.LabelLayoutType || (Entities.LabelLayoutType = {}));
                var LabelItemSearchBy;
                (function (LabelItemSearchBy) {
                    LabelItemSearchBy[LabelItemSearchBy["CategoryHierarchy"] = 0] = "CategoryHierarchy";
                    LabelItemSearchBy[LabelItemSearchBy["LocationHierarchy"] = 1] = "LocationHierarchy";
                    LabelItemSearchBy[LabelItemSearchBy["ItemFilter"] = 2] = "ItemFilter";
                })(LabelItemSearchBy = Entities.LabelItemSearchBy || (Entities.LabelItemSearchBy = {}));
                var LabelItemQtySource;
                (function (LabelItemQtySource) {
                    LabelItemQtySource[LabelItemQtySource["Available"] = 0] = "Available";
                    LabelItemQtySource[LabelItemQtySource["OrderReceived"] = 1] = "OrderReceived";
                    LabelItemQtySource[LabelItemQtySource["Fixed"] = 2] = "Fixed";
                })(LabelItemQtySource = Entities.LabelItemQtySource || (Entities.LabelItemQtySource = {}));
                var LabelItemChangeTracking;
                (function (LabelItemChangeTracking) {
                    LabelItemChangeTracking[LabelItemChangeTracking["None"] = 0] = "None";
                    LabelItemChangeTracking[LabelItemChangeTracking["Price"] = 1] = "Price";
                    LabelItemChangeTracking[LabelItemChangeTracking["PriceAndName"] = 2] = "PriceAndName";
                    LabelItemChangeTracking[LabelItemChangeTracking["OldPrice"] = 3] = "OldPrice";
                })(LabelItemChangeTracking = Entities.LabelItemChangeTracking || (Entities.LabelItemChangeTracking = {}));
                var LabelItem = (function () {
                    function LabelItem(odataObject) {
                        odataObject = odataObject || {};
                        this.Id = (odataObject.Id != null) ? parseInt(odataObject.Id, 10) : undefined;
                        this.ChannelId = (odataObject.ChannelId != null) ? parseInt(odataObject.ChannelId, 10) : undefined;
                        this.ItemId = odataObject.ItemId;
                        this.InventDimId = odataObject.InventDimId;
                        this.LabelTypeValue = odataObject.LabelTypeValue;
                        this.DeviceId = odataObject.DeviceId;
                        this.DateCreated = (odataObject.DateCreated instanceof Date) ? odataObject.DateCreated
                            : (odataObject.DateCreated != null) ? odataObject.DateCreated : undefined;
                        this.DataAreaId = odataObject.DataAreaId;
                        this.Barcode = odataObject.Barcode;
                        this.Name = odataObject.Name;
                        this.Description = odataObject.Description;
                        this.UnitId = odataObject.UnitId;
                        this.BaseUnitId = odataObject.BaseUnitId;
                        this.BaseUnitQty = (odataObject.BaseUnitQty != null) ? parseFloat(odataObject.BaseUnitQty) : undefined;
                        this.EquivUnitId = odataObject.EquivUnitId;
                        this.EquivUnitQty = (odataObject.EquivUnitQty != null) ? parseFloat(odataObject.EquivUnitQty) : undefined;
                        this.UnitPrice = (odataObject.UnitPrice != null) ? parseFloat(odataObject.UnitPrice) : undefined;
                        this.UnitPriceOld = (odataObject.UnitPriceOld != null) ? parseFloat(odataObject.UnitPriceOld) : undefined;
                        this.UnitPriceCurrency = (odataObject.UnitPriceCurrency != null) ? parseFloat(odataObject.UnitPriceCurrency) : undefined;
                        this.SalePrice = (odataObject.SalePrice != null) ? parseFloat(odataObject.SalePrice) : 0.0;
                        this.VariantId = odataObject.VariantId;
                        this.DimColorId = odataObject.DimColorId;
                        this.DimColorName = odataObject.DimColorName;
                        this.DimSizeId = odataObject.DimSizeId;
                        this.DimSizeName = odataObject.DimSizeName;
                        this.DimStyleId = odataObject.DimStyleId;
                        this.DimStyleName = odataObject.DimStyleName;
                        this.DimConfigId = odataObject.DimConfigId;
                        this.DimConfigName = odataObject.DimConfigName;
                        this.SeasonId = odataObject.SeasonId;
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.Department = odataObject.Department;
                        this.Category = odataObject.Category;
                        this.DataRecId = (odataObject.DataRecId != null) ? parseInt(odataObject.DataRecId, 10) : undefined;
                        this.LayoutlId = (odataObject.LayoutlId != null) ? parseInt(odataObject.LayoutlId, 10) : undefined;
                        this.PrinterId = (odataObject.PrinterId != null) ? parseInt(odataObject.PrinterId, 10) : undefined;
                        this.FormatId = (odataObject.FormatId != null) ? parseInt(odataObject.FormatId, 10) : undefined;
                        this.NoOfLabels = (odataObject.NoOfLabels != null) ? parseInt(odataObject.NoOfLabels, 10) : 0;
                        this.Location = (odataObject.Location != null) ? parseInt(odataObject.Location, 10) : 0;
                        this.PrintBatchNo = (odataObject.PrintBatchNo != null) ? parseInt(odataObject.PrintBatchNo, 10) : 0;
                        this.ProductId = (odataObject.ProductId != null) ? parseInt(odataObject.ProductId, 10) : undefined;
                        this.CodeRecId = (odataObject.CodeRecId != null) ? parseInt(odataObject.CodeRecId, 10) : undefined;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return LabelItem;
                }());
                Entities.LabelItem = LabelItem;
                var StoreSection = (function () {
                    function StoreSection(odataObject) {
                        odataObject = odataObject || {};
                        this.SectionId = odataObject.SectionId;
                        this.SectionName = odataObject.SectionName;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreSection;
                }());
                Entities.StoreSection = StoreSection;
                var StoreShelf = (function () {
                    function StoreShelf(odataObject) {
                        odataObject = odataObject || {};
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.SectionName = odataObject.SectionName;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return StoreShelf;
                }());
                Entities.StoreShelf = StoreShelf;
                var PrinterJob = (function () {
                    function PrinterJob(odataObject) {
                        odataObject = odataObject || {};
                        this.PrinterName = odataObject.PrinterName;
                        this.PrinterType = odataObject.PrinterType;
                        this.Document = odataObject.Document;
                        this.LabelData = odataObject.LabelData;
                        this.Template = odataObject.Template;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                if (odataObject.ExtensionProperties[i] != null) {
                                    if (odataObject.ExtensionProperties[i]['@odata.type'] != null) {
                                        var className = odataObject.ExtensionProperties[i]['@odata.type'];
                                        className = className.substr(className.lastIndexOf('.') + 1).concat("Class");
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities[className](odataObject.ExtensionProperties[i]);
                                    }
                                    else {
                                        this.ExtensionProperties[i] = new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]);
                                    }
                                }
                                else {
                                    this.ExtensionProperties[i] = undefined;
                                }
                            }
                        }
                    }
                    return PrinterJob;
                }());
                Entities.PrinterJob = PrinterJob;
                var LabelPrinterTask = (function () {
                    function LabelPrinterTask(odataObject) {
                        odataObject = odataObject || {};
                        this.Quantity = odataObject.Quantity;
                        this.Text = odataObject.Text;
                    }
                    return LabelPrinterTask;
                }());
                Entities.LabelPrinterTask = LabelPrinterTask;
                var LabelItemCalculateItem = (function () {
                    function LabelItemCalculateItem(odataObject) {
                        odataObject = odataObject || {};
                        this.ItemId = odataObject.ItemId;
                        this.ProductId = odataObject.ProductId;
                        this.UnitOfMeasure = odataObject.UnitOfMeasure;
                        this.Quantity = odataObject.Quantity;
                        this.BarCode = odataObject.BarCode;
                    }
                    return LabelItemCalculateItem;
                }());
                Entities.LabelItemCalculateItem = LabelItemCalculateItem;
                var LabelItemCalculateCriteria = (function () {
                    function LabelItemCalculateCriteria(odataObject) {
                        odataObject = odataObject || {};
                        this.SearchOption = odataObject.SearchOption;
                        this.CategoryId = (odataObject.CategoryId != null) ? parseInt(odataObject.CategoryId, 10) : undefined;
                        this.HierarchyId = (odataObject.HierarchyId != null) ? parseInt(odataObject.HierarchyId, 10) : undefined;
                        this.SectionId = odataObject.SectionId;
                        this.ShelfId = odataObject.ShelfId;
                        this.ItemFilter = odataObject.ItemFilter;
                        this.ChangeTracking = odataObject.ChangeTracking;
                        this.QtySource = odataObject.QtySource;
                        this.FromDate = (odataObject.FromDate instanceof Date) ? odataObject.FromDate
                            : (odataObject.FromDate != null) ? odataObject.FromDate : undefined;
                        this.ToDate = (odataObject.ToDate instanceof Date) ? odataObject.ToDate
                            : (odataObject.ToDate != null) ? odataObject.ToDate : undefined;
                        this.Quantity = odataObject.Quantity;
                    }
                    return LabelItemCalculateCriteria;
                }());
                Entities.LabelItemCalculateCriteria = LabelItemCalculateCriteria;
                var LabelItemStatistic = (function () {
                    function LabelItemStatistic(odataObject) {
                        odataObject = odataObject || {};
                        this.LabelTypeValue = odataObject.LabelTypeValue;
                        this.Personal = odataObject.Personal;
                        this.LayoutRecId = (odataObject.LayoutRecId != null) ? parseInt(odataObject.LayoutRecId, 10) : undefined;
                        this.LayoutId = odataObject.LayoutId;
                        this.LayoutName = odataObject.LayoutName;
                        this.LayoutText = odataObject.LayoutText;
                        this.PrinterRecId = (odataObject.PrinterRecId != null) ? parseInt(odataObject.PrinterRecId, 10) : undefined;
                        this.PrinterName = odataObject.PrinterName;
                        this.LabelPrinter = odataObject.LabelPrinter;
                        this.LabelRecIds = odataObject.LabelRecIds == null ? [] : odataObject.LabelRecIds;
                        this.NoOfLabels = odataObject.NoOfLabels;
                        this.ErrorText = odataObject.ErrorText;
                    }
                    return LabelItemStatistic;
                }());
                Entities.LabelItemStatistic = LabelItemStatistic;
                var LabelCode = (function () {
                    function LabelCode(odataObject) {
                        odataObject = odataObject || {};
                        this.Id = (odataObject.Id != null) ? parseInt(odataObject.Id, 10) : undefined;
                        this.Code = odataObject.Code;
                        this.Description = odataObject.Description;
                    }
                    return LabelCode;
                }());
                Entities.LabelCode = LabelCode;
                var LabelItemCalculateParams = (function () {
                    function LabelItemCalculateParams(odataObject) {
                        odataObject = odataObject || {};
                        this.CodeRecId = (odataObject.CodeRecId != null) ? parseInt(odataObject.CodeRecId, 10) : undefined;
                        this.LabelCode = odataObject.LabelCode;
                        this.PriceDate = odataObject.PriceDate;
                    }
                    return LabelItemCalculateParams;
                }());
                Entities.LabelItemCalculateParams = LabelItemCalculateParams;
                var UtilitiesConfiguration = (function () {
                    function UtilitiesConfiguration(odataObject) {
                        odataObject = odataObject || {};
                        this.RangingWithFaces = (odataObject.RangingWithFaces != null) ? parseInt(odataObject.RangingWithFaces, 10) : undefined;
                        this.LabelHierarchyRecId = (odataObject.LabelHierarchyRecId != null) ? parseInt(odataObject.LabelHierarchyRecId, 10) : undefined;
                        this.DefaultLabelProfileRecId = (odataObject.DefaultLabelProfileRecId != null) ? parseInt(odataObject.DefaultLabelProfileRecId, 10) : undefined;
                        this.FireSaleBarcodePrefix = odataObject.FireSaleBarcodePrefix;
                        this.LabelCurrencyCode = odataObject.LabelCurrencyCode;
                        this.DisableLabelWizard = (odataObject.DisableLabelWizard != null) ? parseInt(odataObject.DisableLabelWizard, 10) : undefined;
                        this.BlockSales = (odataObject.BlockSales != null) ? parseInt(odataObject.BlockSales, 10) : undefined;
                    }
                    return UtilitiesConfiguration;
                }());
                Entities.UtilitiesConfiguration = UtilitiesConfiguration;
                var RetailServerError = (function () {
                    function RetailServerError() {
                    }
                    return RetailServerError;
                }());
                Entities.RetailServerError = RetailServerError;
            })(Entities || (exports_1("Entities", Entities = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/DataService2/DataServiceEntities.g.js.map