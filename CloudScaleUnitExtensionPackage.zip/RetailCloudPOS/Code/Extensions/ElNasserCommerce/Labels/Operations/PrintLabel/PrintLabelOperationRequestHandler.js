System.register(["PosApi/Create/Operations", "./PrintLabelOperationRequest"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, PrintLabelOperationRequest_1, PrintLabelOperationRequestHandler;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            },
            function (PrintLabelOperationRequest_1_1) {
                PrintLabelOperationRequest_1 = PrintLabelOperationRequest_1_1;
            }
        ],
        execute: function () {
            PrintLabelOperationRequestHandler = (function (_super) {
                __extends(PrintLabelOperationRequestHandler, _super);
                function PrintLabelOperationRequestHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PrintLabelOperationRequestHandler.prototype.supportedRequestType = function () {
                    return PrintLabelOperationRequest_1.default;
                };
                PrintLabelOperationRequestHandler.prototype.executeAsync = function (request) {
                    var _this = this;
                    this.context.logger.logInformational("Log message from PrintOperationRequestHandler executeAsync().", this.context.logger.getNewCorrelationId());
                    return new Promise(function (resolve) {
                        setTimeout(resolve, 1000);
                        _this.context.navigator.navigate("ItemLabelPrintWzrdView");
                    });
                };
                return PrintLabelOperationRequestHandler;
            }(Operations_1.ExtensionOperationRequestHandlerBase));
            exports_1("default", PrintLabelOperationRequestHandler);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/Operations/PrintLabel/PrintLabelOperationRequestHandler.js.map