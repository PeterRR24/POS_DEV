System.register(["./PrintLabelOperationRequest"], function (exports_1, context_1) {
    "use strict";
    var PrintLabelOperationRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (PrintLabelOperationRequest_1_1) {
                PrintLabelOperationRequest_1 = PrintLabelOperationRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var operationRequest = new PrintLabelOperationRequest_1.default(correlationId);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/Operations/PrintLabel/PrintLabelOperationRequestFactory.js.map