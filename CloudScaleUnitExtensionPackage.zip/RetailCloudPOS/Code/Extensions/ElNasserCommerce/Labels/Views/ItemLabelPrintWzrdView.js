System.register(["knockout", "PosApi/Create/Views", "./ItemLabelPrintWzrdViewModel", "PosApi/TypeExtensions", "PosApi/Consume/Formatters", "PosApi/Consume/Controls", "../DataService2/DataServiceEntities.g", "../Controls/DialogControl/AddLabelDialogModule", "../Controls/DialogControl/ConfirmMessageDialogModule"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, ItemLabelPrintWzrdViewModel_1, TypeExtensions_1, Formatters_1, Controls, DataServiceEntities_g_1, AddLabelDialogModule_1, ConfirmMessageDialogModule_1, ItemLabelPrintWzrdView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (ItemLabelPrintWzrdViewModel_1_1) {
                ItemLabelPrintWzrdViewModel_1 = ItemLabelPrintWzrdViewModel_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (Formatters_1_1) {
                Formatters_1 = Formatters_1_1;
            },
            function (Controls_1) {
                Controls = Controls_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (AddLabelDialogModule_1_1) {
                AddLabelDialogModule_1 = AddLabelDialogModule_1_1;
            },
            function (ConfirmMessageDialogModule_1_1) {
                ConfirmMessageDialogModule_1 = ConfirmMessageDialogModule_1_1;
            }
        ],
        execute: function () {
            ItemLabelPrintWzrdView = (function (_super) {
                __extends(ItemLabelPrintWzrdView, _super);
                function ItemLabelPrintWzrdView(context) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("MAX_LABEL_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "importBarcodes",
                                    label: context.resources.getString('CMD_IMPORT_BUTTON'),
                                    icon: NewView.Icons.ProductList,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.importBarcodeOperation();
                                    }
                                },
                                {
                                    name: "changelabelQuantity",
                                    label: context.resources.getString('CMD_EDIT_QUANTITY'),
                                    icon: NewView.Icons.Edit,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.changeQuantityOperation();
                                    }
                                },
                                {
                                    name: "searchLabelByFilter",
                                    label: context.resources.getString('CMD_PRINT_WIZARD_TEXT'),
                                    icon: NewView.Icons.Filter,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.searchLabelByFilterOperation();
                                    }
                                },
                                {
                                    name: "searchLabelByBarcode",
                                    label: context.resources.getString('CMD_PRINT_BY_BARCODE_TEXT'),
                                    icon: NewView.Icons.Search,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.searchByBarcodeOperation();
                                    }
                                },
                                {
                                    name: "printlabelitems",
                                    label: context.resources.getString('CMD_PRINT_TEXT'),
                                    icon: NewView.Icons.Print,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.printLabelsOperation();
                                    }
                                },
                                {
                                    name: "deletelabelitems",
                                    label: context.resources.getString('CMD_DELETE_TEXT'),
                                    icon: NewView.Icons.Delete,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.deleteItemOperation();
                                    }
                                },
                                {
                                    name: "clearlabelitems",
                                    label: context.resources.getString('CMD_CLEAR_TEXT'),
                                    icon: NewView.Icons.ClearSelection,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.clearOperation();
                                    }
                                }
                            ]
                        }
                    }) || this;
                    _this.viewModel = new ItemLabelPrintWzrdViewModel_1.default(context, _this.state);
                    _this.isShowWizard = knockout_1.default.observable(true);
                    _this.currentPage = knockout_1.default.observable(0);
                    _this.prevPage = knockout_1.default.observable(0);
                    _this.page0Visible = knockout_1.default.computed(function () { return _this.currentPage() === 0; });
                    _this.page1Visible = knockout_1.default.computed(function () { return _this.currentPage() === 1; });
                    _this.page2Visible = knockout_1.default.computed(function () { return _this.currentPage() === 2; });
                    _this.page3Visible = knockout_1.default.computed(function () { return _this.currentPage() === 3; });
                    _this.btnNextEnable = knockout_1.default.computed(function () { return _this.currentPage() != 3 && _this.viewModel.enableWizardNext(); });
                    _this.btnBackEnable = knockout_1.default.computed(function () { return _this.currentPage() != 1; });
                    _this.btnFinishEnable = knockout_1.default.computed(function () { return _this.currentPage() == 3; });
                    _this.arrLabelTypes = knockout_1.default.observableArray([
                        { LabelType: "Product", Value: 1 },
                        { LabelType: "Shelf", Value: 0 }
                    ]);
                    var self = _this;
                    _this.selectedLblTypeText = knockout_1.default.computed(function () {
                        return self.viewModel.labelType() === 1 ? 'Product' : (self.viewModel.labelType() === 0 ? 'Shelf' : '');
                    }, _this);
                    _this.selectedLblCodeText = knockout_1.default.computed(function () {
                        return (self.viewModel.selectedLC() == null || self.viewModel.selectedLC().Id == null)
                            ? self.context.resources.getString("NONE")
                            : self.viewModel.selectedLC().Code.toString() + ' : ' + self.viewModel.selectedLC().Description.toString();
                    }, _this);
                    _this.isProductHierarchy = knockout_1.default.computed(function () { return _this.viewModel.selectedOptionValue() === 'CategoryHierarchy'; });
                    _this.isLocationHierarchy = knockout_1.default.computed(function () { return _this.viewModel.selectedOptionValue() === 'LocationHierarchy'; });
                    _this.isItemFilter = knockout_1.default.computed(function () { return _this.viewModel.selectedOptionValue() === 'ItemFilter'; });
                    _this.isTree = knockout_1.default.computed(function () {
                        return false;
                    }, _this);
                    return _this;
                }
                ItemLabelPrintWzrdView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var paginatedDataSource = {
                        pageSize: this.viewModel.PageSize,
                        loadDataPage: this.viewModel.loadDataPage.bind(this.viewModel)
                    };
                    var dataListOptions = {
                        columns: [
                            {
                                title: this.context.resources.getString("LABEL_ITEM_ID"),
                                ratio: 10,
                                collapseOrder: 9,
                                minWidth: 90,
                                computeValue: function (rowData) { return rowData.ItemId; }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_NAME"),
                                ratio: 28,
                                collapseOrder: 5,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.Name; }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_PRICE_ORIGINAL"),
                                ratio: 8,
                                collapseOrder: 6,
                                minWidth: 90,
                                computeValue: function (rowData) { return Formatters_1.CurrencyFormatter.toCurrency(rowData.UnitPriceOld); }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_PRICE"),
                                ratio: 8,
                                collapseOrder: 7,
                                minWidth: 90,
                                computeValue: function (rowData) { return Formatters_1.CurrencyFormatter.toCurrency(rowData.UnitPrice); }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_DIM_COLOR"),
                                ratio: 10,
                                collapseOrder: 4,
                                minWidth: 90,
                                computeValue: function (rowData) { return rowData.DimColorName || rowData.DimColorId; }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_DIM_CONFIG"),
                                ratio: 10,
                                collapseOrder: 3,
                                minWidth: 90,
                                computeValue: function (rowData) { return rowData.DimConfigName || rowData.DimConfigId; }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_DIM_STYLE"),
                                ratio: 10,
                                collapseOrder: 2,
                                minWidth: 90,
                                computeValue: function (rowData) { return rowData.DimStyleName || rowData.DimStyleId; }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_DIM_SIZE"),
                                ratio: 10,
                                collapseOrder: 1,
                                minWidth: 90,
                                computeValue: function (rowData) { return rowData.DimSizeName || rowData.DimSizeId; }
                            },
                            {
                                title: this.context.resources.getString("LABEL_ITEM_LABELS"),
                                ratio: 6,
                                collapseOrder: 8,
                                minWidth: 70,
                                computeValue: function (rowData) { return rowData.NoOfLabels.toString(); }
                            }
                        ],
                        data: paginatedDataSource,
                        interactionMode: Controls.DataListInteractionMode.MultiSelect,
                    };
                    var dataListRootElem = element.querySelector("#labelitemsview");
                    this.paginatedDataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "PaginatedDataList", dataListOptions, dataListRootElem);
                    this.paginatedDataList.addEventListener("SelectionChanged", function (eventData) {
                        _this.viewModel.setSelectedItems(eventData.items);
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'changelabelQuantity'; }).canExecute = _this.viewModel.allowEdit();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'deletelabelitems'; }).canExecute = _this.viewModel.allowDelete();
                    });
                    this.paginatedDataList.addEventListener("ItemInvoked", function (eventData) {
                        _this.viewModel.noOfLabelEditor(eventData.item);
                    });
                    var datePickerOptios = { date: new Date(), enabled: true };
                    var divPriceDate = element.querySelector("#divPriceDate");
                    this.priceDatePicker = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DatePicker", datePickerOptios, divPriceDate);
                    this.priceDatePicker.addEventListener("DateChanged", function (eventData) {
                        _this.viewModel.priceDate(eventData.date);
                    });
                    TypeExtensions_1.ArrayExtensions.firstOrUndefined(this.state.commandBar.commands, function (c) { return c.name === 'clearlabelitems'; }).canExecute = this.viewModel.allowClear();
                    TypeExtensions_1.ArrayExtensions.firstOrUndefined(this.state.commandBar.commands, function (c) { return c.name === 'printlabelitems'; }).canExecute = this.viewModel.allowPrint();
                    this.viewModel.labelitemsQuantityHandler = (function () {
                        _this.LabelItemQuantityDialogActivity();
                    });
                    this.viewModel.refreshLabelListHandler = (function () {
                        _this.reloadItemList();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'clearlabelitems'; }).canExecute = _this.viewModel.allowClear();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'printlabelitems'; }).canExecute = _this.viewModel.allowPrint();
                    });
                };
                ItemLabelPrintWzrdView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                ItemLabelPrintWzrdView.prototype.onShown = function () {
                    this.isShowWizard(false);
                    $('.category ul').hide();
                    var rooNodes = document.querySelectorAll('.rootCategory');
                    for (var i = 0; i < rooNodes.length; i++) {
                        rooNodes[i].addEventListener('click', function (e) {
                            var element = e.target;
                            if (element && element.tagName.toLowerCase() === 'label') {
                                var eleTags = document.querySelectorAll('.rootCategory label');
                                for (var i = 0; i < eleTags.length; i++) {
                                    eleTags[i].classList.remove("accentBackground");
                                }
                                element.classList.add("accentBackground");
                            }
                        });
                    }
                };
                ItemLabelPrintWzrdView.prototype.reloadItemList = function () {
                    this.paginatedDataList.reloadData();
                    this.viewModel.selectedLabelItems([]);
                };
                ItemLabelPrintWzrdView.prototype.searchClickHandler = function () {
                    this.reloadItemList();
                };
                ItemLabelPrintWzrdView.prototype.SelectCatHandler = function (self, data, element) {
                    self.viewModel.categoryId(data.value.RecordId);
                    self.viewModel.hierarchyId(0);
                    self.viewModel.enableWizardNext(true);
                };
                ItemLabelPrintWzrdView.prototype.ToggleCatHandler = function (self, data, element) {
                    var src = element.currentTarget;
                    $(src).siblings('ul').slideToggle('slow');
                };
                ItemLabelPrintWzrdView.prototype.ToggleLocHandler = function (self, data, element) {
                    var src = element.currentTarget;
                    $(src).siblings('ul').slideToggle('slow');
                };
                ItemLabelPrintWzrdView.prototype.SelectLocHandler = function (self, data, element) {
                    self.viewModel.sectionId(data.SectionId);
                    self.viewModel.shelfId(data.ShelfId);
                    self.viewModel.enableWizardNext(true);
                };
                ItemLabelPrintWzrdView.prototype.AddItemHandler = function () {
                    this.viewModel.calculateItemBarcode();
                };
                ItemLabelPrintWzrdView.prototype.OkHandler = function () {
                    var no = this.prevPage() == 0 ? 1 : this.prevPage();
                    this.currentPage(no);
                    this.isShowWizard(true);
                    this.viewModel.enableWizardNext(true);
                };
                ItemLabelPrintWzrdView.prototype.BackHandler = function () {
                    var no = this.currentPage();
                    this.prevPage(no - 1);
                    this.currentPage(no - 1);
                    this.viewModel.enableWizardNext(true);
                };
                ItemLabelPrintWzrdView.prototype.NextHandler = function () {
                    var no = this.currentPage();
                    this.prevPage(no + 1);
                    this.currentPage(no + 1);
                    if (this.currentPage() == 0) {
                        this.currentPage(1);
                    }
                    else if (this.currentPage() == 2 && this.isProductHierarchy()) {
                        this.viewModel.getCategoryList();
                        this.viewModel.enableWizardNext(false);
                        if (this.viewModel.categoryId() != null) {
                            this.viewModel.enableWizardNext(true);
                        }
                    }
                    else if (this.currentPage() == 2 && this.isLocationHierarchy()) {
                        this.viewModel.getStoreSections();
                        this.viewModel.getStoreShelves();
                        this.viewModel.enableWizardNext(false);
                        if (this.viewModel.sectionId() != "") {
                            this.viewModel.enableWizardNext(true);
                        }
                    }
                    else if (this.currentPage() == 2 && this.isItemFilter()) {
                        this.viewModel.enableWizardNext(false);
                        if (this.viewModel.itemFilterText() != "") {
                            this.viewModel.enableWizardNext(true);
                        }
                        else {
                            var eleTags = document.querySelector('input.item-filter');
                            eleTags.focus();
                        }
                    }
                    else {
                        this.viewModel.enableWizardNext(false);
                    }
                };
                ItemLabelPrintWzrdView.prototype.CancelWizardHandler = function () {
                    this.isShowWizard(false);
                };
                ItemLabelPrintWzrdView.prototype.FinishHandler = function () {
                    this.viewModel.calculateItemsOnWizard();
                    this.isShowWizard(false);
                };
                ItemLabelPrintWzrdView.prototype.CancelPrintHandler = function () {
                    this.viewModel.printStatDialog(false);
                };
                ItemLabelPrintWzrdView.prototype.OkPrintHandler = function () {
                    this.viewModel.printSelectedLabelLayout();
                };
                ItemLabelPrintWzrdView.prototype.selectAllStatistics = function (mngr, element) {
                    var chk = element.target.checked;
                    var stats = mngr.viewModel.labelItemStatistics();
                    for (var i = 0; i < stats.length; i++) {
                        if (stats[i].IsEnable()) {
                            stats[i].IsSelect(chk);
                        }
                    }
                    mngr.viewModel.labelItemStatistics([]);
                    mngr.viewModel.labelItemStatistics(stats);
                    return true;
                };
                ItemLabelPrintWzrdView.prototype.clearOperation = function () {
                    var _this = this;
                    var dialog = new ConfirmMessageDialogModule_1.default();
                    dialog.open(this.context.resources.getString("CONFIRM_CLEAR_LABEL_ITEMS"))
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            _this.viewModel.clear();
                            _this.viewModel.searchText();
                        }
                    }).catch(function (reason) {
                        _this.context.logger.logError("ItemLabelPrintWzrdView clearOperation confirmation: " + JSON.stringify(reason));
                    });
                };
                ItemLabelPrintWzrdView.prototype.deleteItemOperation = function () {
                    var _this = this;
                    if (!this.viewModel.allowDelete())
                        return;
                    var dialog = new ConfirmMessageDialogModule_1.default();
                    dialog.open(this.context.resources.getString("CONFIRM_DELETE_LABEL_ITEM"))
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            _this.viewModel.deleteItem();
                        }
                    }).catch(function (reason) {
                        _this.context.logger.logError("ItemLabelPrintWzrdView deleteItemOperation confirmation: " + JSON.stringify(reason));
                    });
                };
                ItemLabelPrintWzrdView.prototype.printLabelsOperation = function () {
                    if (this.viewModel.selectedLabelItems().length == 1) {
                        this.viewModel.printSelectedLabels();
                    }
                    else if (this.viewModel.selectedLabelItems().length > 1) {
                        this.viewModel.calculateStatistics();
                    }
                    else {
                        this.viewModel.calculateStatistics();
                    }
                };
                ItemLabelPrintWzrdView.prototype.searchByBarcodeOperation = function () {
                    this.viewModel.showWizard(false);
                    this.showlabelPrintWizardOperation();
                };
                ItemLabelPrintWzrdView.prototype.searchLabelByFilterOperation = function () {
                    this.viewModel.showWizard(true);
                    this.showlabelPrintWizardOperation();
                };
                ItemLabelPrintWzrdView.prototype.showlabelPrintWizardOperation = function () {
                    $('.category ul').hide();
                    $(".rootCategory label").removeClass("accentBackground");
                    var eleTags = document.querySelectorAll('.rootCategory label');
                    for (var i = 0; i < eleTags.length; i++) {
                        eleTags[i].classList.remove("accentBackground");
                    }
                    this.isShowWizard(true);
                    this.viewModel.resetWizardParameter();
                    this.prevPage(1);
                    this.currentPage(1);
                    this.viewModel.enableWizardNext(true);
                    this.viewModel.barCodeNotFoundMsg('');
                    this.viewModel.itemBarCode('');
                    this.viewModel.barCodeLabelQuantity('');
                };
                ItemLabelPrintWzrdView.prototype.changeQuantityOperation = function () {
                    this.LabelItemQuantityDialogActivity();
                };
                ItemLabelPrintWzrdView.prototype.LabelItemQuantityDialogActivity = function () {
                    var _this = this;
                    var item = this.viewModel.selectedLabelItems()[0];
                    if (item == null && !this.viewModel.allowEdit())
                        return;
                    var dialog = new AddLabelDialogModule_1.default(this.viewModel.labelType(), false);
                    dialog.open(this.context.resources.getString('PRINT_LABEL_QTY'), item.Description, item.NoOfLabels + "", [])
                        .then(function (result) {
                        if (result.selectedValue !== 'Closed') {
                            var quantity = parseInt(result.selectedValue);
                            if (isNaN(quantity)) {
                                _this.context.logger.logError("Please enter numbers only!");
                                return;
                            }
                            if (quantity <= 0) {
                                _this.context.logger.logError("The label printing quantity cannot be zero or negative");
                                return;
                            }
                            _this.viewModel.updatelabelitem(quantity);
                        }
                    }).catch(function (reason) {
                        _this.context.logger.logError("ItemLabelPrintWzrdView.openTemplatedDialog: " + JSON.stringify(reason));
                    });
                };
                ItemLabelPrintWzrdView.prototype.importBarcodeOperation = function () {
                    document.getElementById('barCodeFilePath').click();
                };
                ItemLabelPrintWzrdView.prototype.FileDialogHandler = function (self, evt) {
                    var _this = this;
                    var file = evt.currentTarget.files[0];
                    this.getFileData(file)
                        .then(function (data) {
                        if (typeof data === 'string' || data instanceof String) {
                            var ipStrs = data.split('\r\n');
                            console.log(ipStrs);
                            var barCodes_1 = ipStrs.map(function (n) { return n.trim(); });
                            if (!barCodes_1.length)
                                return;
                            var dialog = new AddLabelDialogModule_1.default(_this.viewModel.labelType(), true, 0, true, false);
                            dialog.open(_this.context.resources.getString('PRINT_LABEL_QTY'), "", "1", _this.viewModel.labelCodes())
                                .then(function (result) {
                                _this.context.logger.logInformational("Dialog result: " + result.selectedValue);
                                if (result.selectedValue == 'Closed') {
                                    return;
                                }
                                var labelCode = result.labelCode;
                                var labelType = parseInt(result.itemLabelType);
                                console.log(labelType);
                                var labelCalcParam = new DataServiceEntities_g_1.Entities.LabelItemCalculateParams();
                                labelCalcParam.CodeRecId = isNaN(labelCode.Id) ? 0 : labelCode.Id;
                                labelCalcParam.PriceDate = result.priceDate;
                                _this.viewModel.calculateImportBarcodes(labelType, barCodes_1, labelCalcParam);
                            }).catch(function (reason) {
                                _this.context.logger.logError("Dialog error: " + JSON.stringify(reason));
                            });
                        }
                    }).then(function () {
                        document.getElementById('barCodeFilePath').value = '';
                    });
                };
                ItemLabelPrintWzrdView.prototype.getFileData = function (file) {
                    return new Promise(function (resolve, reject) {
                        var reader = new FileReader();
                        reader.readAsText(file);
                        reader.onload = function () { return resolve(reader.result); };
                        reader.onerror = function (error) { return reject(error); };
                    });
                };
                return ItemLabelPrintWzrdView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", ItemLabelPrintWzrdView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/Views/ItemLabelPrintWzrdView.js.map