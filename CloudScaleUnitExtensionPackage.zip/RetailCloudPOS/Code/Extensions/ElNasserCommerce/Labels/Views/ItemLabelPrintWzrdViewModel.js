System.register(["knockout", "PosApi/TypeExtensions", "../DataService2/DataServiceRequests.g", "../DataService2/DataServiceEntities.g", "PosApi/Consume/Peripherals", "../Controls/DialogControl/ConfirmMessageDialogModule", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, TypeExtensions_1, DataServiceRequests_g_1, DataServiceEntities_g_1, Peripherals_1, ConfirmMessageDialogModule_1, ErrorHelper_1, ItemLabelPrintWzrdViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (Peripherals_1_1) {
                Peripherals_1 = Peripherals_1_1;
            },
            function (ConfirmMessageDialogModule_1_1) {
                ConfirmMessageDialogModule_1 = ConfirmMessageDialogModule_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ItemLabelPrintWzrdViewModel = (function () {
                function ItemLabelPrintWzrdViewModel(context, baseState) {
                    var _this = this;
                    this.PageSize = 100;
                    this._context = context;
                    this.state = baseState;
                    var date = new Date();
                    var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                    this.selectedLabelItems = knockout_1.default.observableArray([]);
                    this.searchItems = knockout_1.default.observableArray([]);
                    this.labelItem = knockout_1.default.observable({});
                    this.labelItemStatistics = knockout_1.default.observableArray([]);
                    this.categories = knockout_1.default.observableArray([]);
                    this.categoryTree = knockout_1.default.observableArray([]);
                    this.storeSections = knockout_1.default.observableArray([]);
                    this.storeShelves = knockout_1.default.observableArray([]);
                    this.locationTree = knockout_1.default.observableArray([]);
                    this.labelCodes = knockout_1.default.observableArray([]);
                    this.labelType = knockout_1.default.observable(1);
                    this.allowPrint = knockout_1.default.computed(function () { return _this.labelType() != 2; });
                    this.allowClear = knockout_1.default.computed(function () { return _this.labelType() != 2; });
                    this.allowDelete = knockout_1.default.computed(function () { return _this.selectedLabelItems().length > 0; });
                    this.allowCommit = knockout_1.default.observable(false);
                    this.showWizard = knockout_1.default.observable(false);
                    this.itemBarCode = knockout_1.default.observable('');
                    this.barCodeLabelQuantity = knockout_1.default.observable('');
                    this.barCodeNotFoundMsg = knockout_1.default.observable('');
                    this.allowEdit = knockout_1.default.computed(function () { return _this.selectedLabelItems().length == 1; });
                    this.searchText = knockout_1.default.observable("");
                    this.printStatDialog = knockout_1.default.observable(false);
                    this.labelCalcParam = new DataServiceEntities_g_1.Entities.LabelItemCalculateParams();
                    this.selectedLC = knockout_1.default.observable(null);
                    this.selectedOptionValue = knockout_1.default.observable("CategoryHierarchy");
                    this.selectedQtySource = knockout_1.default.observable("Available");
                    this.changeTracking = knockout_1.default.observable("None");
                    this.fromDate = knockout_1.default.observable(null);
                    this.toDate = knockout_1.default.observable(null);
                    this.priceDate = knockout_1.default.observable(today);
                    this.itemFilterText = knockout_1.default.observable("");
                    this.itemQuantity = knockout_1.default.observable(0);
                    this.categoryId = knockout_1.default.observable(null);
                    this.hierarchyId = knockout_1.default.observable(null);
                    this.sectionId = knockout_1.default.observable("");
                    this.shelfId = knockout_1.default.observable("");
                    var self = this;
                    this.labelType.subscribe(function (a) {
                        self.updateLabelList();
                    }, this);
                    this.enableWizardNext = knockout_1.default.observable(true);
                    this.itemFilterText.subscribe(function () {
                        if (self.itemFilterText() == "") {
                            self.enableWizardNext(false);
                        }
                        else {
                            self.enableWizardNext(true);
                        }
                    }, this);
                    this.enablePrintCancel = knockout_1.default.observable(false);
                    this.enablePrintOk = knockout_1.default.computed(function () {
                        return !(_this.labelItemStatistics().every(function (element) {
                            return element.IsSelect() == false;
                        })) && _this.enablePrintCancel();
                    });
                    this.getLabelCodes();
                    this._context.logger.logInformational("ItemLabelPrintWzrdViewModel: success");
                }
                ItemLabelPrintWzrdViewModel.prototype.loadDataPage = function (size, skip) {
                    var _this = this;
                    var timeOut = skip == 0 ? 0 : 1000;
                    var promise = new Promise(function (resolve) {
                        setTimeout(function () {
                            _this._context.logger.logInformational("dataListPageLoaded");
                            var pageData = _this.searchLabelItems(size, skip);
                            resolve(pageData);
                        }, timeOut);
                    });
                    return promise;
                };
                ItemLabelPrintWzrdViewModel.prototype.searchLabelItems = function (size, skip) {
                    var _this = this;
                    if (TypeExtensions_1.StringExtensions.isNullOrWhitespace(this.searchText())) {
                        this.searchText("");
                    }
                    var search = this.searchText();
                    this.state.isProcessing = true;
                    var request = new DataServiceRequests_g_1.Labels.GetLabelItemRequest(this.labelType(), search, size, skip);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.searchItems(result.data.result);
                            return result.data.result;
                        }
                        else
                            return [];
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Print label search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        return [];
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.updateLabelQuantity = function () {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.labelitemsQuantityHandler)) {
                        this.labelitemsQuantityHandler();
                    }
                };
                ItemLabelPrintWzrdViewModel.prototype.updateLabelList = function () {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.refreshLabelListHandler)) {
                        this.refreshLabelListHandler();
                    }
                };
                ItemLabelPrintWzrdViewModel.prototype.resetWizardParameter = function () {
                    this.selectedOptionValue("CategoryHierarchy");
                    this.selectedQtySource("Available");
                    this.changeTracking("None");
                    this.itemFilterText("");
                    this.itemQuantity(0);
                    this.categoryId(null);
                    this.hierarchyId(null);
                    this.sectionId("");
                    this.shelfId("");
                    this.getLabelCodes();
                };
                ItemLabelPrintWzrdViewModel.prototype.clearParameters = function () {
                    this.searchText("");
                };
                ItemLabelPrintWzrdViewModel.prototype.getCategoryList = function () {
                    var _this = this;
                    if (this.categories().length > 0)
                        return;
                    this.state.isProcessing = true;
                    var request = new DataServiceRequests_g_1.Labels.GetCategoryHierarchyRequest();
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.categories(result.data.result);
                            _this.arrangeCategories(result.data.result);
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Getting category error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.calculateItem = function (labelType, calculateItems) {
                    var _this = this;
                    this.state.isProcessing = true;
                    var request = new DataServiceRequests_g_1.Labels.CalculateLabelItemRequest(labelType, this.labelCalcParam, calculateItems, null, 0);
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Print label calculate error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.deleteItem = function () {
                    var _this = this;
                    this.state.isProcessing = true;
                    var completeCount = 0;
                    for (var i = 0; i < this.selectedLabelItems().length; i++) {
                        var delRequest = new DataServiceRequests_g_1.Labels.LabelItemDeleteRequest(this.selectedLabelItems()[i]);
                        this._context.runtime.executeAsync(delRequest)
                            .then(function () {
                            completeCount += 1;
                            if (_this.selectedLabelItems().length == completeCount) {
                                _this.state.isProcessing = false;
                                _this.updateLabelList();
                                _this.selectedLabelItems([]);
                            }
                        })
                            .catch(function () {
                            _this.state.isProcessing = false;
                            if (completeCount != 0)
                                _this.updateLabelList();
                        });
                    }
                };
                ItemLabelPrintWzrdViewModel.prototype.printSelectedLabels = function (idx) {
                    var _this = this;
                    if (idx === void 0) { idx = 0; }
                    this.state.isProcessing = true;
                    var item = this.selectedLabelItems()[idx];
                    var labelFormatRequest = new DataServiceRequests_g_1.Labels.GetLabelItemFormatRequest(item.Id, item.NoOfLabels);
                    this._context.runtime.executeAsync(labelFormatRequest)
                        .then(function (result) {
                        if (!result.canceled) {
                            var _commerce_1 = Commerce;
                            var printerJob = result.data.result;
                            var printRequest = {};
                            if (printerJob.PrinterType == "SHARPSHOOTER") {
                                var deviceConfig = new Commerce.Proxy.Entities.DeviceConfigurationClass(JSON.parse(_commerce_1.ApplicationStorage.getItem(_commerce_1.ApplicationStorageIDs.DEVICE_CONFIGURATION_KEY)));
                                var header = "CultureName=" + deviceConfig.CultureName + ";Currency=" + deviceConfig.Currency + ";Store=" + deviceConfig.StoreNumber + ";Terminal=" + deviceConfig.TerminalId + ";LabelType=" + _this.labelType();
                                printRequest = {
                                    DeviceName: printerJob.PrinterName,
                                    DeviceType: printerJob.PrinterType,
                                    Lines: printerJob.LabelData,
                                    Header: JSON.stringify(header),
                                    Footer: printerJob.Template
                                };
                            }
                            else {
                                printRequest = {
                                    DeviceName: printerJob.PrinterName,
                                    DeviceType: printerJob.PrinterType,
                                    Lines: printerJob.Document
                                };
                            }
                            var hsRequest = new Peripherals_1.HardwareStationDeviceActionRequest("PRINTER", "Print", [printRequest]);
                            var oldTimeOut_1;
                            if (_commerce_1.ApplicationSession.instance.posConfiguration) {
                                oldTimeOut_1 = _commerce_1.ApplicationSession.instance.posConfiguration.connectionTimeout;
                                _commerce_1.ApplicationSession.instance.posConfiguration._connectionTimeout = 1800;
                            }
                            _this._context.runtime.executeAsync(hsRequest)
                                .then(function () {
                                if (_commerce_1.ApplicationSession.instance.posConfiguration) {
                                    _commerce_1.ApplicationSession.instance.posConfiguration._connectionTimeout = oldTimeOut_1;
                                }
                                _this.state.isProcessing = false;
                                var confirmDialog = new ConfirmMessageDialogModule_1.default(true);
                                var confrmMsg = TypeExtensions_1.StringExtensions.format(_this._context.resources.getString("CONFIRM_LABEL_PRINT_COMPLETE"), _this._context.resources.getString("ITEM_TXT"), item.Description || item.Name);
                                confirmDialog.open(confrmMsg)
                                    .then(function (result) {
                                    if (result.selectedValue == 'Reprint') {
                                        _this.printSelectedLabels(idx);
                                    }
                                    else if (result.selectedValue !== 'Closed') {
                                        _this.state.isProcessing = true;
                                        var commitRequest = new DataServiceRequests_g_1.Labels.CommitLabelItemRequest(item.Id);
                                        _this._context.runtime.executeAsync(commitRequest)
                                            .then(function () {
                                            _this.state.isProcessing = false;
                                            idx = idx + 1;
                                            if (idx < _this.selectedLabelItems().length) {
                                                _this.printSelectedLabels(idx);
                                            }
                                            else {
                                                _this.updateLabelList();
                                                _this.printStatDialog(false);
                                            }
                                        });
                                    }
                                    else {
                                        if (idx > 0)
                                            _this.updateLabelList();
                                    }
                                }).catch(function (reason) {
                                    _this._context.logger.logError("Selected label item printOperation complete confirmation: " + JSON.stringify(reason));
                                    _this.state.isProcessing = false;
                                });
                            })
                                .catch(function (reason) {
                                if (_commerce_1.ApplicationSession.instance.posConfiguration) {
                                    _commerce_1.ApplicationSession.instance.posConfiguration._connectionTimeout = oldTimeOut_1;
                                }
                                _this.state.isProcessing = false;
                                _this._context.logger.logError("Print label execute error: " + JSON.stringify(reason));
                                ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                            });
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Print label execute error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.printSelectedLabelLayout = function () {
                    var rrCommerce = Commerce;
                    if (rrCommerce.ApplicationStorage.getItem(rrCommerce.ApplicationStorageIDs.HARDWARE_STATION_FEATURE_ENABLE) != "true") {
                        ErrorHelper_1.ErrorHelper.displayMessageAsync(this._context, this._context.resources.getString("HARDWARE_STATION_REQUIRED_FOR_PRINT_OPERATION"));
                        return;
                    }
                    this.enablePrintCancel(false);
                    var stats = [];
                    for (var i = 0; i < this.labelItemStatistics().length; i++) {
                        if (this.labelItemStatistics()[i].IsSelect()) {
                            stats[i] = this.labelItemStatistics()[i].statistic;
                        }
                    }
                    this.printLayouts(0, stats);
                };
                ItemLabelPrintWzrdViewModel.prototype.printLayouts = function (idx, stats) {
                    var _this = this;
                    var itemStat = stats[idx];
                    itemStat.LabelRecIds = '';
                    var labelIds = [];
                    if (this.selectedLabelItems().length > 1) {
                        this.selectedLabelItems().forEach(function (item) { return labelIds.push(item.Id); });
                        itemStat.LabelRecIds = labelIds.toString();
                    }
                    var request = new DataServiceRequests_g_1.Labels.GetLabelsFormatRequest(itemStat);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (!result.canceled) {
                            var printerJob = result.data.result;
                            var _commerce_2 = Commerce;
                            var printRequest = {};
                            if (printerJob.PrinterType == "SHARPSHOOTER") {
                                var deviceConfig = new Commerce.Proxy.Entities.DeviceConfigurationClass(JSON.parse(_commerce_2.ApplicationStorage.getItem(_commerce_2.ApplicationStorageIDs.DEVICE_CONFIGURATION_KEY)));
                                var header = "CultureName=" + deviceConfig.CultureName + ";Currency=" + deviceConfig.Currency + ";Store=" + deviceConfig.StoreNumber + ";Terminal=" + deviceConfig.TerminalId + ";LabelType=" + _this.labelType();
                                printRequest = {
                                    DeviceName: printerJob.PrinterName,
                                    DeviceType: printerJob.PrinterType,
                                    Lines: printerJob.LabelData,
                                    Header: JSON.stringify(header),
                                    Footer: printerJob.Template
                                };
                            }
                            else {
                                printRequest = {
                                    DeviceName: printerJob.PrinterName,
                                    DeviceType: printerJob.PrinterType,
                                    Lines: printerJob.Document
                                };
                            }
                            var hsRequest = new Peripherals_1.HardwareStationDeviceActionRequest("PRINTER", "Print", [printRequest]);
                            var oldTimeOut_2;
                            if (_commerce_2.ApplicationSession.instance.posConfiguration) {
                                oldTimeOut_2 = _commerce_2.ApplicationSession.instance.posConfiguration.connectionTimeout;
                                _commerce_2.ApplicationSession.instance.posConfiguration._connectionTimeout = 3600;
                            }
                            _this._context.runtime.executeAsync(hsRequest)
                                .then(function () {
                                if (_commerce_2.ApplicationSession.instance.posConfiguration) {
                                    _commerce_2.ApplicationSession.instance.posConfiguration._connectionTimeout = oldTimeOut_2;
                                }
                                _this.state.isProcessing = false;
                                var confirmDialog = new ConfirmMessageDialogModule_1.default(true);
                                var confrmMsg = TypeExtensions_1.StringExtensions.format(_this._context.resources.getString("CONFIRM_LABEL_PRINT_COMPLETE"), _this._context.resources.getString("LAYOUT_TXT"), itemStat.LayoutName || itemStat.LayoutId);
                                confirmDialog.open(confrmMsg)
                                    .then(function (result) {
                                    if (result.selectedValue == 'Reprint') {
                                        _this.printLayouts(idx, stats);
                                    }
                                    else if (result.selectedValue !== 'Closed') {
                                        _this.state.isProcessing = true;
                                        if (_this.selectedLabelItems().length > 1) {
                                            var commitRequest = new DataServiceRequests_g_1.Labels.CommitLabelItemsRequest(labelIds);
                                            _this._context.runtime.executeAsync(commitRequest)
                                                .then(function () {
                                                _this.state.isProcessing = false;
                                                _this.updateLabelList();
                                                _this.printStatDialog(false);
                                            });
                                        }
                                        else {
                                            var commitRequest = new DataServiceRequests_g_1.Labels.GetLabelsCommitRequest(itemStat);
                                            _this._context.runtime.executeAsync(commitRequest)
                                                .then(function () {
                                                _this.state.isProcessing = false;
                                                idx = idx + 1;
                                                if (idx < stats.length) {
                                                    _this.printLayouts(idx, stats);
                                                }
                                                else {
                                                    _this.updateLabelList();
                                                    _this.printStatDialog(false);
                                                }
                                            });
                                        }
                                    }
                                    else {
                                        if (idx > 0) {
                                            _this.updateLabelList();
                                        }
                                        _this.printStatDialog(false);
                                    }
                                }).catch(function (reason) {
                                    _this._context.logger.logError("ItemLabelPrintWzrdViewModel complete printOperation confirmation: " + JSON.stringify(reason));
                                    _this.state.isProcessing = false;
                                });
                            })
                                .catch(function (reason) {
                                if (_commerce_2.ApplicationSession.instance.posConfiguration) {
                                    _commerce_2.ApplicationSession.instance.posConfiguration._connectionTimeout = oldTimeOut_2;
                                }
                                _this.state.isProcessing = false;
                                _this.enablePrintCancel(true);
                                _this._context.logger.logError("Print label execute error: " + JSON.stringify(reason));
                                ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                            });
                        }
                    }).then(function () {
                        _this.state.isProcessing = false;
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this.enablePrintCancel(true);
                        _this._context.logger.logError("Print label execute error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.calculateStatistics = function () {
                    var _this = this;
                    var itemStats = [];
                    var request = new DataServiceRequests_g_1.Labels.GetCalcStatRequest(this.labelType());
                    this.state.isProcessing = true;
                    var allowSelect = false;
                    var canCalculateAndPrint = this.selectedLabelItems().length > 1;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            var stats = result.data.result;
                            for (var i = 0; i < stats.length; i++) {
                                allowSelect = TypeExtensions_1.StringExtensions.isNullOrWhitespace(stats[i].ErrorText);
                                itemStats.push({ statistic: stats[i], IsSelect: knockout_1.default.observable(allowSelect), IsEnable: knockout_1.default.observable(allowSelect) });
                            }
                            _this.labelItemStatistics(itemStats);
                            if (!canCalculateAndPrint) {
                                _this.printStatDialog(true);
                                _this.enablePrintCancel(true);
                            }
                        }
                    })
                        .then(function () {
                        if (canCalculateAndPrint)
                            _this.printSelectedLabelLayout();
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Print label calculate Statistics error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.clear = function () {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.Labels.GetClearRequest(this.labelType());
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.updateLabelList();
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError(" Clear execute error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.calculateItemsOnWizard = function () {
                    var itemCalculateCriteria = new DataServiceEntities_g_1.Entities.LabelItemCalculateCriteria();
                    itemCalculateCriteria.SearchOption = this.selectedOptionValue();
                    itemCalculateCriteria.Quantity = this.itemQuantity();
                    itemCalculateCriteria.CategoryId = isNaN(this.categoryId()) ? 0 : this.categoryId();
                    itemCalculateCriteria.HierarchyId = isNaN(this.hierarchyId()) ? 0 : this.hierarchyId();
                    itemCalculateCriteria.SectionId = TypeExtensions_1.StringExtensions.isNullOrWhitespace(this.sectionId()) ? "" : this.sectionId();
                    itemCalculateCriteria.ShelfId = TypeExtensions_1.StringExtensions.isNullOrWhitespace(this.shelfId()) ? "" : this.shelfId();
                    itemCalculateCriteria.ItemFilter = this.itemFilterText();
                    itemCalculateCriteria.QtySource = this.selectedQtySource();
                    itemCalculateCriteria.ChangeTracking = this.changeTracking();
                    itemCalculateCriteria.FromDate = null;
                    itemCalculateCriteria.ToDate = null;
                    if (this.selectedQtySource() == "OrderReceived") {
                        itemCalculateCriteria.FromDate = this.fromDate() != null ? this.fromDate() : new Date();
                        itemCalculateCriteria.ToDate = this.toDate() != null ? this.toDate() : new Date();
                    }
                    if (TypeExtensions_1.ObjectExtensions.isNullOrUndefined(this.selectedLC())) {
                        this.selectedLC = knockout_1.default.observable(new DataServiceEntities_g_1.Entities.LabelCode());
                    }
                    this.labelCalcParam.CodeRecId = isNaN(this.selectedLC().Id) ? 0 : this.selectedLC().Id;
                    this.labelCalcParam.PriceDate = this.DateWithTime(this.priceDate());
                    this.wizardItemCalculate(itemCalculateCriteria, 0);
                };
                ItemLabelPrintWzrdViewModel.prototype.wizardItemCalculate = function (itemCalculateCriteria, pageNumber) {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.Labels.CalculateLabelItemRequest(this.labelType(), this.labelCalcParam, null, itemCalculateCriteria, pageNumber);
                    this.state.isProcessing = true;
                    var _commerce = Commerce;
                    var requestDelay = pageNumber == 0 ? 10 : 500;
                    var oldTimeOut;
                    if (_commerce.ApplicationSession.instance.posConfiguration) {
                        oldTimeOut = _commerce.ApplicationSession.instance.posConfiguration.connectionTimeout;
                        _commerce.ApplicationSession.instance.posConfiguration._connectionTimeout = 900;
                    }
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (_commerce.ApplicationSession.instance.posConfiguration) {
                            _commerce.ApplicationSession.instance.posConfiguration._connectionTimeout = oldTimeOut;
                        }
                        setTimeout(function () {
                            _this.state.isProcessing = false;
                            if (!result.canceled) {
                                if (result.data.result >= 0) {
                                    _this.updateLabelList();
                                }
                                else {
                                    ++pageNumber;
                                    _this.wizardItemCalculate(itemCalculateCriteria, pageNumber);
                                }
                            }
                        }, requestDelay);
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Calculate item on wizard error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.noOfLabelEditor = function (item) {
                    this.labelItem(item);
                    this.updateLabelQuantity();
                };
                ItemLabelPrintWzrdViewModel.prototype.getLabelCodes = function () {
                    var _this = this;
                    if (this.labelCodes().length > 0)
                        return;
                    var request = new DataServiceRequests_g_1.Labels.GetLabelCodeRequest();
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.labelCodes(result.data.result);
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Getting store section's error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.getStoreSections = function () {
                    var _this = this;
                    if (this.storeSections().length > 0)
                        return;
                    var request = new DataServiceRequests_g_1.Labels.GetStoreSectionsRequest();
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.storeSections(result.data.result);
                            _this.arrangeLocation(null);
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Getting store section's error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.getStoreShelves = function (sectionId) {
                    var _this = this;
                    if (sectionId === void 0) { sectionId = ''; }
                    if (this.storeShelves().length > 0)
                        return;
                    var request = new DataServiceRequests_g_1.Labels.GetStoreShelvesRequest(sectionId);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.storeShelves(result.data.result);
                            _this.arrangeLocation(result.data.result);
                        }
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Geting section's shalve error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.updatelabelitem = function (quantity) {
                    var _this = this;
                    var item = this.selectedLabelItems()[0];
                    item.NoOfLabels = quantity;
                    this.state.isProcessing = true;
                    var upRequest = new DataServiceRequests_g_1.Labels.LabelItemUpdateRequest(item);
                    this._context.runtime.executeAsync(upRequest)
                        .then(function () {
                        _this.state.isProcessing = false;
                        _this.updateLabelList();
                        _this.selectedLabelItems([]);
                    })
                        .catch(function () {
                        _this.state.isProcessing = false;
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.labelQuantityCancelHandler = function () {
                    this.labelItem({});
                };
                ItemLabelPrintWzrdViewModel.prototype.calculateImportBarcodes = function (labelType, barCodes, labelCalcParam) {
                    var _this = this;
                    var calculateItem;
                    var items = [];
                    for (var i = 0; i < barCodes.length; i++) {
                        if (barCodes[i] != '') {
                            calculateItem = new DataServiceEntities_g_1.Entities.LabelItemCalculateItem();
                            calculateItem.ProductId = 0;
                            calculateItem.BarCode = barCodes[i];
                            calculateItem.Quantity = 1;
                            items.push(calculateItem);
                        }
                    }
                    var request = new DataServiceRequests_g_1.Labels.CalculateLabelItemRequest(labelType, labelCalcParam, items, null, 0);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        _this.updateLabelList();
                        _this.selectedLabelItems([]);
                    })
                        .catch(function (reason) {
                        _this._context.logger.logError("Calculate label item error: " + JSON.stringify(reason));
                        _this.state.isProcessing = false;
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.calculateItemBarcode = function () {
                    var _this = this;
                    this.barCodeNotFoundMsg('');
                    var codeRecId = 0;
                    if (this.selectedLC() == undefined)
                        codeRecId = 0;
                    else
                        codeRecId = this.selectedLC().Id;
                    if (TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(this.itemBarCode())) {
                        this.barCodeNotFoundMsg(this._context.resources.getString("ENTER_BARCODE_ALERT"));
                        return;
                    }
                    if (TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(this.barCodeLabelQuantity())) {
                        this.barCodeNotFoundMsg(this._context.resources.getString("ENTER_LABEL_QUANTIRY_ALERT"));
                        return;
                    }
                    if (Commerce.NumberExtensions.isNullOrNaN(parseInt(this.barCodeLabelQuantity()))) {
                        this.barCodeNotFoundMsg(this._context.resources.getString("ENTER_LABEL_QUANTIRY_ALERT"));
                        return;
                    }
                    if (codeRecId == 0) {
                        this.barCodeNotFoundMsg(this._context.resources.getString("SELECT_LABEL_CODE_ALERT"));
                        return;
                    }
                    var calculateItem = new DataServiceEntities_g_1.Entities.LabelItemCalculateItem();
                    calculateItem.ProductId = 0;
                    calculateItem.BarCode = this.itemBarCode();
                    calculateItem.Quantity = parseInt(this.barCodeLabelQuantity());
                    this.labelCalcParam.CodeRecId = codeRecId;
                    this.labelCalcParam.PriceDate = this.DateWithTime(this.priceDate());
                    var request = new DataServiceRequests_g_1.Labels.CalculateLabelItemRequest(this.labelType(), this.labelCalcParam, [calculateItem], null, 0);
                    this.state.isProcessing = true;
                    this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (!result.canceled) {
                            if (result.data.result == 0) {
                                _this.barCodeNotFoundMsg(TypeExtensions_1.StringExtensions.format(_this._context.resources.getString("BARCODE_NOT_FOUND"), _this.itemBarCode()));
                                _this.state.isProcessing = false;
                            }
                            else {
                                _this.updateLabelList();
                                _this.selectedLabelItems([]);
                                _this.itemBarCode('');
                                _this.barCodeLabelQuantity('');
                            }
                        }
                    })
                        .catch(function (reason) {
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        _this.state.isProcessing = false;
                    });
                };
                ItemLabelPrintWzrdViewModel.prototype.setSelectedItems = function (items) {
                    this.selectedLabelItems(items);
                };
                ItemLabelPrintWzrdViewModel.prototype.arrangeCategories = function (arry) {
                    var roots = [], children = {};
                    for (var i = 0, len = arry.length; i < len; ++i) {
                        var item = arry[i];
                        var p = item.ParentCategory;
                        var target = !p ? roots : (children[p] || (children[p] = []));
                        target.push({ value: item });
                    }
                    var findChildren = function (parentCategory) {
                        if (children[parentCategory.value.RecordId]) {
                            parentCategory.children = children[parentCategory.value.RecordId];
                            for (var i = 0, len = parentCategory.children.length; i < len; ++i) {
                                findChildren(parentCategory.children[i]);
                            }
                        }
                        else {
                            parentCategory.children = [];
                        }
                    };
                    for (var i = 0, ltd = roots.length; i < ltd; ++i) {
                        findChildren(roots[i]);
                    }
                    this.categoryTree(roots);
                };
                ItemLabelPrintWzrdViewModel.prototype.arrangeLocation = function (arry) {
                    var sections = this.storeSections(), shelves = this.storeShelves(), roots = [], parents = [];
                    if (this.storeSections().length == 0 || this.storeShelves().length == 0) {
                        return;
                    }
                    for (var i = 0; i < sections.length; ++i) {
                        var section = sections[i];
                        parents.push({
                            SectionId: section.SectionId,
                            SectionName: section.SectionName,
                            shelves: []
                        });
                        for (var j = 0; j < shelves.length; ++j) {
                            var shelve = shelves[j];
                            if (section.SectionId == shelve.SectionId) {
                                parents[i].shelves.push(shelve);
                            }
                        }
                    }
                    roots.push({ Id: 0, Name: this._context.resources.getString("ALL"), sections: parents });
                    this.locationTree(roots);
                };
                ItemLabelPrintWzrdViewModel.prototype.DateWithTime = function (date) {
                    var tmpDate = new Date(Date.now());
                    var hrs = tmpDate.getHours();
                    var mins = tmpDate.getMinutes();
                    var secs = tmpDate.getSeconds();
                    var newDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), hrs, mins, secs, 0);
                    return newDate;
                };
                return ItemLabelPrintWzrdViewModel;
            }());
            exports_1("default", ItemLabelPrintWzrdViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/Views/ItemLabelPrintWzrdViewModel.js.map