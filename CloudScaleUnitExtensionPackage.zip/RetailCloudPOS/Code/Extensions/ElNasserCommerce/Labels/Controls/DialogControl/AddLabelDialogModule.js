System.register(["PosApi/Create/Dialogs", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, TypeExtensions_1, knockout_1, AddLabelDialogModule;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            AddLabelDialogModule = (function (_super) {
                __extends(AddLabelDialogModule, _super);
                function AddLabelDialogModule(labelType, showLabelType, codeId, isVariantSelected, showQuantity) {
                    if (codeId === void 0) { codeId = 0; }
                    if (isVariantSelected === void 0) { isVariantSelected = true; }
                    if (showQuantity === void 0) { showQuantity = true; }
                    var _this = _super.call(this) || this;
                    _this.userEnteredValue = knockout_1.default.observable("");
                    _this.selectedLabelType = knockout_1.default.observable(labelType.toString());
                    _this.showLabelType = showLabelType || false;
                    _this.isVariantSelected = isVariantSelected;
                    _this.showQuantity = showQuantity;
                    _this.labelCodes = knockout_1.default.observableArray([]);
                    _this.selectedCode = knockout_1.default.observable(null);
                    _this.selectedCode({ Id: codeId });
                    _this.priceDate = knockout_1.default.observable(null);
                    var date = new Date();
                    var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                    _this.priceDate(today);
                    var self = _this;
                    _this.userEnteredValue.subscribe(function () {
                        self.enableOk();
                    });
                    return _this;
                }
                AddLabelDialogModule.prototype.onReady = function (el) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, el);
                    var datePickerOptios = { date: new Date(), enabled: true };
                    var divPriceDate = el.querySelector("#divPriceDate");
                    this.priceDatePicker = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "DatePicker", datePickerOptios, divPriceDate);
                    this.priceDatePicker.addEventListener("DateChanged", function (eventData) {
                        _this.priceDate(eventData.date);
                    });
                };
                AddLabelDialogModule.prototype.open = function (title, subTitle, quantity, labelCodes) {
                    var _this = this;
                    this.userEnteredValue(quantity);
                    this.labelCodes(labelCodes);
                    if (this.showLabelType && this.selectedCode().Id > 0) {
                        this.selectedCode(labelCodes.filter(function (lbl) { return lbl.Id == _this.selectedCode().Id; })[0]);
                    }
                    var promise = new Promise(function (resolve, reject) {
                        _this.resolve = resolve;
                        var option = {
                            title: _this.context.resources.getString('PRINT_LABEL_QTY'),
                            subTitle: subTitle,
                            onCloseX: _this.onCloseX.bind(_this),
                            button1: {
                                id: "Button1",
                                label: _this.context.resources.getString('OK_BUTTON_TEXT'),
                                isPrimary: true,
                                onClick: _this.button1ClickHandler.bind(_this)
                            },
                            button2: {
                                id: "Button2",
                                label: _this.context.resources.getString('CANCEL_BUTTON_TEXT'),
                                onClick: _this.button2ClickHandler.bind(_this)
                            }
                        };
                        _this.openDialog(option);
                    });
                    if (this.showQuantity)
                        this.setButtonDisabledState("Button1", true);
                    else
                        this.setButtonDisabledState("Button1", false);
                    return promise;
                };
                AddLabelDialogModule.prototype.closeDialogClicked = function () {
                    this.closeDialog();
                    this.resolvePromise("Closed");
                };
                AddLabelDialogModule.prototype.enableOkClicked = function () {
                    this.setButtonDisabledState("Button1", false);
                    this.resolvePromise("Closed");
                };
                AddLabelDialogModule.prototype.enableOk = function () {
                    var quantity = parseInt(this.userEnteredValue());
                    var isQuantity = (this.userEnteredValue() != quantity.toString()) || isNaN(quantity) || quantity <= 0;
                    var isLabelType = this.selectedLabelType() == '0';
                    if (isLabelType || isQuantity || !this.isVariantSelected) {
                        this.setButtonDisabledState("Button1", true);
                    }
                    else {
                        this.setButtonDisabledState("Button1", false);
                    }
                    return true;
                };
                AddLabelDialogModule.prototype.onCloseX = function () {
                    this.resolvePromise("Closed");
                    return true;
                };
                AddLabelDialogModule.prototype.button1ClickHandler = function () {
                    this.resolvePromise(this.userEnteredValue());
                    return true;
                };
                AddLabelDialogModule.prototype.button2ClickHandler = function () {
                    this.resolvePromise("Closed");
                    this.closeDialog();
                    return false;
                };
                AddLabelDialogModule.prototype.resolvePromise = function (result) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this.resolve)) {
                        this.resolve({
                            selectedValue: result,
                            itemLabelType: this.selectedLabelType(),
                            labelCode: this.selectedCode(),
                            priceDate: this.priceDate()
                        });
                        this.resolve = null;
                    }
                };
                return AddLabelDialogModule;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", AddLabelDialogModule);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/Controls/DialogControl/AddLabelDialogModule.js.map