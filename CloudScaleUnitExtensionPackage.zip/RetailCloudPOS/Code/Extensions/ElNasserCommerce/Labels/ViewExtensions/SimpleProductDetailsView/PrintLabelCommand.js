System.register(["PosApi/Entities", "../../DataService2/DataServiceEntities.g", "../../DataService2/DataServiceRequests.g", "PosApi/Extend/Views/SimpleProductDetailsView", "../../Controls/DialogControl/AddLabelDialogModule", "../../Controls/DialogControl/MessageDialog", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, DataServiceEntities_g_1, DataServiceRequests_g_1, SimpleProductDetailsView, AddLabelDialogModule_1, MessageDialog_1, TypeExtensions_1, knockout_1, PrintProductLabelCommand;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (SimpleProductDetailsView_1) {
                SimpleProductDetailsView = SimpleProductDetailsView_1;
            },
            function (AddLabelDialogModule_1_1) {
                AddLabelDialogModule_1 = AddLabelDialogModule_1_1;
            },
            function (MessageDialog_1_1) {
                MessageDialog_1 = MessageDialog_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            PrintProductLabelCommand = (function (_super) {
                __extends(PrintProductLabelCommand, _super);
                function PrintProductLabelCommand(context) {
                    var _this = _super.call(this, context) || this;
                    _this.id = "printLabelCommand";
                    _this.label = _this.context.resources.getString("PRINT_LABEL_CMD_TEXT");
                    _this.extraClass = "iconGo";
                    _this._labelCodes = knockout_1.default.observableArray([]);
                    _this.productChangedHandler = function (data) {
                        _this._productChanged(data.product);
                    };
                    _this.canExecute = true;
                    _this.isVisible = true;
                    return _this;
                }
                PrintProductLabelCommand.prototype.init = function (state) {
                    this._productChanged(state.product);
                    this.GetLabelCodes();
                };
                PrintProductLabelCommand.prototype.execute = function () {
                    var _this = this;
                    var selectedLabelType = TypeExtensions_1.ObjectExtensions.isNullOrUndefined(sessionStorage.getItem("LabelType")) ? 0 : parseInt(sessionStorage.getItem("LabelType"));
                    var codeRecId = TypeExtensions_1.ObjectExtensions.isNullOrUndefined(sessionStorage.getItem("CodeRecId")) ? 0 : parseInt(sessionStorage.getItem("CodeRecId"));
                    var isVatiantSel = !(this._product.ProductTypeValue === Entities_1.ProxyEntities.ProductType.Master);
                    var dialog = new AddLabelDialogModule_1.default(selectedLabelType, true, codeRecId, isVatiantSel);
                    dialog.open(this.context.resources.getString('PRINT_LABEL_QTY'), this._product.Description, "", this._labelCodes())
                        .then(function (result) {
                        _this.context.logger.logInformational("Dialog result: " + result.selectedValue);
                        if (result.selectedValue == 'Closed') {
                            return;
                        }
                        var quantity = parseInt(result.selectedValue);
                        var labelType = parseInt(result.itemLabelType);
                        if (isNaN(quantity)) {
                            _this.context.logger.logError("Please enter numbers only!");
                            return;
                        }
                        if (quantity <= 0) {
                            _this.context.logger.logError("The label printing quantity cannot be zero or negative");
                            return;
                        }
                        if (isNaN(labelType)) {
                            _this.context.logger.logError("Please enter numbers only!");
                            return;
                        }
                        _this.isProcessing = true;
                        var calculateItem = new DataServiceEntities_g_1.Entities.LabelItemCalculateItem();
                        var labelCalcParam;
                        var labelCode = result.labelCode;
                        calculateItem.ItemId = _this._product.ItemId;
                        calculateItem.UnitOfMeasure = _this._product.DefaultUnitOfMeasure;
                        calculateItem.Quantity = quantity;
                        if (TypeExtensions_1.ObjectExtensions.isNullOrUndefined(labelCode)) {
                            labelCode = new DataServiceEntities_g_1.Entities.LabelCode();
                        }
                        labelCalcParam = new DataServiceEntities_g_1.Entities.LabelItemCalculateParams();
                        labelCalcParam.CodeRecId = isNaN(labelCode.Id) ? 0 : labelCode.Id;
                        labelCalcParam.PriceDate = result.priceDate;
                        if (_this._product.ProductTypeValue === Entities_1.ProxyEntities.ProductType.Variant && labelType == 1) {
                            calculateItem.ProductId = _this._product.RecordId;
                        }
                        sessionStorage.setItem("CodeRecId", labelCalcParam.CodeRecId.toString());
                        sessionStorage.setItem("LabelType", labelType.toString());
                        var request = new DataServiceRequests_g_1.Labels.CalculateLabelItemRequest(labelType, labelCalcParam, [calculateItem], null, 0);
                        _this.context.runtime.executeAsync(request)
                            .then(function (result) {
                            _this.isProcessing = false;
                            if (!result.canceled) {
                                if (result.data.result > 0) {
                                    _this.displayClientMessage(TypeExtensions_1.StringExtensions.format(_this.context.resources.getString("CALCUALTE_ITEM_RESULT_PASS"), _this._product.Name), "Information");
                                }
                                else {
                                    _this.displayClientMessage(TypeExtensions_1.StringExtensions.format(_this.context.resources.getString("CALCUALTE_ITEM_RESULT_FAIL"), _this._product.Name), "Information");
                                }
                            }
                        })
                            .catch(function (reason) {
                            _this.isProcessing = false;
                            _this.context.logger.logError("Calculate label item error: " + JSON.stringify(reason));
                            _this.handleError(reason);
                        });
                    }).catch(function (reason) {
                        _this.context.logger.logError("Dialog error: " + JSON.stringify(reason));
                        _this.handleError(reason);
                    });
                };
                PrintProductLabelCommand.prototype.GetLabelCodes = function () {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.Labels.GetLabelCodeRequest();
                    this.isProcessing = true;
                    this.context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.isProcessing = false;
                        if (!result.canceled) {
                            _this._labelCodes(result.data.result);
                        }
                    })
                        .catch(function (reason) {
                        _this.isProcessing = false;
                        _this.context.logger.logError("Label code get error: " + JSON.stringify(reason));
                        _this.handleError(reason);
                    });
                };
                PrintProductLabelCommand.prototype.handleError = function (error) {
                    var rsError = error || {};
                    if (error.length) {
                        rsError = error[0] || {};
                    }
                    var dlgTitle = rsError.name;
                    var errorMsg = rsError._externalLocalizedErrorMessage;
                    if (TypeExtensions_1.StringExtensions.isNullOrWhitespace(dlgTitle) || TypeExtensions_1.StringExtensions.isEmpty(dlgTitle)) {
                        dlgTitle = this.context.resources.getString("ERROR_TITLE");
                    }
                    if (TypeExtensions_1.StringExtensions.isNullOrWhitespace(errorMsg) || TypeExtensions_1.StringExtensions.isEmpty(errorMsg)) {
                        errorMsg = JSON.stringify(rsError);
                    }
                    this.displayClientMessage(errorMsg, dlgTitle);
                };
                PrintProductLabelCommand.prototype.displayClientMessage = function (msg, dlgTitle) {
                    MessageDialog_1.default.show(this.context, msg, dlgTitle);
                };
                PrintProductLabelCommand.prototype._productChanged = function (product) {
                    this._product = product;
                };
                return PrintProductLabelCommand;
            }(SimpleProductDetailsView.SimpleProductDetailsExtensionCommandBase));
            exports_1("default", PrintProductLabelCommand);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/ViewExtensions/SimpleProductDetailsView/PrintLabelCommand.js.map