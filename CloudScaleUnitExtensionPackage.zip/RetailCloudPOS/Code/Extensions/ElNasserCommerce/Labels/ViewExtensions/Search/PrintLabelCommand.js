System.register(["PosApi/Extend/Views/SearchView"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var SearchView, PrintLabelCommand;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (SearchView_1) {
                SearchView = SearchView_1;
            }
        ],
        execute: function () {
            PrintLabelCommand = (function (_super) {
                __extends(PrintLabelCommand, _super);
                function PrintLabelCommand(context) {
                    var _this = _super.call(this, context) || this;
                    _this.id = "navigateToSimpleExtensionViewCommand";
                    _this.label = "RR Labels View";
                    _this.extraClass = "iconGo";
                    return _this;
                }
                PrintLabelCommand.prototype.init = function (state) {
                    this.canExecute = true;
                    this.isVisible = true;
                };
                PrintLabelCommand.prototype.execute = function () {
                };
                return PrintLabelCommand;
            }(SearchView.ProductSearchExtensionCommandBase));
            exports_1("default", PrintLabelCommand);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/Labels/ViewExtensions/Search/PrintLabelCommand.js.map