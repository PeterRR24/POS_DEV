System.register(["PosApi/Extend/Triggers/ProductTriggers", "PosApi/TypeExtensions", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, TypeExtensions_1, ErrorHelper_1, PreVoidProductsTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            PreVoidProductsTrigger = (function (_super) {
                __extends(PreVoidProductsTrigger, _super);
                function PreVoidProductsTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PreVoidProductsTrigger.prototype.execute = function (options) {
                    this.context.logger.logVerbose("Executing PreVoidProductsTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    if (options.cart.CartTypeValue == 3 && options.cart.CustomerOrderModeValue != 3) {
                        return Promise.resolve({ canceled: false });
                    }
                    var cartLines = options.cartLines;
                    var lessQtyVoiedLineIds = JSON.parse(sessionStorage.getItem("RR_LessQtyVoiedItem")) || [];
                    var products = '';
                    for (var i = 0; i < cartLines.length; i++) {
                        if (lessQtyVoiedLineIds.indexOf(cartLines[i].LineId) != -1) {
                            var item = cartLines[i].ItemId + '::' + cartLines[i].Description;
                            if (products.indexOf(item) == -1) {
                                products += item + '\r\n';
                            }
                            ErrorHelper_1.ErrorHelper.displayMessageAsync(this.context, TypeExtensions_1.StringExtensions.format(this.context.resources.getString('PRODUCT_QUANTITY_ZERO_ALERT'), products));
                            return Promise.resolve({ canceled: true });
                        }
                    }
                    return Promise.resolve({ canceled: false });
                };
                return PreVoidProductsTrigger;
            }(Triggers.PreVoidProductsTrigger));
            exports_1("default", PreVoidProductsTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/TriggerHandlers/PreVoidProductsTrigger.js.map