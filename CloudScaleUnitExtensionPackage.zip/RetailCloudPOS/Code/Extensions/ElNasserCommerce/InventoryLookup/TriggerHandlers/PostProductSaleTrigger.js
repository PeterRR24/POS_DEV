System.register(["PosApi/Extend/Triggers/ProductTriggers", "PosApi/TypeExtensions", "../DataService/DataServiceRequests.g", "../../ErrorHelper", "PosApi/Consume/Cart"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, TypeExtensions_1, DataServiceRequests_g_1, ErrorHelper_1, Cart_1, PostProductSaleTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            },
            function (Cart_1_1) {
                Cart_1 = Cart_1_1;
            }
        ],
        execute: function () {
            PostProductSaleTrigger = (function (_super) {
                __extends(PostProductSaleTrigger, _super);
                function PostProductSaleTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PostProductSaleTrigger.prototype.execute = function (options) {
                    var _this = this;
                    this.context.logger.logVerbose("Executing PostProductSaleTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    this.getConfiguration();
                    if (options.cart.CartLines[options.cart.CartLines.length - 1].Description.charAt(0) === "%") {
                        var Desc = options.cart.CartLines[options.cart.CartLines.length - 1].Description.split('%');
                        var UpatedPrice = (options.cart.CartLines[options.cart.CartLines.length - 1].Price * parseFloat(Desc[1])) / 100;
                        this.context.runtime.executeAsync(new Cart_1.PriceOverrideOperationRequest(options.cart.CartLines[options.cart.CartLines.length - 1].LineId, UpatedPrice, ""))
                            .then(function () {
                            correlationId = _this.context.logger.getNewCorrelationId();
                            _this.context.runtime.executeAsync(new Commerce.RefreshCartClientRequest(correlationId))
                                .then(function (resp) {
                                console.log(resp);
                            });
                        }).catch(function (err) {
                            console.log(err);
                        });
                    }
                    if (!this.isBlockSale || (options.cart.CartTypeValue == 3 && options.cart.CustomerOrderModeValue != 3))
                        return Promise.resolve();
                    if (options.cart.TransactionTypeValue == 19)
                        return Promise.resolve();
                    var RequestPSDs = options.productSaleDetails;
                    var PSDs = [];
                    for (var i = 0; i < RequestPSDs.length; i++) {
                        if (RequestPSDs[i].product.ItemTypeValue !== 2) {
                            PSDs.push(RequestPSDs[i]);
                        }
                    }
                    if (PSDs.length == 0)
                        return Promise.resolve();
                    var correlationId = '';
                    var voidCartLines = [];
                    var updateCartLine = [];
                    var cart = options.cart;
                    var tempCartLine = cart.CartLines;
                    var products = '';
                    var strQuantity = '';
                    var rrCommerce = Commerce;
                    var deviceConfig = new Commerce.Proxy.Entities.DeviceConfigurationClass(JSON.parse(rrCommerce.ApplicationStorage.getItem(rrCommerce.ApplicationStorageIDs.DEVICE_CONFIGURATION_KEY)));
                    var aggregateItem = deviceConfig.AllowItemsAggregation;
                    this.GetProductsQuantity(PSDs).then(function (results) {
                        var _loop_1 = function (idx) {
                            var availableQuantity = results[idx].AvailableQuantity;
                            if (!(availableQuantity > 0)) {
                                for (var cl = 0; cl < cart.CartLines.length; cl++) {
                                    if (!cart.CartLines[cl].IsVoided && cart.CartLines[cl].ProductId == results[idx].product.RecordId) {
                                        voidCartLines.push(cart.CartLines[cl]);
                                        var item = cart.CartLines[cl].ItemId + '::' + cart.CartLines[cl].Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                        }
                                    }
                                }
                            }
                            else if (!aggregateItem) {
                                var lines = tempCartLine;
                                var mapLines_1 = lines.reduce(function (prev, next) {
                                    if (next.ProductId in prev) {
                                        if (!next.IsVoided) {
                                            prev[next.ProductId].Quantity += next.Quantity;
                                            prev[next.ProductId].LineId = next.LineId;
                                        }
                                    }
                                    else {
                                        prev[next.ProductId] = next;
                                    }
                                    return prev;
                                }, {});
                                var aggregateCartLine = Object.keys(mapLines_1).map(function (id) { return mapLines_1[id]; });
                                var cartLine = null;
                                for (var cl = 0; cl < aggregateCartLine.length; cl++) {
                                    cartLine = aggregateCartLine[cl];
                                    if (cartLine.ProductId == results[idx].product.RecordId && cartLine.Quantity > availableQuantity) {
                                        var item = cartLine.ItemId + '::' + cartLine.Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                            strQuantity += availableQuantity + ', ';
                                        }
                                        cartLine.Quantity = results[idx].quantity;
                                        voidCartLines.push(cartLine);
                                    }
                                }
                            }
                            else {
                                var cartLine = null;
                                for (var cl = 0; cl < cart.CartLines.length; cl++) {
                                    cartLine = cart.CartLines[cl];
                                    if (!cartLine.IsVoided && cartLine.ProductId == results[idx].product.RecordId && cartLine.Quantity > availableQuantity) {
                                        var item = cartLine.ItemId + '::' + cartLine.Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                            strQuantity += availableQuantity + ', ';
                                        }
                                        cartLine.Quantity = availableQuantity;
                                        updateCartLine.push(cartLine);
                                    }
                                }
                            }
                        };
                        for (var idx = 0; idx < results.length; idx++) {
                            _loop_1(idx);
                        }
                        if (voidCartLines.length !== 0) {
                            var lineId = [];
                            for (var vcl = 0; vcl < voidCartLines.length; vcl++) {
                                lineId.push(voidCartLines[vcl].LineId);
                            }
                            var tempLineId = JSON.parse(sessionStorage.getItem("RR_LessQtyVoiedItem")) || [];
                            lineId = lineId.concat(tempLineId);
                            sessionStorage.setItem("RR_LessQtyVoiedItem", JSON.stringify(lineId));
                            _this.context.runtime.executeAsync(new DataServiceRequests_g_1.Products.VoidCartLinesRequest(cart.Id, voidCartLines))
                                .then(function () {
                                correlationId = _this.context.logger.getNewCorrelationId();
                                _this.context.runtime.executeAsync(new Commerce.RefreshCartClientRequest(correlationId))
                                    .then(function (resp) {
                                    console.log(resp);
                                    ErrorHelper_1.ErrorHelper.displayMessageAsync(_this.context, TypeExtensions_1.StringExtensions.format(_this.context.resources.getString('PRODUCT_QUANTITY_ZERO_ALERT'), products));
                                });
                            });
                        }
                        if (updateCartLine.length !== 0) {
                            strQuantity = strQuantity.substring(0, strQuantity.length - 2);
                            _this.context.runtime.executeAsync(new DataServiceRequests_g_1.Products.UpdateCartLinesRequest(cart.Id, updateCartLine))
                                .then(function () {
                                correlationId = _this.context.logger.getNewCorrelationId();
                                _this.context.runtime.executeAsync(new Commerce.RefreshCartClientRequest(correlationId))
                                    .then(function (resp) {
                                    console.log(resp);
                                    ErrorHelper_1.ErrorHelper.displayMessageAsync(_this.context, TypeExtensions_1.StringExtensions.format(_this.context.resources.getString('PRODUCT_QUANTITY_LESS_ALERT'), products, strQuantity));
                                });
                            });
                        }
                    }).catch(function (err) {
                        console.log(err);
                    });
                    return Promise.resolve();
                };
                PostProductSaleTrigger.prototype.GetProductsQuantity = function (PSDs) {
                    var promises = [];
                    var itemQtyRequest = null;
                    var _loop_2 = function (i) {
                        if (PSDs[i].product.ProductTypeValue == 4 || PSDs[i].product.ProductTypeValue == 5) {
                            itemQtyRequest = new DataServiceRequests_g_1.Products.GetProductAvailableQuantityRequest(PSDs[i].product.RecordId, PSDs[i].product.ItemId, '');
                            promises.push(this_1.context.runtime.executeAsync(itemQtyRequest)
                                .then(function (resp) {
                                if (!resp.canceled) {
                                    PSDs[i].AvailableQuantity = resp.data.result;
                                    return PSDs[i];
                                }
                            }));
                        }
                    };
                    var this_1 = this;
                    for (var i = 0; i < PSDs.length; i++) {
                        _loop_2(i);
                    }
                    return Promise.all(promises);
                };
                PostProductSaleTrigger.prototype.getConfiguration = function () {
                    var str_configuration = sessionStorage.getItem("RR_UtilitiesConfiguration");
                    var configuration = JSON.parse(str_configuration);
                    this.isBlockSale = false;
                    if (!Commerce.ObjectExtensions.isNullOrUndefined(configuration))
                        this.isBlockSale = configuration.BlockSales == 1;
                };
                return PostProductSaleTrigger;
            }(Triggers.PostProductSaleTrigger));
            exports_1("default", PostProductSaleTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/TriggerHandlers/PostProductSaleTrigger.js.map