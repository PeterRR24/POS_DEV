System.register(["PosApi/Extend/Triggers/PaymentTriggers"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, PostPaymentTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            }
        ],
        execute: function () {
            PostPaymentTrigger = (function (_super) {
                __extends(PostPaymentTrigger, _super);
                function PostPaymentTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PostPaymentTrigger.prototype.execute = function (options) {
                    this.context.logger.logVerbose("Executing PostPaymentTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    sessionStorage.removeItem("RR_LessQtyVoiedItem");
                    sessionStorage.removeItem("RR_InitialTransQuantity");
                    sessionStorage.removeItem("RR_LessQtyRecallOrder");
                    return Promise.resolve();
                };
                return PostPaymentTrigger;
            }(Triggers.PostPaymentTrigger));
            exports_1("default", PostPaymentTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/TriggerHandlers/PostPaymentTrigger.js.map