System.register(["PosApi/Extend/Triggers/TransactionTriggers", "PosApi/TypeExtensions", "../DataService/DataServiceRequests.g", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, TypeExtensions_1, DataServiceRequests_g_1, ErrorHelper_1, PostRecallTransactionTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            PostRecallTransactionTrigger = (function (_super) {
                __extends(PostRecallTransactionTrigger, _super);
                function PostRecallTransactionTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PostRecallTransactionTrigger.prototype.execute = function (options) {
                    this.context.logger.logVerbose("Executing PostRecallTransactionTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    var me = this;
                    this.getConfiguration();
                    if (!this.isBlockSale || (options.cart.CartTypeValue == 3 && options.cart.CustomerOrderModeValue != 3))
                        return Promise.resolve();
                    sessionStorage.setItem("RR_LessQtyRecallOrder", "0");
                    var cartLines = options.cart.CartLines;
                    var products = '';
                    var strQuantity = '';
                    var rrCommerce = Commerce;
                    var deviceConfig = new Commerce.Proxy.Entities.DeviceConfigurationClass(JSON.parse(rrCommerce.ApplicationStorage.getItem(rrCommerce.ApplicationStorageIDs.DEVICE_CONFIGURATION_KEY)));
                    var aggregateItem = deviceConfig.AllowItemsAggregation;
                    var prodIds = cartLines.filter(function (obj) { return !obj.IsVoided; }).map(function (cl) { return cl.ProductId; });
                    return me.context.runtime.executeAsync(new DataServiceRequests_g_1.Products.GetSimpleProductsRequest(deviceConfig.ChannelId, prodIds))
                        .then(function (resp) {
                        if (!resp.canceled) {
                            var RequestPSDs = [];
                            var PSDs = [];
                            for (var cnt = 0; cnt < resp.data.result.length; cnt++) {
                                var PSD = { quantity: 0, product: resp.data.result[cnt] };
                                RequestPSDs.push(PSD);
                            }
                            for (var i = 0; i < RequestPSDs.length; i++) {
                                if (RequestPSDs[i].product.ItemTypeValue !== 2) {
                                    PSDs.push(RequestPSDs[i]);
                                }
                            }
                            if (PSDs.length == 0)
                                return Promise.resolve({ canceled: false });
                            else
                                return PSDs;
                        }
                    }).then(function (PSDs) {
                        return me.GetProductsQuantity(PSDs);
                    }).then(function (results) {
                        var _loop_1 = function (j) {
                            var availableQuantity = results[j].AvailableQuantity;
                            if (!(availableQuantity > 0)) {
                                for (var cl = 0; cl < cartLines.length; cl++) {
                                    if (!cartLines[cl].IsVoided && cartLines[cl].ProductId == results[j].product.RecordId) {
                                        var item = cartLines[cl].ItemId + '::' + results[j].product.Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                            strQuantity += availableQuantity + ', ';
                                        }
                                    }
                                }
                            }
                            else if (!aggregateItem) {
                                var lines = cartLines;
                                var mapLines_1 = lines.reduce(function (prev, next) {
                                    if (next.ProductId in prev) {
                                        if (!next.IsVoided) {
                                            prev[next.ProductId].Quantity += next.Quantity;
                                            prev[next.ProductId].LineId = next.LineId;
                                        }
                                    }
                                    else {
                                        prev[next.ProductId] = next;
                                    }
                                    return prev;
                                }, {});
                                var aggregateCartLine = Object.keys(mapLines_1).map(function (id) { return mapLines_1[id]; });
                                var cartLine = null;
                                for (var acl = 0; acl < aggregateCartLine.length; acl++) {
                                    cartLine = aggregateCartLine[acl];
                                    if (cartLine.ProductId == results[j].product.RecordId && cartLine.Quantity > availableQuantity) {
                                        var item = cartLine.ItemId + '::' + results[j].product.Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                            strQuantity += availableQuantity + ', ';
                                        }
                                        cartLine.Quantity = results[j].quantity;
                                    }
                                }
                            }
                            else {
                                var cartLine = null;
                                for (var cl = 0; cl < cartLines.length; cl++) {
                                    cartLine = cartLines[cl];
                                    if (!cartLine.IsVoided && cartLine.ProductId == results[j].product.RecordId && cartLine.Quantity > availableQuantity) {
                                        var item = cartLine.ItemId + '::' + results[j].product.Description;
                                        if (products.indexOf(item) == -1) {
                                            products += item + '\r\n';
                                            strQuantity += availableQuantity + ', ';
                                        }
                                        cartLine.Quantity = availableQuantity;
                                    }
                                }
                            }
                        };
                        for (var j = 0; j < results.length; j++) {
                            _loop_1(j);
                        }
                    }).then(function () {
                        if (products.length > 0) {
                            sessionStorage.setItem("RR_LessQtyRecallOrder", "1");
                            return ErrorHelper_1.ErrorHelper.displayMessageAsync(me.context, TypeExtensions_1.StringExtensions.format(me.context.resources.getString('PRODUCT_QUANTITY_LESS_ALERT'), products, strQuantity));
                        }
                        else
                            return Promise.resolve();
                    }).catch(function (err) {
                        console.log(err);
                        return ErrorHelper_1.ErrorHelper.displayMessageAsync(me.context, JSON.stringify(err));
                    });
                };
                PostRecallTransactionTrigger.prototype.GetProductsQuantity = function (PSDs) {
                    var promises = [];
                    var itemQtyRequest = null;
                    var _loop_2 = function (i) {
                        if (PSDs[i].product.ProductTypeValue == 4 || PSDs[i].product.ProductTypeValue == 5) {
                            itemQtyRequest = new DataServiceRequests_g_1.Products.GetProductAvailableQuantityRequest(PSDs[i].product.RecordId, PSDs[i].product.ItemId, '');
                            promises.push(this_1.context.runtime.executeAsync(itemQtyRequest)
                                .then(function (resp) {
                                if (!resp.canceled) {
                                    PSDs[i].AvailableQuantity = resp.data.result;
                                    return PSDs[i];
                                }
                            }));
                        }
                    };
                    var this_1 = this;
                    for (var i = 0; i < PSDs.length; i++) {
                        _loop_2(i);
                    }
                    return Promise.all(promises);
                };
                PostRecallTransactionTrigger.prototype.getConfiguration = function () {
                    var str_configuration = sessionStorage.getItem("RR_UtilitiesConfiguration");
                    var configuration = JSON.parse(str_configuration);
                    this.isBlockSale = false;
                    if (!Commerce.ObjectExtensions.isNullOrUndefined(configuration))
                        this.isBlockSale = configuration.BlockSales == 1;
                };
                return PostRecallTransactionTrigger;
            }(Triggers.PostRecallTransactionTrigger));
            exports_1("default", PostRecallTransactionTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/TriggerHandlers/PostRecallTransactionTrigger.js.map