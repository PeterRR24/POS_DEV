System.register(["PosApi/Extend/Triggers/ProductTriggers", "PosApi/TypeExtensions", "../DataService/DataServiceRequests.g", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Triggers, TypeExtensions_1, DataServiceRequests_g_1, ErrorHelper_1, PostSetQuantityTrigger;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Triggers_1) {
                Triggers = Triggers_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            PostSetQuantityTrigger = (function (_super) {
                __extends(PostSetQuantityTrigger, _super);
                function PostSetQuantityTrigger() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PostSetQuantityTrigger.prototype.execute = function (options) {
                    var _this = this;
                    this.context.logger.logVerbose("Executing PostSetQuantityTrigger with options " + JSON.stringify(options) + " at " + new Date().getTime() + ".");
                    this.getConfiguration();
                    if (!this.isBlockSale || (options.cart.CartTypeValue == 3 && options.cart.CustomerOrderModeValue != 3))
                        return Promise.resolve();
                    var correlationId = '';
                    var cart = options.cart;
                    var updateCartLine = options.cartLines;
                    var tempCartLine = [];
                    var products = '';
                    var availableQuantity = 0;
                    var updateQty = 0;
                    var transactionQty = 0;
                    var rrCommerce = Commerce;
                    var deviceConfig = new Commerce.Proxy.Entities.DeviceConfigurationClass(JSON.parse(rrCommerce.ApplicationStorage.getItem(rrCommerce.ApplicationStorageIDs.DEVICE_CONFIGURATION_KEY)));
                    var aggregateItem = deviceConfig.AllowItemsAggregation;
                    var channelId = deviceConfig.ChannelId;
                    this.context.runtime.executeAsync(new DataServiceRequests_g_1.Products.GetSimpleProductRequest(channelId, updateCartLine[0].ProductId))
                        .then(function (resp) {
                        var SP = resp.data.result;
                        if (SP.ItemTypeValue !== 2) {
                            var itemQtyRequest = new DataServiceRequests_g_1.Products.GetProductAvailableQuantityRequest(updateCartLine[0].ProductId, updateCartLine[0].ItemId, '');
                            _this.context.runtime.executeAsync(itemQtyRequest)
                                .then(function (resp) {
                                if (!resp.canceled) {
                                    availableQuantity = resp.data.result;
                                    transactionQty = updateCartLine[0].Quantity;
                                    if (!aggregateItem) {
                                        tempCartLine = cart.CartLines;
                                        var mapLines_1 = tempCartLine.reduce(function (prev, next) {
                                            if (next.ProductId in prev) {
                                                if (!next.IsVoided) {
                                                    prev[next.ProductId].Quantity += next.Quantity;
                                                    prev[next.ProductId].LineId = next.LineId;
                                                }
                                            }
                                            else {
                                                prev[next.ProductId] = next;
                                            }
                                            return prev;
                                        }, {});
                                        var aggregateCartLine = Object.keys(mapLines_1).map(function (id) { return mapLines_1[id]; });
                                        var matchedLines = aggregateCartLine.filter(function (cl) { return cl.ProductId == updateCartLine[0].ProductId; });
                                        if (matchedLines.length)
                                            transactionQty = matchedLines[0].Quantity;
                                    }
                                    if (transactionQty > availableQuantity) {
                                        updateQty = parseInt(sessionStorage.getItem("RR_InitialTransQuantity"), 10);
                                        updateCartLine[0].Quantity = updateQty;
                                        products = updateCartLine[0].ItemId + '::' + updateCartLine[0].Description + '\r\n';
                                        _this.context.runtime.executeAsync(new DataServiceRequests_g_1.Products.UpdateCartLinesRequest(cart.Id, updateCartLine))
                                            .then(function () {
                                            correlationId = _this.context.logger.getNewCorrelationId();
                                            _this.context.runtime.executeAsync(new Commerce.RefreshCartClientRequest(correlationId))
                                                .then(function (resp) {
                                                console.log(resp);
                                                ErrorHelper_1.ErrorHelper.displayMessageAsync(_this.context, TypeExtensions_1.StringExtensions.format(_this.context.resources.getString('PRODUCT_QUANTITY_LESS_ALERT'), products, availableQuantity));
                                            });
                                        });
                                    }
                                }
                            });
                        }
                    });
                    return Promise.resolve();
                };
                PostSetQuantityTrigger.prototype.getConfiguration = function () {
                    var str_configuration = sessionStorage.getItem("RR_UtilitiesConfiguration");
                    var configuration = JSON.parse(str_configuration);
                    this.isBlockSale = false;
                    if (!Commerce.ObjectExtensions.isNullOrUndefined(configuration))
                        this.isBlockSale = configuration.BlockSales == 1;
                };
                return PostSetQuantityTrigger;
            }(Triggers.PostSetQuantityTrigger));
            exports_1("default", PostSetQuantityTrigger);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/TriggerHandlers/PostSetQuantityTrigger.js.map