System.register(["./ProdSrchOpRequest"], function (exports_1, context_1) {
    "use strict";
    var ProdSrchOpRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (ProdSrchOpRequest_1_1) {
                ProdSrchOpRequest_1 = ProdSrchOpRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var operationRequest = new ProdSrchOpRequest_1.default(correlationId);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/Operations/InventoryLookup/ProdSrchOpReqFactory.js.map