System.register(["PosApi/Create/Operations", "./ProdSrchOpRequest"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, ProdSrchOpRequest_1, ProdSrchOpReqHandler;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            },
            function (ProdSrchOpRequest_1_1) {
                ProdSrchOpRequest_1 = ProdSrchOpRequest_1_1;
            }
        ],
        execute: function () {
            ProdSrchOpReqHandler = (function (_super) {
                __extends(ProdSrchOpReqHandler, _super);
                function ProdSrchOpReqHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                ProdSrchOpReqHandler.prototype.supportedRequestType = function () {
                    return ProdSrchOpRequest_1.default;
                };
                ProdSrchOpReqHandler.prototype.executeAsync = function (request) {
                    var _this = this;
                    this.context.logger.logInformational("Log message from ProductSearchView executeAsync().", this.context.logger.getNewCorrelationId());
                    return new Promise(function (resolve) {
                        setTimeout(resolve, 1000);
                        _this.context.navigator.navigate("ProductSearchView");
                    });
                };
                return ProdSrchOpReqHandler;
            }(Operations_1.ExtensionOperationRequestHandlerBase));
            exports_1("default", ProdSrchOpReqHandler);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/Operations/InventoryLookup/ProdSrchOpReqHandler.js.map