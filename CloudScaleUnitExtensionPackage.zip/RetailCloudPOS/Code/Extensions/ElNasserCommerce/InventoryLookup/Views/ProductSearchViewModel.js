System.register(["knockout", "PosApi/Entities", "../DataService/DataServiceRequests.g", "../DataService/DataServiceEntities.g", "PosApi/TypeExtensions", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, Entities_1, DataServiceRequests_g_1, DataServiceEntities_g_1, TypeExtensions_1, ErrorHelper_1, ProductSearchViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ProductSearchViewModel = (function () {
                function ProductSearchViewModel(context, vState) {
                    this.PageSize = 50;
                    this._context = context;
                    this.state = vState;
                    this.searchProducts = knockout_1.default.observableArray([]);
                    this.selectedProducts = knockout_1.default.observableArray([]);
                    this.searchText = knockout_1.default.observable("");
                    this.allowTrans = knockout_1.default.observable(false);
                    this.showMatrix = knockout_1.default.observable(false);
                    this.isBlockSale = false;
                    this.getConfiguration();
                    this._context.logger.logInformational("ProductSearchViewModel: success");
                }
                ProductSearchViewModel.prototype.loadDataPage = function (size, skip) {
                    var _this = this;
                    var timeOut = skip == 0 ? 0 : 200;
                    var promise = new Promise(function (resolve) {
                        setTimeout(function () {
                            _this._context.logger.logInformational("dataListPageLoaded");
                            var pageData = _this.ProductSearchByText(size, skip);
                            resolve(pageData);
                        }, timeOut);
                    });
                    return promise;
                };
                ProductSearchViewModel.prototype.ProductSearchByText = function (size, skip) {
                    var _this = this;
                    this.state.isProcessing = true;
                    var RR = Commerce;
                    var ChannelConfig = JSON.parse(RR.ApplicationStorage.getItem(RR.ApplicationStorageIDs.CHANNEL_CONFIGURATION_KEY));
                    var projectionDomain = new DataServiceEntities_g_1.Entities.ProjectionDomain();
                    projectionDomain.ChannelId = ChannelConfig.RecordId;
                    var productSearchCriteria = new Entities_1.ProxyEntities.ProductSearchCriteriaClass();
                    productSearchCriteria.Context = projectionDomain;
                    productSearchCriteria.SearchCondition = !TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(this.searchText()) ? this.searchText() : "0";
                    productSearchCriteria.DataLevelValue = 1;
                    var request = new DataServiceRequests_g_1.Products.ProductSearchByTextRequest(productSearchCriteria, size, skip);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        _this.state.isProcessing = false;
                        if (!result.canceled) {
                            _this.searchProducts(result.data.result);
                            return result.data.result;
                        }
                        else
                            return [];
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        _this._context.logger.logError("Product search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        return [];
                    });
                };
                ProductSearchViewModel.prototype.itemClicked = function (item) {
                    if (item.IsMasterProduct == true && !item.IsKit)
                        this._context.navigator.navigate("ProductDimensionsView", item);
                    else {
                        var productDetailsOptions = new Entities_1.ClientEntities.SimpleProductDetailsNavigationParameters(item.Product.RecordId);
                        this._context.navigator.navigateToPOSView("SimpleProductDetailsView", productDetailsOptions);
                    }
                };
                ProductSearchViewModel.prototype.setSelectedItems = function (items) {
                    this.selectedProducts(items);
                    if (items.length == 0) {
                        this.allowTrans(false);
                        this.showMatrix(false);
                    }
                    else if (items.length == 1) {
                        this.allowTrans(true);
                        this.showMatrix(true);
                    }
                    else {
                        this.allowTrans(true);
                        this.showMatrix(false);
                    }
                };
                ProductSearchViewModel.prototype.ExportPorducts = function () {
                    var _this = this;
                    var products = this.searchProducts();
                    var requestObj = {
                        "FileName": "",
                        "Products": JSON.stringify(products)
                    };
                    var exportRequest = new Commerce.HardwareStationDeviceActionRequest("FILEOPERATION", "ExportProducts", requestObj);
                    this._context.runtime.executeAsync(exportRequest)
                        .then(function (resp) {
                        console.log(JSON.stringify(resp));
                        var respMsg = '';
                        if (resp.data.response == true)
                            respMsg = _this._context.resources.getString("PRODUCT_EXPORT_SUCCESS_MESSAGE");
                        else
                            respMsg = _this._context.resources.getString("PRODUCT_EXPORT_FAIL_MESSAGE");
                        _this.state.isProcessing = false;
                        ErrorHelper_1.ErrorHelper.displayMessageAsync(_this._context, respMsg);
                    })
                        .catch(function (reason) {
                        _this.state.isProcessing = false;
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                    });
                };
                ProductSearchViewModel.prototype.getConfiguration = function () {
                    var str_configuration = sessionStorage.getItem("RR_UtilitiesConfiguration");
                    var configuration = JSON.parse(str_configuration);
                    this.isBlockSale = false;
                    if (!Commerce.ObjectExtensions.isNullOrUndefined(configuration))
                        this.isBlockSale = configuration.BlockSales == 1;
                };
                return ProductSearchViewModel;
            }());
            exports_1("default", ProductSearchViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/Views/ProductSearchViewModel.js.map