System.register(["knockout", "PosApi/Create/Views", "./ProductDimensionsViewModel", "PosApi/TypeExtensions", "PosApi/Consume/Controls", "PosApi/Consume/Cart", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, ProductDimensionsViewModel_1, TypeExtensions_1, Controls, Cart_1, ErrorHelper_1, ProductDimensionsView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (ProductDimensionsViewModel_1_1) {
                ProductDimensionsViewModel_1 = ProductDimensionsViewModel_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (Controls_1) {
                Controls = Controls_1;
            },
            function (Cart_1_1) {
                Cart_1 = Cart_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ProductDimensionsView = (function (_super) {
                __extends(ProductDimensionsView, _super);
                function ProductDimensionsView(context, options) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("MAX_ILKP_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "quickSale",
                                    label: 'Sale now',
                                    icon: NewView.Icons.Buy,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.QuickSale();
                                    }
                                },
                                {
                                    name: "addtosale",
                                    label: 'Add item',
                                    icon: NewView.Icons.Add,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.AddProductToCart();
                                    }
                                }
                            ]
                        }
                    }) || this;
                    _this.productSaleDetail = [];
                    _this.totalVariants = 0;
                    _this.COLOR = 'Color';
                    _this.SIZE = 'Size';
                    _this.STYLE = 'Style';
                    _this.CONFIGURATION = 'Configuration';
                    _this._context = context;
                    _this.viewModel = new ProductDimensionsViewModel_1.default(context);
                    _this._productDetailOptions = knockout_1.default.observable(options);
                    _this.localizedProductName = knockout_1.default.observable("");
                    _this.localizedProductDescription = knockout_1.default.observable("");
                    _this._selectedVariants = knockout_1.default.observableArray([]);
                    _this.filteredVariants = knockout_1.default.observableArray([]);
                    _this.localOptions = knockout_1.default.observable({});
                    _this.allowTrans = knockout_1.default.observable(false);
                    _this.frequentlySelectedVariant = knockout_1.default.observable("");
                    _this.CanQuantityNegative = knockout_1.default.observable(false);
                    _this.alternateDimensions = knockout_1.default.observableArray([]);
                    _this.menuAnchor = knockout_1.default.observable(null);
                    _this.isMenuVisible = knockout_1.default.observable(false);
                    _this.isSizeVisible = knockout_1.default.observable(false);
                    _this.isColorVisible = knockout_1.default.observable(false);
                    _this.isStyleVisible = knockout_1.default.observable(false);
                    _this.isConfigurationVisible = knockout_1.default.observable(false);
                    _this.isItemSelected = false;
                    if (!TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this._productDetailOptions().RecordId)) {
                        _this.viewModel.getProductDimensions(_this._productDetailOptions().RecordId);
                        _this.state.isProcessing = true;
                        _this.viewModel.getProductDetails([_this._productDetailOptions().RecordId], true)
                            .then(function (products) {
                            _this.loadVariantList();
                            _this.state.isProcessing = false;
                        });
                    }
                    return _this;
                }
                ProductDimensionsView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var menuOptions = {
                        directionalHint: Controls.DirectionalHint.BottomCenter,
                        type: 'button',
                        commands: [
                            {
                                id: 'Color',
                                label: 'Color',
                                isVisible: true
                            },
                            {
                                id: 'Style',
                                label: 'Style',
                                isVisible: true
                            },
                            {
                                id: 'Size',
                                label: 'Size',
                                isVisible: true
                            },
                            {
                                id: 'Configuration',
                                label: 'Configuration',
                                isVisible: true
                            }
                        ]
                    };
                    var menuElem = element.querySelector("#buttonInteractionMenu");
                    var menuElem2 = element.querySelector("#buttonInteractionMenu2");
                    this.menu = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "Menu", menuOptions, menuElem);
                    this.menu2 = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "Menu", menuOptions, menuElem2);
                    this.menu.addEventListener("CommandInvoked", function (eventData) {
                        _this.switchDimensionHandler(eventData.id, _this, null);
                    });
                    this.menu2.addEventListener("CommandInvoked", function (eventData) {
                        _this.switchDimensionHandler(eventData.id, _this, null);
                    });
                };
                ProductDimensionsView.prototype.loadVariantList = function () {
                    this.state.isProcessing = true;
                    var color = "", size = "", style = "", config = "";
                    if (this.viewModel.bDimension1()) {
                        color = "", size = "", style = "", config = "";
                    }
                    if (this.viewModel.bDimension2()) {
                        color = "", size = "", style = "", config = "";
                    }
                    var dimValue = '';
                    if (this.viewModel.bDimension3()) {
                        var dimList3 = this.viewModel.dimensionList3()[0];
                        dimValue = dimList3.text;
                        switch (dimList3.dimension) {
                            case this.COLOR:
                                color = dimValue;
                                break;
                            case this.SIZE:
                                size = dimValue;
                                break;
                            case this.STYLE:
                                style = dimValue;
                                break;
                            case this.CONFIGURATION:
                                config = dimValue;
                                break;
                            default:
                                break;
                        }
                    }
                    if (this.viewModel.bDimension4()) {
                        var dimList4 = this.viewModel.dimensionList4()[0];
                        dimValue = dimList4.text;
                        switch (dimList4.dimension) {
                            case this.COLOR:
                                color = dimValue;
                                break;
                            case this.SIZE:
                                size = dimValue;
                                break;
                            case this.STYLE:
                                style = dimValue;
                                break;
                            case this.CONFIGURATION:
                                config = dimValue;
                                break;
                            default:
                                break;
                        }
                    }
                    this.localOptions({ Color: color, Size: size, Style: style, Config: config });
                    this.viewModel.LoadFilterVariants(color, size, style, config);
                    this.loadFilterVariants();
                };
                ProductDimensionsView.prototype.loadFilterVariants = function () {
                    var list = this.viewModel.dimensionFilterVariantList(), len1 = list.length;
                    var firstList = this.viewModel.dimensionList1(), len2 = firstList.length;
                    var filterList = [], me = this;
                    for (var i = 0; i < len2; i++) {
                        var groupHeaderItem = firstList[i], secondlevelItems = [];
                        var gpHeaderName = groupHeaderItem.dimension;
                        var gpHeaderNameID = groupHeaderItem.dimension == this.CONFIGURATION ? 'ConfigId' : groupHeaderItem.dimension + 'Id';
                        for (var x = 0; x < len1; x++) {
                            if (list[x][gpHeaderName] === groupHeaderItem.text || list[x][gpHeaderNameID] === groupHeaderItem.text) {
                                secondlevelItems.push(list[x]);
                            }
                        }
                        if (me.viewModel.bDimension2()) {
                            switch (me.viewModel.dimensionName2()) {
                                case this.COLOR:
                                    secondlevelItems.sort(me.SortByColor);
                                    break;
                                case this.SIZE:
                                    secondlevelItems.sort(me.SortBySize);
                                    break;
                                case this.STYLE:
                                    secondlevelItems.sort(me.SortByStyle);
                                    break;
                                case this.CONFIGURATION:
                                    secondlevelItems.sort(me.SortByConfig);
                                    break;
                                default:
                                    break;
                            }
                        }
                        var groupItems = { groupTxt: groupHeaderItem.text, groupVal: this.viewModel.encodeInputStr(groupHeaderItem.text), itemList: secondlevelItems, secondFilter: me.viewModel.dimensionList2(), b_filter2: me.viewModel.bDimension2() };
                        filterList.push(groupItems);
                    }
                    this.filteredVariants(filterList);
                    this.state.isProcessing = false;
                };
                ProductDimensionsView.prototype.dimensionHandler = function (data) {
                    this.clearDimensionSelection(data);
                    var temp = this.localOptions();
                    var dimValue = data.text;
                    switch (data.dimension) {
                        case this.COLOR:
                            this.localOptions({ Color: dimValue, Size: temp.Size, Style: temp.Style, Config: temp.Config });
                            break;
                        case this.SIZE:
                            this.localOptions({ Color: temp.Color, Size: dimValue, Style: temp.Style, Config: temp.Config });
                            break;
                        case this.STYLE:
                            this.localOptions({ Color: temp.Color, Size: temp.Size, Style: dimValue, Config: temp.Config });
                            break;
                        case this.CONFIGURATION:
                            this.localOptions({ Color: temp.Color, Size: temp.Size, Style: temp.Style, Config: dimValue });
                            break;
                        default:
                            break;
                    }
                    temp = this.localOptions();
                    this.viewModel.LoadFilterVariants(temp.Color, temp.Size, temp.Style, temp.Config);
                    this.loadFilterVariants();
                };
                ProductDimensionsView.prototype.variantHandler = function (model, action, xelement, yelement, data, ev) {
                    if (model.viewModel.isBlockSale) {
                        if (!(data.Quantity > 0) || (data.Quantity == data.TransQuantity))
                            return;
                    }
                    var filterList = [];
                    var bool = false;
                    $.each(model.filteredVariants(), function (index, item) {
                        var idx = item.itemList.indexOf(data);
                        if (idx != -1) {
                            data.TransQuantity = action === "add" ? data.TransQuantity + 1 : 0;
                            item.itemList[idx] = data;
                        }
                        if (data.TransQuantity > 0)
                            bool = true;
                        var newItem = { groupTxt: item.groupTxt, groupVal: item.groupVal, itemList: item.itemList, secondFilter: item.secondFilter, b_filter2: item.b_filter2 };
                        filterList.push(newItem);
                    });
                    model.filteredVariants([]);
                    model.filteredVariants(filterList);
                    model.allowTrans(bool);
                    model.frequentlySelectedVariant(data.VariantId);
                    var $elementx = $("#" + xelement);
                    var $elementy;
                    if (model.viewModel.bDimension2())
                        $elementy = $("#" + yelement);
                    $elementx.removeClass("accentBackground").addClass("secondaryBackgroundColor");
                    if (model.viewModel.bDimension2()) {
                        $elementy.removeClass("accentBackground").addClass("secondaryBackgroundColor");
                    }
                    setTimeout(function () {
                        $elementx.addClass("accentBackground").removeClass("secondaryBackgroundColor");
                        if (model.viewModel.bDimension2()) {
                            $elementy.addClass("accentBackground").removeClass("secondaryBackgroundColor");
                        }
                    }, 150);
                    if (!this.isItemSelected) {
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(model.state.commandBar.commands, function (c) { return c.name === 'quickSale'; }).canExecute = model.allowTrans();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(model.state.commandBar.commands, function (c) { return c.name === 'addtosale'; }).canExecute = model.allowTrans();
                    }
                    this.isItemSelected = true;
                };
                ProductDimensionsView.prototype.clearDimensionSelection = function (data) {
                    var objArray = [];
                    switch (data.dimension) {
                        case this.viewModel.dimensionName1():
                            objArray = this.viewModel.dimensionList1();
                            this.viewModel.dimensionList1([]);
                            for (var i = 0; i < objArray.length; i++) {
                                objArray[i].isSelected = objArray[i].value == data.value ? true : false;
                            }
                            this.viewModel.dimensionList1(objArray);
                            break;
                        case this.viewModel.dimensionName2():
                            objArray = this.viewModel.dimensionList2();
                            this.viewModel.dimensionList2([]);
                            for (var i = 0; i < objArray.length; i++) {
                                objArray[i].isSelected = objArray[i].value == data.value ? true : false;
                            }
                            this.viewModel.dimensionList2(objArray);
                            break;
                        case this.viewModel.dimensionName3():
                            objArray = this.viewModel.dimensionList3();
                            this.viewModel.dimensionList3([]);
                            for (var i = 0; i < objArray.length; i++) {
                                objArray[i].isSelected = objArray[i].value == data.value ? true : false;
                            }
                            this.viewModel.dimensionList3(objArray);
                            break;
                        case this.viewModel.dimensionName4():
                            objArray = this.viewModel.dimensionList4();
                            this.viewModel.dimensionList4([]);
                            for (var i = 0; i < objArray.length; i++) {
                                objArray[i].isSelected = objArray[i].value == data.value ? true : false;
                            }
                            this.viewModel.dimensionList4(objArray);
                            break;
                        default:
                            break;
                    }
                };
                ProductDimensionsView.prototype.dimensionOrderHandler = function (data, isSwitch) {
                    var control = document.getElementById("dimensionFlyout")['winControl'], arr = [], objArray = [], dochange = false;
                    if (data == "apply") {
                        if (!isSwitch) {
                            var list = $("#dimensionNameList h4");
                            for (var i = 0; i < list.length; i++) {
                                var item = list[i];
                                arr.push({ name: item.innerText });
                                if (!dochange) {
                                    dochange = !(item.innerText == this.viewModel.dimensions()[i].name);
                                }
                            }
                            this.viewModel.dimensions(arr);
                        }
                        else {
                            arr = this.viewModel.dimensions();
                            dochange = true;
                        }
                        if (dochange) {
                            for (var i = 0; i < arr.length; i++) {
                                switch (arr[i].name) {
                                    case this.viewModel.dimensionName1():
                                        switch (i) {
                                            case 0:
                                                this.viewModel.dimensionList1(this.viewModel.dimList1());
                                                break;
                                            case 1:
                                                this.viewModel.dimensionList2(this.viewModel.dimList1());
                                                break;
                                            case 2:
                                                this.viewModel.dimensionList3(this.viewModel.dimList1());
                                                break;
                                            case 3:
                                                this.viewModel.dimensionList4(this.viewModel.dimList1());
                                                break;
                                        }
                                        break;
                                    case this.viewModel.dimensionName2():
                                        switch (i) {
                                            case 0:
                                                this.viewModel.dimensionList1(this.viewModel.dimList2());
                                                break;
                                            case 1:
                                                this.viewModel.dimensionList2(this.viewModel.dimList2());
                                                break;
                                            case 2:
                                                this.viewModel.dimensionList3(this.viewModel.dimList2());
                                                break;
                                            case 3:
                                                this.viewModel.dimensionList4(this.viewModel.dimList2());
                                                break;
                                        }
                                        break;
                                    case this.viewModel.dimensionName3():
                                        switch (i) {
                                            case 0:
                                                this.viewModel.dimensionList1(this.viewModel.dimList3());
                                                break;
                                            case 1:
                                                this.viewModel.dimensionList2(this.viewModel.dimList3());
                                                break;
                                            case 2:
                                                this.viewModel.dimensionList3(this.viewModel.dimList3());
                                                break;
                                            case 3:
                                                this.viewModel.dimensionList4(this.viewModel.dimList3());
                                                break;
                                        }
                                        break;
                                    case this.viewModel.dimensionName4():
                                        switch (i) {
                                            case 0:
                                                this.viewModel.dimensionList1(this.viewModel.dimList4());
                                                break;
                                            case 1:
                                                this.viewModel.dimensionList2(this.viewModel.dimList4());
                                                break;
                                            case 2:
                                                this.viewModel.dimensionList3(this.viewModel.dimList4());
                                                break;
                                            case 3:
                                                this.viewModel.dimensionList4(this.viewModel.dimList4());
                                                break;
                                        }
                                        break;
                                }
                            }
                            for (var x = 0; x < arr.length; x++) {
                                objArray = [];
                                switch (x) {
                                    case 0:
                                        this.viewModel.dimensionName1(arr[x].name);
                                        break;
                                    case 1:
                                        this.viewModel.dimensionName2(arr[x].name);
                                        this.viewModel.dimensionList2(this.viewModel.dimensionList2().sort(this.viewModel.SortByName));
                                        break;
                                    case 2:
                                        this.viewModel.dimensionName3(arr[x].name);
                                        objArray = this.viewModel.dimensionList3();
                                        this.viewModel.dimensionList3([]);
                                        for (var i = 0; i < objArray.length; i++) {
                                            objArray[i].isSelected = i == 0 ? true : false;
                                        }
                                        this.viewModel.dimensionList3(objArray);
                                        break;
                                    case 3:
                                        this.viewModel.dimensionName4(arr[x].name);
                                        objArray = this.viewModel.dimensionList4();
                                        this.viewModel.dimensionList4([]);
                                        for (var i = 0; i < objArray.length; i++) {
                                            objArray[i].isSelected = i == 0 ? true : false;
                                        }
                                        this.viewModel.dimensionList4(objArray);
                                        break;
                                }
                            }
                            this.viewModel.dimList1(this.viewModel.dimensionList1());
                            this.viewModel.dimList2(this.viewModel.dimensionList2());
                            this.viewModel.dimList3(this.viewModel.dimensionList3());
                            this.viewModel.dimList4(this.viewModel.dimensionList4());
                            this.loadVariantList();
                        }
                    }
                    control.hide();
                };
                ProductDimensionsView.prototype.dimensionPositioHandler = function (data, src, ev) {
                    var btn = $(ev.currentTarget), item = btn.parents('.dimension-grid');
                    if (data == 'up') {
                        var prev = item.prev();
                        if (prev.length == 0)
                            return;
                        prev.css('z-index', 999).css('position', 'relative').animate({ top: item.outerHeight(true) }, 250);
                        item.css('z-index', 1000).css('position', 'relative').animate({ top: '-' + prev.outerHeight(true) }, 300, function () {
                            prev.css('z-index', '').css('top', '').css('position', '');
                            item.css('z-index', '').css('top', '').css('position', '');
                            item.insertBefore(prev);
                        });
                    }
                    else {
                        var next = item.next();
                        if (next.length == 0)
                            return;
                        next.css('z-index', 999).css('position', 'relative').animate({ top: '-' + item.outerHeight(true) }, 250);
                        item.css('z-index', 1000).css('position', 'relative').animate({ top: next.outerHeight(true) }, 300, function () {
                            next.css('z-index', '').css('top', '').css('position', '');
                            item.css('z-index', '').css('top', '').css('position', '');
                            item.insertAfter(next);
                        });
                    }
                };
                ProductDimensionsView.prototype.showDimensionPopup = function () {
                    this.viewModel.dimensions(this.viewModel.dimensions());
                    var btn = document.getElementById("popupButton");
                    var winControl = document.getElementById("dimensionFlyout")['winControl'];
                    winControl.show(btn);
                };
                ProductDimensionsView.prototype.switchDimensionHandler = function (data, self, ev) {
                    var oldValue = $('#hidDimension').val(), newValue = data, arr = self.viewModel.dimensions();
                    self.viewModel.dimensions([]);
                    for (var i = 0; i < arr.length; i++) {
                        if (arr[i].name == oldValue) {
                            arr[i].name = newValue;
                        }
                        else if (arr[i].name == newValue) {
                            arr[i].name = oldValue;
                        }
                    }
                    self.viewModel.dimensions(arr);
                    self.dimensionOrderHandler('apply', true);
                };
                ProductDimensionsView.prototype.alternateDimensionPopup = function (dimension, self, data, ev) {
                    var arr = self.viewModel.dimensions();
                    self.isMenuVisible(false);
                    self.isColorVisible(false);
                    self.isSizeVisible(false);
                    self.isStyleVisible(false);
                    self.isConfigurationVisible(false);
                    self.alternateDimensions([]);
                    self.alternateDimensions(arr.filter(function (item) { return item.name !== dimension; }));
                    for (var i = 0; i < self.alternateDimensions().length; i++) {
                        switch (self.alternateDimensions()[i].name) {
                            case self.COLOR:
                                self.isColorVisible(true);
                                break;
                            case self.SIZE:
                                self.isSizeVisible(true);
                                break;
                            case self.STYLE:
                                self.isStyleVisible(true);
                                break;
                            case self.CONFIGURATION:
                                self.isConfigurationVisible(true);
                                break;
                        }
                    }
                    self.showAvilableDimentions(self, self.menu2);
                    self.menu.show(event.currentTarget);
                    $('#hidDimension').val(dimension);
                };
                ProductDimensionsView.prototype.alternateDimensionPopup2 = function (dimension, self, data, ev) {
                    var arr = self.viewModel.dimensions();
                    self.isMenuVisible(false);
                    self.isColorVisible(false);
                    self.isSizeVisible(false);
                    self.isStyleVisible(false);
                    self.isConfigurationVisible(false);
                    self.alternateDimensions([]);
                    self.alternateDimensions(arr.filter(function (item) { return item.name !== dimension; }));
                    for (var i = 0; i < self.alternateDimensions().length; i++) {
                        switch (self.alternateDimensions()[i].name) {
                            case self.COLOR:
                                self.isColorVisible(true);
                                break;
                            case self.SIZE:
                                self.isSizeVisible(true);
                                break;
                            case self.STYLE:
                                self.isStyleVisible(true);
                                break;
                            case self.CONFIGURATION:
                                self.isConfigurationVisible(true);
                                break;
                        }
                    }
                    self.showAvilableDimentions(self, self.menu2);
                    self.menu2.show(event.currentTarget);
                    $('#hidDimension').val(dimension);
                };
                ProductDimensionsView.prototype.showAvilableDimentions = function (self, menu) {
                    TypeExtensions_1.ArrayExtensions.firstOrUndefined(menu.menuCommands, function (c) { return c.id === 'Color'; }).isVisible = self.isColorVisible();
                    TypeExtensions_1.ArrayExtensions.firstOrUndefined(menu.menuCommands, function (c) { return c.id === 'Style'; }).isVisible = self.isStyleVisible();
                    TypeExtensions_1.ArrayExtensions.firstOrUndefined(menu.menuCommands, function (c) { return c.id === 'Size'; }).isVisible = self.isSizeVisible();
                    TypeExtensions_1.ArrayExtensions.firstOrUndefined(menu.menuCommands, function (c) { return c.id === 'Configuration'; }).isVisible = self.isConfigurationVisible();
                };
                ProductDimensionsView.prototype.variantListSelectionChanged = function (items) {
                    var variants = [];
                    items.forEach(function (list, ind, _ary) {
                        variants.push(list.DistinctVariant);
                    });
                    this._selectedVariants(variants);
                };
                ProductDimensionsView.prototype.QuickSale = function (isQuickSale) {
                    if (isQuickSale === void 0) { isQuickSale = true; }
                    this.state.isProcessing = true;
                    this.processCartDetails(isQuickSale);
                };
                ProductDimensionsView.prototype.processCartDetails = function (isQuickSale) {
                    var self = this;
                    $.each(this.viewModel.productVariantList(), function (index, item) {
                        if (item.TransQuantity > 0) {
                            var dimensions = [];
                            var quantity = 0;
                            var color = TypeExtensions_1.StringExtensions.isEmpty(item.Color) || TypeExtensions_1.StringExtensions.isNullOrWhitespace(item.Color) ? item.ColorId : item.Color;
                            var size = TypeExtensions_1.StringExtensions.isEmpty(item.Size) || TypeExtensions_1.StringExtensions.isNullOrWhitespace(item.Size) ? item.SizeId : item.Size;
                            var style = TypeExtensions_1.StringExtensions.isEmpty(item.Style) || TypeExtensions_1.StringExtensions.isNullOrWhitespace(item.Style) ? item.StyleId : item.Style;
                            var configuration = TypeExtensions_1.StringExtensions.isEmpty(item.Configuration) || TypeExtensions_1.StringExtensions.isNullOrWhitespace(item.Configuration) ? item.ConfigId : item.Configuration;
                            if (!TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(color)) {
                                dimensions.push({ DimensionTypeValue: 1, DimensionValue: { RecordId: 0, Value: color } });
                            }
                            if (!TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(size)) {
                                dimensions.push({ DimensionTypeValue: 3, DimensionValue: { RecordId: 0, Value: size } });
                            }
                            if (!TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(style)) {
                                dimensions.push({ DimensionTypeValue: 4, DimensionValue: { RecordId: 0, Value: style } });
                            }
                            if (!TypeExtensions_1.StringExtensions.isEmptyOrWhitespace(configuration)) {
                                dimensions.push({ DimensionTypeValue: 2, DimensionValue: { RecordId: 0, Value: configuration } });
                            }
                            quantity += item.TransQuantity;
                            if (!TypeExtensions_1.ObjectExtensions.isNullOrUndefined(self.viewModel.product())) {
                                var selectedProductDimension = [];
                                return self.viewModel.getDimensionValues(self.viewModel.product().RecordId, dimensions[0].DimensionTypeValue, null, null)
                                    .then(function (productDimensions) {
                                    for (var i = 0; i < productDimensions.length; i++) {
                                        if (dimensions[0].DimensionValue.Value == productDimensions[i].Value) {
                                            selectedProductDimension.push({
                                                DimensionTypeValue: dimensions[0].DimensionTypeValue,
                                                DimensionValue: productDimensions[i]
                                            });
                                            break;
                                        }
                                    }
                                    if (dimensions.length > 1) {
                                        return self.viewModel.getDimensionValues(self.viewModel.product().RecordId, dimensions[1].DimensionTypeValue, null, selectedProductDimension)
                                            .then(function (productDimensions2) {
                                            for (var i = 0; i < productDimensions2.length; i++) {
                                                if (dimensions[1].DimensionValue.Value == productDimensions2[i].Value) {
                                                    selectedProductDimension.push({
                                                        DimensionTypeValue: dimensions[1].DimensionTypeValue,
                                                        DimensionValue: productDimensions2[i]
                                                    });
                                                    break;
                                                }
                                            }
                                            if (dimensions.length > 2) {
                                                return self.viewModel.getDimensionValues(self.viewModel.product().RecordId, dimensions[2].DimensionTypeValue, null, selectedProductDimension)
                                                    .then(function (productDimensions3) {
                                                    for (var i = 0; i < productDimensions3.length; i++) {
                                                        if (dimensions[2].DimensionValue.Value == productDimensions3[i].Value) {
                                                            selectedProductDimension.push({
                                                                DimensionTypeValue: dimensions[2].DimensionTypeValue,
                                                                DimensionValue: productDimensions3[i]
                                                            });
                                                            break;
                                                        }
                                                    }
                                                    if (dimensions.length > 3) {
                                                        return self.viewModel.getDimensionValues(self.viewModel.product().RecordId, dimensions[3].DimensionTypeValue, null, selectedProductDimension)
                                                            .then(function (productDimensions4) {
                                                            for (var i = 0; i < productDimensions4.length; i++) {
                                                                if (dimensions[3].DimensionValue.Value == productDimensions4[i].Value) {
                                                                    selectedProductDimension.push({
                                                                        DimensionTypeValue: dimensions[3].DimensionTypeValue,
                                                                        DimensionValue: productDimensions4[i]
                                                                    });
                                                                    break;
                                                                }
                                                            }
                                                            return self.AddItemToCart(selectedProductDimension, isQuickSale, quantity);
                                                        }).catch(function (err) {
                                                            self.state.isProcessing = false;
                                                            return Promise.resolve();
                                                        });
                                                    }
                                                    else
                                                        return self.AddItemToCart(selectedProductDimension, isQuickSale, quantity);
                                                }).catch(function (err) {
                                                    self.state.isProcessing = false;
                                                    return Promise.resolve();
                                                });
                                            }
                                            else
                                                return self.AddItemToCart(selectedProductDimension, isQuickSale, quantity);
                                        }).catch(function (err) {
                                            self.state.isProcessing = false;
                                            return Promise.resolve();
                                        });
                                    }
                                    else {
                                        return self.AddItemToCart(selectedProductDimension, isQuickSale, quantity);
                                    }
                                }).catch(function (err) {
                                    self.state.isProcessing = false;
                                    return Promise.resolve();
                                });
                            }
                            else
                                return null;
                        }
                        else
                            return null;
                    });
                };
                ProductDimensionsView.prototype.AddItemToCart = function (selectedProductDimension, isQuickSale, quantity) {
                    var self = this;
                    return self.viewModel.getProductVariantDetails(self.viewModel.product().RecordId, selectedProductDimension)
                        .then(function (simpleProducts) {
                        self.productSaleDetail.push({
                            product: simpleProducts[0],
                            quantity: quantity,
                            productId: simpleProducts[0].RecordId,
                        });
                        if (self.totalVariants == 0) {
                            for (var i = 0; i < self.viewModel.productVariantList().length; i++) {
                                if (self.viewModel.productVariantList()[i].TransQuantity > 0)
                                    self.totalVariants += 1;
                            }
                        }
                        if (self.productSaleDetail.length == self.totalVariants) {
                            var addItemToCartOperationRequest = new Cart_1.AddItemToCartOperationRequest(self.productSaleDetail, self._context.logger.getNewCorrelationId());
                            return self._context.runtime.executeAsync(addItemToCartOperationRequest)
                                .then(function (getgddItemToCartOperationResponse) {
                                self.state.isProcessing = false;
                                if (!getgddItemToCartOperationResponse.canceled && isQuickSale) {
                                    self._context.navigator.navigateToPOSView("CartView");
                                }
                                else {
                                    self._context.navigator.navigateBack();
                                }
                            }).catch(function (err) {
                                self.state.isProcessing = false;
                                ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(self._context, err);
                            });
                        }
                        return Promise.resolve();
                    }).catch(function (err) {
                        self.state.isProcessing = false;
                        return Promise.resolve();
                    });
                };
                ProductDimensionsView.prototype.AddProductToCart = function () {
                    this.QuickSale(false);
                };
                ProductDimensionsView.prototype.SortByColor = function (x, y) {
                    return ((x.Color == y.Color) ? 0 : ((x.Color > y.Color) ? 1 : -1));
                };
                ProductDimensionsView.prototype.SortByStyle = function (x, y) {
                    return ((x.Style == y.Style) ? 0 : ((x.Style > y.Style) ? 1 : -1));
                };
                ProductDimensionsView.prototype.SortBySize = function (x, y) {
                    return ((x.Size == y.Size) ? 0 : ((x.Size > y.Size) ? 1 : -1));
                };
                ProductDimensionsView.prototype.SortByConfig = function (x, y) {
                    return ((x.Configuration == y.Configuration) ? 0 : ((x.Configuration > y.Configuration) ? 1 : -1));
                };
                ProductDimensionsView.prototype.onCreated = function (element) {
                };
                ProductDimensionsView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                ProductDimensionsView.prototype.onShown = function () {
                };
                return ProductDimensionsView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", ProductDimensionsView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/Views/ProductDimensionsView.js.map