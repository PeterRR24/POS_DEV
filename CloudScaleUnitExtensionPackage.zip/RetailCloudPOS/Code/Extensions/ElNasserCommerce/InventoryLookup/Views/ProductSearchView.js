System.register(["knockout", "PosApi/Create/Views", "./ProductSearchViewModel", "PosApi/TypeExtensions", "PosApi/Consume/Formatters", "PosApi/Consume/Controls", "PosApi/Entities", "PosApi/Consume/Cart", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var knockout_1, NewView, ProductSearchViewModel_1, TypeExtensions_1, Formatters_1, Controls, Entities_1, Cart_1, ErrorHelper_1, ProductSearchView;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (NewView_1) {
                NewView = NewView_1;
            },
            function (ProductSearchViewModel_1_1) {
                ProductSearchViewModel_1 = ProductSearchViewModel_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (Formatters_1_1) {
                Formatters_1 = Formatters_1_1;
            },
            function (Controls_1) {
                Controls = Controls_1;
            },
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (Cart_1_1) {
                Cart_1 = Cart_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ProductSearchView = (function (_super) {
                __extends(ProductSearchView, _super);
                function ProductSearchView(context) {
                    var _this = _super.call(this, context, {
                        title: context.resources.getString("MAX_PROD_SEARCH_PAGE_TITLE"),
                        commandBar: {
                            commands: [
                                {
                                    name: "quickSale",
                                    label: 'Sale now',
                                    icon: NewView.Icons.Buy,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.QuickSale();
                                    }
                                },
                                {
                                    name: "addtosale",
                                    label: 'Add item',
                                    icon: NewView.Icons.Add,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.AddProductToCart();
                                    }
                                },
                                {
                                    name: "showMatrix",
                                    label: 'Item details',
                                    icon: NewView.Icons.PageList,
                                    isVisible: true,
                                    canExecute: false,
                                    execute: function (args) {
                                        _this.navigateProdDetails();
                                    }
                                },
                                {
                                    name: "exportProds",
                                    label: context.resources.getString('EXPORT_PRODUCT_BUTTON'),
                                    icon: NewView.Icons.CloudUpload,
                                    isVisible: true,
                                    canExecute: true,
                                    execute: function (args) {
                                        _this.exportOperation();
                                    }
                                }
                            ]
                        }
                    }) || this;
                    _this.viewModel = new ProductSearchViewModel_1.default(context, _this.state);
                    return _this;
                }
                ProductSearchView.prototype.onReady = function (element) {
                    var _this = this;
                    knockout_1.default.applyBindings(this, element);
                    var paginatedDataSource = {
                        pageSize: this.viewModel.PageSize,
                        loadDataPage: this.viewModel.loadDataPage.bind(this.viewModel)
                    };
                    var dataListOptions = {
                        columns: [
                            {
                                title: this.context.resources.getString("PRODUCT_ID"),
                                ratio: 20,
                                collapseOrder: 1,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.ItemId; }
                            },
                            {
                                title: this.context.resources.getString("PRODUCT_NAME"),
                                ratio: 40,
                                collapseOrder: 2,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.ProductName; }
                            },
                            {
                                title: this.context.resources.getString("PRODUCT_TYPE"),
                                ratio: 20,
                                collapseOrder: 3,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.ProductType; }
                            },
                            {
                                title: this.context.resources.getString("PRODUCT_PRICE"),
                                ratio: 10,
                                collapseOrder: 4,
                                minWidth: 100,
                                computeValue: function (rowData) { return Formatters_1.CurrencyFormatter.toCurrency(rowData.Price); }
                            },
                            {
                                title: this.context.resources.getString("PRODUCT_AVAIL_QTY"),
                                ratio: 10,
                                collapseOrder: 5,
                                minWidth: 100,
                                computeValue: function (rowData) { return rowData.Quantity.toString(); }
                            }
                        ],
                        data: paginatedDataSource,
                        interactionMode: Controls.DataListInteractionMode.MultiSelect,
                    };
                    var dataListRootElem = element.querySelector("#productlistview");
                    this.paginatedDataList = this.context.controlFactory.create(this.context.logger.getNewCorrelationId(), "PaginatedDataList", dataListOptions, dataListRootElem);
                    this.paginatedDataList.addEventListener("ItemInvoked", function (eventData) {
                        _this.viewModel.itemClicked(eventData.item);
                    });
                    this.paginatedDataList.addEventListener("SelectionChanged", function (eventData) {
                        _this.viewModel.setSelectedItems(eventData.items);
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'quickSale'; }).canExecute = _this.viewModel.allowTrans();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'addtosale'; }).canExecute = _this.viewModel.allowTrans();
                        TypeExtensions_1.ArrayExtensions.firstOrUndefined(_this.state.commandBar.commands, function (c) { return c.name === 'showMatrix'; }).canExecute = _this.viewModel.showMatrix();
                    });
                };
                ProductSearchView.prototype.dispose = function () {
                    TypeExtensions_1.ObjectExtensions.disposeAllProperties(this);
                };
                ProductSearchView.prototype.reloadItemList = function () {
                    this.paginatedDataList.reloadData();
                    this.viewModel.setSelectedItems([]);
                };
                ProductSearchView.prototype.searchClickHandler = function () {
                    this.reloadItemList();
                };
                ProductSearchView.prototype.navigateProdDetails = function () {
                    var items = this.viewModel.selectedProducts();
                    if (items.length == 1) {
                        if (items[0].IsMasterProduct == true && !items[0].IsKit)
                            this.context.navigator.navigate("ProductDimensionsView", items[0]);
                        else {
                            var productDetailsOptions = new Entities_1.ClientEntities.SimpleProductDetailsNavigationParameters(items[0].Product.RecordId);
                            this.context.navigator.navigateToPOSView("SimpleProductDetailsView", productDetailsOptions);
                        }
                    }
                };
                ProductSearchView.prototype.QuickSale = function (isQuickSale) {
                    var _this = this;
                    if (isQuickSale === void 0) { isQuickSale = true; }
                    var products = this.viewModel.selectedProducts();
                    var selectedProducts = [];
                    var productNames = '';
                    if (this.viewModel.isBlockSale) {
                        for (var idx = 0; idx < products.length; idx++) {
                            if (products[idx].IsMasterProduct || products[idx].IsKit) {
                                selectedProducts.push(products[idx]);
                            }
                            else if (products[idx].AvailableQuantity > 0) {
                                selectedProducts.push(products[idx]);
                            }
                            else {
                                productNames += products[idx].ItemId + '::' + products[idx].ProductName + '\r\n';
                            }
                        }
                        if (selectedProducts.length == 0)
                            return;
                    }
                    else
                        selectedProducts = products;
                    this.state.isProcessing = true;
                    var productSaleDetail = [];
                    for (var i = 0; i < selectedProducts.length; i++) {
                        productSaleDetail.push({
                            quantity: 1,
                            productId: selectedProducts[i].RecordId,
                        });
                    }
                    var addItemToCartOperationRequest = new Cart_1.AddItemToCartOperationRequest(productSaleDetail, this.context.logger.getNewCorrelationId());
                    this.context.runtime.executeAsync(addItemToCartOperationRequest)
                        .then(function (getgddItemToCartOperationResponse) {
                        _this.state.isProcessing = false;
                        if (!getgddItemToCartOperationResponse.canceled) {
                            if (isQuickSale && TypeExtensions_1.StringExtensions.isEmpty(productNames))
                                _this.context.navigator.navigateToPOSView("CartView");
                            else if (isQuickSale && !TypeExtensions_1.StringExtensions.isEmpty(productNames)) {
                                ErrorHelper_1.ErrorHelper.displayMessageAsync(_this.context, TypeExtensions_1.StringExtensions.format(_this.context.resources.getString('PRODUCT_QUANTITY_ZERO_ALERT'), productNames))
                                    .then(function () {
                                    _this.context.navigator.navigateToPOSView("CartView");
                                });
                            }
                            else if (!isQuickSale && !TypeExtensions_1.StringExtensions.isEmpty(productNames)) {
                                ErrorHelper_1.ErrorHelper.displayMessageAsync(_this.context, TypeExtensions_1.StringExtensions.format(_this.context.resources.getString('PRODUCT_QUANTITY_ZERO_ALERT'), productNames));
                            }
                        }
                    }).catch(function (err) {
                        _this.state.isProcessing = false;
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this.context, err);
                    });
                };
                ProductSearchView.prototype.exportOperation = function () {
                    this.viewModel.ExportPorducts();
                };
                ProductSearchView.prototype.AddProductToCart = function () {
                    this.QuickSale(false);
                };
                ProductSearchView.prototype.onCreated = function (element) {
                };
                ProductSearchView.prototype.onShown = function () {
                };
                return ProductSearchView;
            }(NewView.CustomViewControllerBase));
            exports_1("default", ProductSearchView);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/Views/ProductSearchView.js.map