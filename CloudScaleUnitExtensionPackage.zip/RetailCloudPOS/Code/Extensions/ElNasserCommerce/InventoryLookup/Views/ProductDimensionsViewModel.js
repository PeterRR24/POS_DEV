System.register(["knockout", "PosApi/Entities", "../DataService/DataServiceEntities.g", "../DataService/DataServiceRequests.g", "PosApi/TypeExtensions", "../../ErrorHelper"], function (exports_1, context_1) {
    "use strict";
    var knockout_1, Entities_1, DataServiceEntities_g_1, DataServiceRequests_g_1, TypeExtensions_1, ErrorHelper_1, ProductDimensionsViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (DataServiceRequests_g_1_1) {
                DataServiceRequests_g_1 = DataServiceRequests_g_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (ErrorHelper_1_1) {
                ErrorHelper_1 = ErrorHelper_1_1;
            }
        ],
        execute: function () {
            ProductDimensionsViewModel = (function () {
                function ProductDimensionsViewModel(context) {
                    this._context = context;
                    this.product = knockout_1.default.observable(new Entities_1.ProxyEntities.ProductClass());
                    this.simpleProduct = knockout_1.default.observable(new Entities_1.ProxyEntities.SimpleProductClass());
                    this.dimensionValue = knockout_1.default.observableArray([]);
                    this.dimensionFilterVariantList = knockout_1.default.observableArray([]);
                    this.productVariantList = knockout_1.default.observableArray([]);
                    this.dimensionList = [];
                    this.selectedVariant = knockout_1.default.observable(null);
                    this.productName = knockout_1.default.observable("");
                    this.bDimensionInfiFilled = knockout_1.default.observable(false);
                    this.bDimension1 = knockout_1.default.observable(false);
                    this.bDimension2 = knockout_1.default.observable(false);
                    this.bDimension3 = knockout_1.default.observable(false);
                    this.bDimension4 = knockout_1.default.observable(false);
                    this.dimensionName1 = knockout_1.default.observable("");
                    this.dimensionName2 = knockout_1.default.observable("");
                    this.dimensionName3 = knockout_1.default.observable("");
                    this.dimensionName4 = knockout_1.default.observable("");
                    this.dimensionList1 = knockout_1.default.observableArray([]);
                    this.dimensionList2 = knockout_1.default.observableArray([]);
                    this.dimensionList3 = knockout_1.default.observableArray([]);
                    this.dimensionList4 = knockout_1.default.observableArray([]);
                    this.dimList1 = knockout_1.default.observableArray([]);
                    this.dimList2 = knockout_1.default.observableArray([]);
                    this.dimList3 = knockout_1.default.observableArray([]);
                    this.dimList4 = knockout_1.default.observableArray([]);
                    this.dimensions = knockout_1.default.observableArray([]);
                    this.isBlockSale = false;
                    this.ChannelID = 0;
                    this.getConfiguration();
                    this._context.logger.logInformational("ProductDimensionsViewModel: success");
                }
                ProductDimensionsViewModel.prototype.LoadFilterVariants = function (color, size, style, configuration) {
                    var bColor, bSize, bStyle, bConfig;
                    var objArrray = [], len = this.productVariantList().length;
                    this.dimensionFilterVariantList([]);
                    for (var i = 0; i < len; i++) {
                        var obj = this.productVariantList()[i];
                        bColor = color == "" ? true : (obj.ColorId == color);
                        bSize = size == "" ? true : (obj.SizeId == size);
                        bStyle = style == "" ? true : (obj.StyleId == style);
                        bConfig = configuration == "" ? true : (obj.ConfigId == configuration);
                        if (bColor && bSize && bStyle && bConfig) {
                            objArrray.push(obj);
                        }
                    }
                    this.dimensionFilterVariantList(objArrray);
                };
                ProductDimensionsViewModel.prototype.SetActiveVariant = function (variantId) {
                    if (this.product().IsMasterProduct) {
                        this.selectedVariant(this.product().CompositionInformation.VariantInformation.Variants.filter(function (v) { return v.DistinctProductVariantId == variantId; })[0]);
                    }
                };
                ProductDimensionsViewModel.prototype.getProductDetails = function (productIds, arrangeProducts) {
                    var _this = this;
                    var projectionDomain = new DataServiceEntities_g_1.Entities.ProjectionDomain();
                    projectionDomain.ChannelId = this.ChannelID;
                    var searchProductCriteria = {
                        Context: projectionDomain,
                        Ids: productIds,
                        DataLevelValue: 4,
                        SkipVariantExpansion: false
                    };
                    var request = new DataServiceRequests_g_1.Products.ProductSearchByTextRequest(searchProductCriteria, 10, 0);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (!result.canceled) {
                            _this.product(result.data.result[0].Product);
                            _this.fillDimensionInfo(result.data.result[0].Product);
                            var description = _this.product().Name || _this.product().ProductName || _this.product().Description;
                            description = TypeExtensions_1.StringExtensions.format("{0} : {1}", _this.product().ItemId, description);
                            _this.productName(description);
                            return result.data.result;
                        }
                        return [];
                    })
                        .catch(function (reason) {
                        _this._context.logger.logError("Product search error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        return [];
                    });
                };
                ProductDimensionsViewModel.prototype.getDimensionValues = function (RecordId, dimension, kitVariantResolutionContext, matchingDimensionValues) {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.Products.GetDimensionValuesRequest(this.ChannelID, RecordId, dimension, kitVariantResolutionContext, matchingDimensionValues);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (!result.canceled) {
                            return result.data.result;
                        }
                        return null;
                    })
                        .catch(function (reason) {
                        _this._context.logger.logError("Product dimension error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        return null;
                    });
                };
                ProductDimensionsViewModel.prototype.getProductVariantDetails = function (recordId, matchingDimensionValues) {
                    var _this = this;
                    var request = new DataServiceRequests_g_1.Products.GetProductVariantRequest(this.ChannelID, recordId, matchingDimensionValues);
                    return this._context.runtime.executeAsync(request)
                        .then(function (result) {
                        if (!result.canceled) {
                            return result.data.result;
                        }
                        return null;
                    })
                        .catch(function (reason) {
                        _this._context.logger.logError("Product variant error: " + JSON.stringify(reason));
                        ErrorHelper_1.ErrorHelper.displayLocalizedErrorAsync(_this._context, reason);
                        return null;
                    });
                };
                ProductDimensionsViewModel.prototype.getConfiguration = function () {
                    var str_configuration = sessionStorage.getItem("RR_UtilitiesConfiguration");
                    var configuration = JSON.parse(str_configuration);
                    this.isBlockSale = false;
                    var RR = Commerce;
                    var ChannelConfig = JSON.parse(RR.ApplicationStorage.getItem(RR.ApplicationStorageIDs.CHANNEL_CONFIGURATION_KEY));
                    this.ChannelID = ChannelConfig.RecordId;
                    if (!TypeExtensions_1.ObjectExtensions.isNullOrUndefined(configuration))
                        this.isBlockSale = configuration.BlockSales == 1;
                };
                ProductDimensionsViewModel.prototype.fillDimensionInfo = function (product) {
                    if (product.IsMasterProduct) {
                        var variantInformation = product.CompositionInformation.VariantInformation;
                        var variants = [];
                        var Dimensions = this.dimensionList;
                        var objArray = [];
                        for (var i = 0; i < variantInformation.Variants.length; i++) {
                            variants.push(new DataServiceEntities_g_1.Entities.ProductExVariantClass(variantInformation.Variants[i]));
                        }
                        this.productVariantList(variants);
                        for (var dimensionCount = 0; dimensionCount < Dimensions.length; dimensionCount++) {
                            this.dimensions.push({ name: Dimensions[dimensionCount].DimensionKey });
                            switch (dimensionCount) {
                                case 0:
                                    this.bDimension1(true);
                                    this.dimensionName1(Dimensions[dimensionCount].DimensionKey);
                                    objArray = [];
                                    for (var i = 0; i < Dimensions[dimensionCount].DimensionValues.length; i++) {
                                        objArray.push({
                                            dimension: Dimensions[dimensionCount].DimensionKey,
                                            text: Dimensions[dimensionCount].DimensionValues[i].DimensionValue,
                                            value: this.encodeInputStr(Dimensions[dimensionCount].DimensionValues[i].DimensionValue),
                                            isSelected: i == 0 ? true : false,
                                            idx: i
                                        });
                                    }
                                    this.dimensionList1(objArray);
                                    break;
                                case 1:
                                    this.bDimension2(true);
                                    this.dimensionName2(Dimensions[dimensionCount].DimensionKey);
                                    objArray = [];
                                    for (var i = 0; i < Dimensions[dimensionCount].DimensionValues.length; i++) {
                                        objArray.push({
                                            dimension: Dimensions[dimensionCount].DimensionKey,
                                            text: Dimensions[dimensionCount].DimensionValues[i].DimensionValue,
                                            value: this.encodeInputStr(Dimensions[dimensionCount].DimensionValues[i].DimensionValue),
                                            isSelected: i == 0 ? true : false,
                                            idx: i
                                        });
                                    }
                                    objArray = objArray.sort(this.SortByName);
                                    this.dimensionList2(objArray);
                                    break;
                                case 2:
                                    this.bDimension3(true);
                                    this.dimensionName3(Dimensions[dimensionCount].DimensionKey);
                                    objArray = [];
                                    for (var i = 0; i < Dimensions[dimensionCount].DimensionValues.length; i++) {
                                        objArray.push({
                                            dimension: Dimensions[dimensionCount].DimensionKey,
                                            text: Dimensions[dimensionCount].DimensionValues[i].DimensionValue,
                                            value: this.encodeInputStr(Dimensions[dimensionCount].DimensionValues[i].DimensionValue),
                                            isSelected: i == 0 ? true : false,
                                            idx: i
                                        });
                                    }
                                    this.dimensionList3(objArray);
                                    break;
                                case 3:
                                    this.bDimension4(true);
                                    this.dimensionName4(Dimensions[dimensionCount].DimensionKey);
                                    objArray = [];
                                    for (var i = 0; i < Dimensions[dimensionCount].DimensionValues.length; i++) {
                                        objArray.push({
                                            dimension: Dimensions[dimensionCount].DimensionKey,
                                            text: Dimensions[dimensionCount].DimensionValues[i].DimensionValue,
                                            value: this.encodeInputStr(Dimensions[dimensionCount].DimensionValues[i].DimensionValue),
                                            isSelected: i == 0 ? true : false,
                                            idx: i
                                        });
                                    }
                                    this.dimensionList4(objArray);
                                    break;
                                default:
                                    break;
                            }
                        }
                        this.bDimensionInfiFilled(true);
                        this.dimList1(this.dimensionList1());
                        this.dimList2(this.dimensionList2());
                        this.dimList3(this.dimensionList3());
                        this.dimList4(this.dimensionList4());
                    }
                };
                ProductDimensionsViewModel.prototype.getProductDimensions = function (recordId) {
                    var _this = this;
                    var request = null;
                    var strArr = [];
                    var dim = '';
                    var self = this;
                    var _loop_1 = function (i) {
                        request = new DataServiceRequests_g_1.Products.GetDimensionValuesRequest(this_1.ChannelID, recordId, i, null, []);
                        this_1._context.runtime.executeAsync(request)
                            .then(function (result) {
                            if (!result.canceled) {
                                var resp = result.data.result;
                                if (resp.length) {
                                    strArr = [];
                                    switch (i) {
                                        case 1:
                                            dim = 'Color';
                                            break;
                                        case 2:
                                            dim = 'Configuration';
                                            break;
                                        case 3:
                                            dim = 'Size';
                                            break;
                                        case 4:
                                            dim = 'Style';
                                            break;
                                    }
                                    for (var idx = 0; idx < resp.length; idx++) {
                                        if (resp[idx].RecordId != 0)
                                            strArr.push(new Entities_1.ProxyEntities.ProductDimensionValueSetClass({
                                                DimensionValue: resp[idx].Value, VariantSet: []
                                            }));
                                    }
                                    if (strArr.length) {
                                        self.dimensionList.push(new Entities_1.ProxyEntities.ProductDimensionSetClass({
                                            DimensionKey: dim, DimensionValues: strArr
                                        }));
                                        console.log(self.dimensionList);
                                    }
                                }
                            }
                        })
                            .catch(function (reason) {
                            _this._context.logger.logError("Product dimension error: " + JSON.stringify(reason));
                        });
                    };
                    var this_1 = this;
                    for (var i = 1; i < 5; i++) {
                        _loop_1(i);
                    }
                };
                ProductDimensionsViewModel.prototype.SortByName = function (x, y) {
                    return ((x.text == y.text) ? 0 : ((x.text > y.text) ? 1 : -1));
                };
                ProductDimensionsViewModel.prototype.getDimensionId = function (dimensionType, dimensionName) {
                    var product = this.product();
                    var variantCollection = product.CompositionInformation.VariantInformation.Variants;
                    var dimensionId = "", len = variantCollection.length;
                    switch (dimensionType) {
                        case "Color":
                            for (var i = 0; i < len; i++) {
                                if (variantCollection[i].Color === dimensionName) {
                                    dimensionId = variantCollection[i].ColorId;
                                    break;
                                }
                            }
                            break;
                        case "Size":
                            for (var i = 0; i < len; i++) {
                                if (variantCollection[i].Size === dimensionName) {
                                    dimensionId = variantCollection[i].SizeId;
                                    break;
                                }
                            }
                            break;
                        case "Style":
                            for (var i = 0; i < len; i++) {
                                if (variantCollection[i].Style === dimensionName) {
                                    dimensionId = variantCollection[i].StyleId;
                                    break;
                                }
                            }
                            break;
                        case "Configuration":
                            for (var i = 0; i < len; i++) {
                                if (variantCollection[i].Configuration === dimensionName) {
                                    dimensionId = variantCollection[i].ConfigId;
                                    break;
                                }
                            }
                            break;
                        default:
                            break;
                    }
                    return dimensionId;
                };
                ProductDimensionsViewModel.prototype.getVariantId = function (product, dimension) {
                    var variantId = -1;
                    var variantCollection = [];
                    if (product.IsMasterProduct && !product.IsKit) {
                        variantCollection = product.CompositionInformation.VariantInformation.Variants;
                        for (var dimensionCount = 0; dimensionCount < product.CompositionInformation.VariantInformation.Dimensions.length; dimensionCount++) {
                            if (!TypeExtensions_1.ObjectExtensions.isNullOrUndefined(dimension[dimensionCount].SelectedOption())) {
                                var tempVariantCollection = [];
                                variantCollection.forEach(function (variant) {
                                    if (variant[dimension[dimensionCount].SelectedOption().dimension] == dimension[dimensionCount].SelectedOption().value) {
                                        tempVariantCollection.push(variant);
                                    }
                                });
                                variantCollection = tempVariantCollection;
                            }
                            else {
                                break;
                            }
                        }
                        if (TypeExtensions_1.ArrayExtensions.hasElements(variantCollection) && variantCollection.length == 1) {
                            variantId = variantCollection[0].DistinctProductVariantId;
                        }
                    }
                    else {
                        variantId = product.RecordId;
                    }
                    return variantId;
                };
                ProductDimensionsViewModel.prototype.encodeInputStr = function (str) {
                    str = str.replace(/\//g, "-");
                    str = str.replace(/\\/g, "_");
                    str = str.replace(/ /g, "_");
                    return str;
                };
                ProductDimensionsViewModel.prototype.GetDimensionTypeString = function (dimensionType) {
                    var OptionCaption = "";
                    if (!TypeExtensions_1.StringExtensions.isNullOrWhitespace(dimensionType)) {
                        switch (dimensionType) {
                            case "COLOR":
                                OptionCaption = "Select a color";
                                break;
                            case "SIZE":
                                OptionCaption = "Select a size";
                                break;
                            case "STYLE":
                                OptionCaption = "Select a style";
                                break;
                            case "CONFIGURATION":
                                OptionCaption = "Select a configuration";
                                break;
                            default:
                                break;
                        }
                    }
                    return OptionCaption;
                };
                ProductDimensionsViewModel.ProductVideoPropertyTypeValue = 40;
                return ProductDimensionsViewModel;
            }());
            exports_1("default", ProductDimensionsViewModel);
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/Views/ProductDimensionsViewModel.js.map