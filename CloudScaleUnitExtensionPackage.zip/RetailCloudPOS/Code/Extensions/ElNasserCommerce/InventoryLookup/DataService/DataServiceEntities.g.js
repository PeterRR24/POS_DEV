System.register(["PosApi/Entities", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var Entities_1, TypeExtensions_1, Entities;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            (function (Entities) {
                var ProjectionDomain = (function () {
                    function ProjectionDomain() {
                    }
                    return ProjectionDomain;
                }());
                Entities.ProjectionDomain = ProjectionDomain;
                var ProductExClass = (function () {
                    function ProductExClass(odataObject) {
                        odataObject = odataObject || {};
                        this.ProductName = odataObject.ProductName || odataObject.Name;
                        this.Name = odataObject.Name;
                        this.ProductNumber = odataObject.ItemId;
                        this.ItemId = odataObject.ItemId;
                        this.Price = odataObject.Price;
                        this.IsMasterProduct = odataObject.IsMasterProduct;
                        this.IsKit = odataObject.IsKit;
                        this.RecordId = odataObject.RecordId;
                        var idx = TypeExtensions_1.ObjectExtensions.isNullOrUndefined(odataObject.ExtensionProperties) ? -1 : odataObject.ExtensionProperties.map(function (e) { return e.Key; }).indexOf('AvailableQty');
                        var qty = idx == -1 ? 0 : odataObject.ExtensionProperties[idx].Value.DecimalValue;
                        this.Quantity = parseFloat(qty);
                        this.ProductType = this.IsMasterProduct ? "Master" : (this.IsKit ? "Kit" : "Product");
                        this.TransactionQuantity = 0;
                        this.SelectedQuantity = 0;
                        this.AvailableQuantity = parseFloat(qty);
                        this.CssQuantity = this.Quantity < 0 ? "#ff0000" : "";
                        this.CssAvailQuantity = "";
                        this.Product = new Commerce.Proxy.Entities.ProductClass(odataObject);
                        var prodUnit = this.Product.Rules.DefaultUnitOfMeasure;
                        this.Unit = TypeExtensions_1.StringExtensions.isNullOrWhitespace(prodUnit) ? '' : prodUnit;
                    }
                    return ProductExClass;
                }());
                Entities.ProductExClass = ProductExClass;
                var ProductExVariantClass = (function () {
                    function ProductExVariantClass(odataObject) {
                        odataObject = odataObject || {};
                        this.Quantity = 0;
                        this.TransQuantity = 0;
                        this.ExtensionProperties = undefined;
                        if (odataObject.ExtensionProperties) {
                            this.ExtensionProperties = [];
                            for (var i = 0; i < odataObject.ExtensionProperties.length; i++) {
                                this.ExtensionProperties[i] = odataObject.ExtensionProperties[i] ? new Entities_1.ProxyEntities.CommercePropertyClass(odataObject.ExtensionProperties[i]) : null;
                                if (this.ExtensionProperties[i].Key == "AvailableQty")
                                    this.Quantity = this.ExtensionProperties[i].Value.DecimalValue;
                            }
                        }
                        this.RecordId = odataObject.RecordId;
                        this.ItemId = odataObject.ItemId;
                        this.MasterProductId = (odataObject.MasterProductId != null) ? parseInt(odataObject.MasterProductId, 10) : undefined;
                        this.InventoryDimensionId = odataObject.InventoryDimensionId;
                        this.DistinctProductVariantId = (odataObject.DistinctProductVariantId != null) ? parseInt(odataObject.DistinctProductVariantId, 10) : undefined;
                        this.ProductNumber = odataObject.ProductNumber;
                        this.AdjustedPrice = (odataObject.AdjustedPrice != null) ? parseFloat(odataObject.AdjustedPrice) : undefined;
                        this.BasePrice = (odataObject.BasePrice != null) ? parseFloat(odataObject.BasePrice) : undefined;
                        this.Price = (odataObject.Price != null) ? parseFloat(odataObject.Price) : undefined;
                        this.Color = odataObject.Color;
                        this.Style = odataObject.Style;
                        this.Size = odataObject.Size;
                        this.Configuration = odataObject.Configuration;
                        this.ColorId = odataObject.ColorId;
                        this.StyleId = odataObject.StyleId;
                        this.SizeId = odataObject.SizeId;
                        this.ConfigId = odataObject.ConfigId;
                        this.VariantId = odataObject.VariantId;
                    }
                    return ProductExVariantClass;
                }());
                Entities.ProductExVariantClass = ProductExVariantClass;
                var UtilitiesConfiguration = (function () {
                    function UtilitiesConfiguration(odataObject) {
                        odataObject = odataObject || {};
                        this.RangingWithFaces = (odataObject.RangingWithFaces != null) ? parseInt(odataObject.RangingWithFaces, 10) : undefined;
                        this.LabelHierarchyRecId = (odataObject.LabelHierarchyRecId != null) ? parseInt(odataObject.LabelHierarchyRecId, 10) : undefined;
                        this.DefaultLabelProfileRecId = (odataObject.DefaultLabelProfileRecId != null) ? parseInt(odataObject.DefaultLabelProfileRecId, 10) : undefined;
                        this.FireSaleBarcodePrefix = odataObject.FireSaleBarcodePrefix;
                        this.LabelCurrencyCode = odataObject.LabelCurrencyCode;
                        this.DisableLabelWizard = (odataObject.DisableLabelWizard != null) ? parseInt(odataObject.DisableLabelWizard, 10) : undefined;
                        this.BlockSales = (odataObject.BlockSales != null) ? parseInt(odataObject.BlockSales, 10) : undefined;
                    }
                    return UtilitiesConfiguration;
                }());
                Entities.UtilitiesConfiguration = UtilitiesConfiguration;
            })(Entities || (exports_1("Entities", Entities = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/InventoryLookup/DataService/DataServiceEntities.g.js.map