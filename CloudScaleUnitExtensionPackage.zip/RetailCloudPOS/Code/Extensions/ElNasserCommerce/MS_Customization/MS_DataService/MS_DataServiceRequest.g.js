System.register(["PosApi/Entities", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, DataService_1, MS;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            (function (MS) {
                var GetItemBarcodeResponse = (function (_super) {
                    __extends(GetItemBarcodeResponse, _super);
                    function GetItemBarcodeResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetItemBarcodeResponse;
                }(DataService_1.DataServiceResponse));
                MS.GetItemBarcodeResponse = GetItemBarcodeResponse;
                var GetItemBarcodeRequest = (function (_super) {
                    __extends(GetItemBarcodeRequest, _super);
                    function GetItemBarcodeRequest(dimRequestData) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "";
                        _this._entityType = "";
                        _this._method = "GetBarcodeAsync";
                        _this._parameters = { dimRequestData: dimRequestData };
                        _this._isAction = true;
                        _this._returnType = String;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return GetItemBarcodeRequest;
                }(DataService_1.DataServiceRequest));
                MS.GetItemBarcodeRequest = GetItemBarcodeRequest;
            })(MS || (exports_1("MS", MS = {})));
        }
    };
});
//# sourceMappingURL=C:/ElNasserCommerce/ElNasserCommerce/src/ScaleUnit/POS/MS_Customization/MS_DataService/MS_DataServiceRequest.g.js.map